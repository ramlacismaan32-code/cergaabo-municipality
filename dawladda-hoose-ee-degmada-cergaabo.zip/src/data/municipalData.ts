import {
  Department,
  MunicipalService,
  Project,
  NewsItem,
  CitizenApplication,
  ComplaintTicket,
  GalleryItem
} from '../types';

export const INITIAL_SERVICES: MunicipalService[] = [
  {
    id: 'shati-ganacsi',
    titleSo: 'Bixinta & Cusboonaysiinta Shatiga Ganacsiga',
    titleEn: 'Business License Issuance & Renewal',
    category: 'business',
    descriptionSo: 'Diiwaangelinta ganacsiyada cusub iyo cusboonaysiinta ruqsadda sanadlaha ah ee dhammaan shirkadaha, dukaamada, iyo xarumaha ganacsi ee Degmada Ceerigaabo.',
    descriptionEn: 'Registration of new commercial enterprises and annual renewal of operating licenses for all businesses in Ceerigaabo District.',
    feeSo: '$35 – $150 sanadkii (waxay ku xiran tahay nooca ganacsiga)',
    feeEn: '$35 – $150 / year (based on business category)',
    durationSo: '2 – 3 Maalmood oo shaqo',
    durationEn: '2 – 3 Working Days',
    requirementsSo: [
      'Nuqul ka mid ah Kaarka Aqoonsiga ama Baasaboorka qofka leh ganacsiga',
      'Magaca rasmiga ah ee ganacsiga iyo goobta uu ku yaal (Xaafadda/Jidka Ceerigaabo)',
      'Warqadda heshiiska kireysiga dhismaha ama caddeynta lahaanshaha',
      'Warqadda canshuur bixinta sanadkii hore (haddii ay tahay cusboonaysiin)'
    ],
    requirementsEn: [
      'Copy of National ID or Passport of the business owner',
      'Registered business name and verified physical location in Ceerigaabo',
      'Commercial lease agreement or ownership certificate',
      'Tax clearance receipt from previous year (if renewal)'
    ],
    departmentId: 'maaliyadda'
  },
  {
    id: 'rukhsad-dhisme',
    titleSo: 'Rukhsadda & Oggolaanshaha Dhismaha Cusub',
    titleEn: 'Building & Construction Permit',
    category: 'land',
    descriptionSo: 'Kormeerka injineernimo, ansixinta naqshadda, iyo bixinta rukhsadda dhismaha guryaha, dukaamada, xarumaha caafimaadka, iyo dhismayaasha guud ee magaalada Ceerigaabo.',
    descriptionEn: 'Engineering review, architectural inspection, and issuance of legal permits for residential and commercial constructions in Ceerigaabo.',
    feeSo: '$80 – $300 (ku salaysan cabbirka iyo dabaqyada)',
    feeEn: '$80 – $300 (based on square meters and floors)',
    durationSo: '5 – 7 Maalmood oo shaqo',
    durationEn: '5 – 7 Working Days',
    requirementsSo: [
      'Nuqul ka mid ah Xujada Dhulka (Mulkiyadda) oo sax ah',
      'Naqshadda dhismaha (Blueprints & Structural Design) oo injineer shati leh saxiixay',
      'Kormeerka goobta dhismaha oo ay samaynayaan injineerada Dawladda Hoose ee Ceerigaabo',
      'Bixinta khidmadda rukhsadda dhismaha'
    ],
    requirementsEn: [
      'Verified Land Title Deed (Mulkiyad)',
      'Architectural and structural engineering drawings signed by licensed engineer',
      'Site inspection report by Ceerigaabo Municipal Building Surveyors',
      'Payment of construction permit fee'
    ],
    departmentId: 'qorshaynta'
  },
  {
    id: 'adeeg-nadaafad',
    titleSo: 'Adeegga Nadaafadda & Ururinta Qashinka',
    titleEn: 'City Sanitation & Waste Collection Services',
    category: 'sanitation',
    descriptionSo: 'Isku xirka guryaha iyo ganacsiyada nidaamka ururinta qashinka toddobaadlaha ah, adeegga gaadiidka qashinka, iyo nadaafadda jidadka waaweyn ee Ceerigaabo.',
    descriptionEn: 'Subscription to weekly scheduled residential and commercial waste disposal, municipal collection trucks, and public street cleaning.',
    feeSo: '$5 bishii (Qoysaska) / $15 - $40 bishii (Ganacsiyada)',
    feeEn: '$5 / month (Households) / $15 - $40 / month (Businesses)',
    durationSo: 'Isla maalinta codsiga ama 24 saacadood',
    durationEn: 'Same day or within 24 hours',
    requirementsSo: [
      'Magaca madaxa qoyska ama mas’uulka dhismaha',
      'Cinwaanka guriga / goobta (Xaafadda Dayaxa, Daalo, Surud, Barwaaqo)',
      'Lambarka telefoonka lagala xiriiro',
      'Doorashada qorshaha ururinta (Todobaadle / Labadii Maalmoodba mar)'
    ],
    requirementsEn: [
      'Head of household or building manager identification',
      'Physical address (Ward: Dayaxa, Daalo, Surud, Barwaaqo)',
      'Contact telephone number',
      'Preferred collection frequency plan'
    ],
    departmentId: 'nadaafadda'
  },
  {
    id: 'xaqiijin-dhul',
    titleSo: 'Xaqiijinta & Diiwaangelinta Mulkiyadda Dhulka',
    titleEn: 'Land Title Verification & Registry',
    category: 'land',
    descriptionSo: 'Baarista xujada dhulka, cabbirka saxda ah (Surveying), diiwaangelinta xogta dhulka ee diiwaanka rasmiga ah ee Dawladda Hoose ee Ceerigaabo.',
    descriptionEn: 'Official land title verification, cadastral surveying, municipal archive registration, and boundary dispute resolution in Sanaag.',
    feeSo: '$60 (Kormeerka & Shahaadada)',
    feeEn: '$60 (Inspection & Official Certificate)',
    durationSo: '4 – 6 Maalmood oo shaqo',
    durationEn: '4 – 6 Working Days',
    requirementsSo: [
      'Xujada asalka ah ama qoraalka wareejinta dhulka',
      'Kaarka aqoonsiga ee mulkiilaha',
      'Oggolaanshaha deriska xuduudaha la leh goobta',
      'Joogitaanka goobta xilliga cabbirka rasmiga ah'
    ],
    requirementsEn: [
      'Original title documents or deed of transfer',
      'Owner national identity document',
      'Adjoining neighbors boundary consent',
      'Presence on site during official municipal GPS surveying'
    ],
    departmentId: 'qorshaynta'
  },
  {
    id: 'shahaado-dhalasho',
    titleSo: 'Bixinta Shahaadada Dhalashada & Guurka',
    titleEn: 'Birth & Marriage Certificates',
    category: 'social',
    descriptionSo: 'Diiwaangelinta muwaadiniinta, dhalashada carruurta cusub, xaqiijinta aqoonsiga degmada, iyo bixinta shahaadooyinka rasmiga ah ee Dawladda Hoose ee Ceerigaabo.',
    descriptionEn: 'Civil registry services for birth certificates, marriage certificates, and municipal certificates of residence in Ceerigaabo.',
    feeSo: '$10 qofkiiba',
    feeEn: '$10 per certificate',
    durationSo: '1 Maalin oo shaqo',
    durationEn: '1 Working Day',
    requirementsSo: [
      'Warqadda dhalashada ee isbitaalka Guud ee Ceerigaabo',
      'Nuqulka aqoonsiga labada waalid',
      'Sawirka canugga ama codsadaha (2 x 2)'
    ],
    requirementsEn: [
      'Hospital birth notification or two credible local witnesses',
      'Parents national identity copies',
      'Passport size photographs'
    ],
    departmentId: 'bulshada'
  },
  {
    id: 'dayactir-waddooyin',
    titleSo: 'Dayactirka & Furitaanka Waddooyinka',
    titleEn: 'Public Roads Maintenance & Access Grading',
    category: 'sanitation',
    descriptionSo: 'Codsiga furitaanka jidadka buuraleyda ah, simidda waddooyinka carro-tuulka ah roobabka kadib, iyo kormeerka dhuumaha biyo-mareennada Ceerigaabo.',
    descriptionEn: 'Citizen request for grading unpaved municipal streets, reopening blocked alleys, and maintaining storm-water trenches.',
    feeSo: 'Bilaash (Adeeg Dadweyne)',
    feeEn: 'Free (Public Municipal Service)',
    durationSo: '3 – 5 Maalmood oo kormeer ah',
    durationEn: '3 – 5 Days for inspection & dispatch',
    requirementsSo: [
      'Qoraalka codsiga guddiga xaafadda ama odayaasha deegaanka',
      'Sawirro muujinaya xaaladda waddada ama caqabadda jirta',
      'Magaca jidka iyo meelaha ay ku xiranto'
    ],
    requirementsEn: [
      'Neighborhood committee request letter',
      'Photographs showing the condition of the street',
      'Street name and connected intersections'
    ],
    departmentId: 'hawlaha-guud'
  },
  {
    id: 'canshuuraha-degmada',
    titleSo: 'Bixinta Canshuuraha Guryaha & Suuqyada',
    titleEn: 'Property Tax & Municipal Market Dues',
    category: 'tax',
    descriptionSo: 'Nidaamka hufan ee bixinta canshuurta guryaha, dhulka la deggan yahay, suuqyada xoolaha, iyo miisaska ganacsiga ee suuqyada magaalada Ceerigaabo.',
    descriptionEn: 'Transparent property tax calculation and municipal fee settlement for residential buildings, commercial shops, and market stalls in Ceerigaabo.',
    feeSo: 'Ku xiran qiimaynta rasmiga ah ee hantida',
    feeEn: 'Assessed according to property classification table',
    durationSo: 'Isla markiiba (Instant Receipt & Clear Certificate)',
    durationEn: 'Instant receipt & tax clearance certificate',
    requirementsSo: [
      'Lambarka aqoonsiga hantida (Property Code)',
      'Warqadda canshuurtii u dambaysay',
      'Bixinta lacagta bangiga ama lacagta taleefanka (Zaad / Sahal / EVC)'
    ],
    requirementsEn: [
      'Municipal Property Identification Code',
      'Previous payment clearance slip',
      'Mobile payment or bank settlement receipt'
    ],
    departmentId: 'maaliyadda'
  },
  {
    id: 'diiwaangelin-gaadiid',
    titleSo: 'Diiwaangelinta Gaadiidka & Taarikada Degmada',
    titleEn: 'Municipal Vehicle Registration & Permits',
    category: 'business',
    descriptionSo: 'Bixinta ruqsadda gaadiidka dadweynaha (Bajaajyada, Takaasida, iyo Gaadiidka Xamuulka ee Buuraha) ee ka shaqeeya gudaha Ceerigaabo iyo gobolka Sanaag.',
    descriptionEn: 'Permits and inspection registration for public transport, auto-rickshaws (Bajaaj), taxis, and freight trucks operating across Ceerigaabo and Sanaag.',
    feeSo: '$25 – $60 sanadkii',
    feeEn: '$25 – $60 / year',
    durationSo: '1 – 2 Maalmood',
    durationEn: '1 – 2 Working Days',
    requirementsSo: [
      'Buugga gaariga / bajaajta (Mulkiyad)',
      'Ruqsadda wadista baabuurka (Liisan)',
      'Kormeerka badqabka gaadiidka ee Waaxda Amniga & Gaadiidka'
    ],
    requirementsEn: [
      'Vehicle ownership logbook',
      'Valid driving license',
      'Safety and mechanical inspection clearance'
    ],
    departmentId: 'amniga'
  }
];

export const INITIAL_DEPARTMENTS: Department[] = [
  {
    id: 'maaliyadda',
    nameSo: 'Waaxda Maaliyadda & Dakhliga',
    nameEn: 'Department of Finance & Municipal Revenue',
    directorSo: 'Agaasime Axmed Jaamac Maxamed',
    directorEn: 'Director Ahmed Jama Mohamed',
    descriptionSo: 'Mas’uul ka ah maamulka miisaaniyadda degmada, ururinta canshuuraha, kordhinta dakhliga gudaha, iyo hubinta hufnaanta maaliyadeed ee degmada Ceerigaabo.',
    descriptionEn: 'Responsible for municipal budget administration, transparent tax collection, internal revenue mobilization, and public financial accountability in Ceerigaabo.',
    phone: '+252 63 446 8001',
    email: 'finance@degmadaceerigaabo.so',
    responsibilitiesSo: [
      'Diyaarinta miisaaniyadda sanadlaha ah ee Golaha Deegaanka Ceerigaabo',
      'Ururinta canshuuraha ganacsiyada, guryaha, iyo suuqyada Sanaag',
      'Xisaab-xirka bishii iyo sanadkii ee hantida dowladda hoose',
      'Bixinta shatiyada ganacsiga iyo caddeymaha canshuur bixinta'
    ],
    responsibilitiesEn: [
      'Annual municipal budget planning for City Council approval',
      'Collection of business licenses, property taxes, and market fees',
      'Transparent monthly and annual public audit reporting',
      'Issuing tax clearance documents and business permits'
    ],
    icon: 'DollarSign'
  },
  {
    id: 'qorshaynta',
    nameSo: 'Waaxda Qorshaynta & Dhulka',
    nameEn: 'Department of Urban Planning & Land Affairs',
    directorSo: 'Injineer Maxamuud Cali Faarax',
    directorEn: 'Eng. Mohamud Ali Farah',
    descriptionSo: 'Hoggaamisa qorshaynta casriga ah ee magaalada Ceerigaabo, bixinta xujada dhulka, kormeerka dhismaha, iyo ilaalinta xuduudaha guud ee magaalada.',
    descriptionEn: 'Leads urban master-planning for Ceerigaabo city, cadastral mapping, land title verification, and modern zoning regulations.',
    phone: '+252 63 446 8002',
    email: 'planning@degmadaceerigaabo.so',
    responsibilitiesSo: [
      'Naqshadaynta Master Plan-ka fiditaanka magaalada Ceerigaabo',
      'Bixinta rukhsadaha dhismaha cusub iyo hubinta badqabka',
      'Diiwaangelinta dhulka iyo ka hortagga is-qabsiga mulkiyadda',
      'Cabbirka dhulka (GPS & Surveying) iyo calaamadaynta jidadka'
    ],
    responsibilitiesEn: [
      'Master plan execution and residential/commercial zoning',
      'Reviewing architectural drawings and issuing building permits',
      'Cadastral land registry and preventing land dispute overlap',
      'GIS surveying and demarcating planned street networks'
    ],
    icon: 'Compass'
  },
  {
    id: 'nadaafadda',
    nameSo: 'Waaxda Nadaafadda & Deegaanka',
    nameEn: 'Department of Sanitation & Environment',
    directorSo: 'Faadumo Xasan Nuur',
    directorEn: 'Fadumo Hassan Nur',
    descriptionSo: 'Ilaalinta nadaafadda guud ee Ceerigaabo, ilaalinta keymaha Daalo iyo buuraha Surud & Sheed, maareynta qashinka, iyo la dagaallanka xaalufka.',
    descriptionEn: 'Maintains citywide hygiene, protects the famous Daalo juniper forest and Surud mountains, operates municipal dump trucks, and enforces conservation.',
    phone: '+252 63 446 8003',
    email: 'environment@degmadaceerigaabo.so',
    responsibilitiesSo: [
      'Isku dubaridka gaadiidka qashinka maalinlaha ah ee xaafadaha Ceerigaabo',
      'Ilaalinta kaymaha caanka ah ee Daalo iyo dhirta dabiiciga ah ee Sanaag',
      'Ololaha joogtada ah ee nadaafadda suuqyada iyo jidadka waaweyn',
      'Mashruuca cagaaraynta magaalada iyo ilaalinta xoolaha dhex yaaca magaalada'
    ],
    responsibilitiesEn: [
      'Fleet operations for residential and commercial waste collection',
      'Protection of the famous Daalo juniper reserve and Sanaag fauna',
      'Routine sweeping campaigns across avenues and commercial districts',
      'Urban greening initiatives and municipal environmental bylaws'
    ],
    icon: 'Trees'
  },
  {
    id: 'hawlaha-guud',
    nameSo: 'Waaxda Hawlaha Guud & Waddooyinka',
    nameEn: 'Department of Public Works & Roads',
    directorSo: 'Inj. Cabdiraxmaan Cismaan Shire',
    directorEn: 'Eng. Abdirahman Osman Shire',
    descriptionSo: 'Dhismaha iyo dayactirka jidadka laamiga ah ee Ceerigaabo, waddada isku xirta Ceerigaabo iyo Maydh, iyo dhuumaha biyo-mareennada buuraha.',
    descriptionEn: 'Oversees road paving, mountain pass maintenance, stormwater channels, culverts, and municipal civil engineering projects in Ceerigaabo.',
    phone: '+252 63 446 8004',
    email: 'publicworks@degmadaceerigaabo.so',
    responsibilitiesSo: [
      'Dhismaha laamiyada cusub ee gudaha Ceerigaabo',
      'Dayactirka iyo dhismaha biyo-mareennada daadadka buuraha',
      'Ku rakibidda iyo ilaalinta nalalka cadceedda (Solar Streetlights)',
      'Kormeerka waddada Ceerigaabo-Maydh iyo Ceerigaabo-Burco'
    ],
    responsibilitiesEn: [
      'Paving connecting asphalt avenues across Ceerigaabo wards',
      'Mountain stormwater drainage channel construction',
      'Solar street lighting installation and maintenance',
      'Oversight of key road arteries connecting Ceerigaabo to Maydh port and Burco'
    ],
    icon: 'Construction'
  },
  {
    id: 'bulshada',
    nameSo: 'Waaxda Arrimaha Bulshada & Caafimaadka',
    nameEn: 'Department of Social Affairs & Public Health',
    directorSo: 'Sahra Cali Cabdi',
    directorEn: 'Sahra Ali Abdi',
    descriptionSo: 'Daryeelka dhalinyarada, haweenka, adeegyada caafimaadka dadweynaha, diiwaangelinta madaniga ah, iyo waxbarashada Ceerigaabo.',
    descriptionEn: 'Champions youth programs, womens empowerment, public health inspections, civil registration, and community development in Ceerigaabo.',
    phone: '+252 63 446 8005',
    email: 'social@degmadaceerigaabo.so',
    responsibilitiesSo: [
      'Diiwaangelinta dhalashada, guurka, iyo dhimashada',
      'Kormeerka caafimaad ee maqaayadaha, hiliblayaasha, iyo suuqyada Ceerigaabo',
      'Barnaamijyada dhalinyarada, cayaaraha gobolka Sanaag, iyo laybareeriga guud',
      'Gargaarka dadka nugul xilliyada qabowga iyo abaaraha'
    ],
    responsibilitiesEn: [
      'Civil registration (birth certificates, marriages, civil status)',
      'Public health inspections for butcheries, cafes, and food vendors',
      'Sanaag regional sports tournaments, cultural events, and community library',
      'Emergency relief coordination for vulnerable households'
    ],
    icon: 'HeartHandshake'
  },
  {
    id: 'amniga',
    nameSo: 'Waaxda Amniga & Nabadgelyada Degmada',
    nameEn: 'Department of Municipal Police & Safety',
    directorSo: 'Korneyl Cabdullaahi Maxamed Guuleed',
    directorEn: 'Col. Abdullahi Mohamed Guled',
    descriptionSo: 'Ilaalinta nidaamka suuqyada, maamulka taraafikada gaadiidka, fulinta xeerarka Golaha Deegaanka, iyo badqabka guud ee degmada Ceerigaabo.',
    descriptionEn: 'Enforces municipal bylaws, manages traffic order, safeguards public assets, and collaborates closely with security agencies across Sanaag.',
    phone: '+252 63 446 8006 / Hotline 888',
    email: 'security@degmadaceerigaabo.so',
    responsibilitiesSo: [
      'Ilaalinta nidaamka suuqyada Ceerigaabo iyo kala dambeynta bajaajyada',
      'Ka hortagga dhismaha sharci-darrada ah ee goobaha dowladda',
      'Kooxda Gurmadka Degdegga ah iyo dab-damiska degmada Ceerigaabo',
      'Wadashaqeynta Ciidamada Booliska Gobolka Sanaag'
    ],
    responsibilitiesEn: [
      'Marketplace order, commercial zoning compliance, and traffic routing',
      'Preventing unauthorized encroachments on public rights-of-way',
      'Municipal emergency response and civic disaster mitigation unit',
      'Coordination with regional police forces in Sanaag'
    ],
    icon: 'ShieldCheck'
  }
];

export const INITIAL_PROJECTS: Project[] = [
  {
    id: 'prj-1',
    titleSo: 'Mashruuca Laamiga Wadada Wadnaha & Suuqa Weyn ee Ceerigaabo',
    titleEn: 'Ceerigaabo Main Boulevard & Central Market Asphalt Paving Project',
    categorySo: 'Waddooyinka & Kaabayaasha',
    categoryEn: 'Roads & Infrastructure',
    descriptionSo: 'Dhismaha laami casri ah oo ballaciisu yahay 14 mitir oo dhex mara badhtamaha Ceerigaabo, leh waddooyinka lugeeyayaasha, biyo-mareenno, iyo 150 nalalka cadceedda ah.',
    descriptionEn: 'Construction of a modern 14-meter wide asphalt boulevard through central Ceerigaabo with pedestrian walkways, drainage culverts, and 150 solar streetlights.',
    location: 'Wadada Wadnaha, Xaafadda Daalo ilaa Suuqa Weyn, Ceerigaabo',
    budget: '$520,000 USD',
    progress: 94,
    status: 'ongoing',
    contractor: 'Sanaag Infrastructure Development Consortium',
    startDate: 'Janaayo 2026',
    expectedCompletion: 'Maarso 2026',
    image: '/src/assets/images/ceerigaabo_highway_project_1794032958289.jpg'
  },
  {
    id: 'prj-2',
    titleSo: 'Mashruuca Waddada Laamiga ah ee Isku Xirta Ceerigaabo & Dekedda Maydh',
    titleEn: 'Ceerigaabo to Maydh Port Scenic Mountain Highway Project',
    categorySo: 'Waddooyinka & Ganacsiga',
    categoryEn: 'Highways & Commerce',
    descriptionSo: 'Dhismaha waddada muhiimka ah ee isku xirta caasimadda gobolka Sanaag ee Ceerigaabo iyo dekedda taariikhiga ah ee Maydh ee badda Cas.',
    descriptionEn: 'Vital asphalt corridor connecting Sanaag capital Ceerigaabo through mountain passes directly to the historic Red Sea port of Maydh.',
    location: 'Waddada Ceerigaabo ilaa Maydh',
    budget: '$1,200,000 USD',
    progress: 82,
    status: 'ongoing',
    contractor: 'Horn Mountain Engineering Co.',
    startDate: 'Oktoobar 2025',
    expectedCompletion: 'May 2026',
    image: '/src/assets/images/ceerigaabo_daalo_landscape_1794032957917.jpg'
  },
  {
    id: 'prj-3',
    titleSo: 'Xarunta Casriga ah ee Maareynta Qashinka & Dhowrista Deegaanka Daalo',
    titleEn: 'Ceerigaabo Eco-Landfill & Daalo Environmental Protection Project',
    categorySo: 'Nadaafadda & Deegaanka',
    categoryEn: 'Sanitation & Environment',
    descriptionSo: 'Dhismaha goob casri ah oo qashinka lagu kala saaro oo aan waxyeello u geysaneyn deegaanka buuraleyda ah ee Ceerigaabo iyo beerista 25,000 oo geed.',
    descriptionEn: 'Modern sanitary landfill facility outside city limits designed to protect fragile mountain hydrology and planting 25,000 native juniper trees.',
    location: 'Duleedka Koonfureed ee Ceerigaabo',
    budget: '$340,000 USD',
    progress: 76,
    status: 'ongoing',
    contractor: 'Sanaag Green Environmental Solutions',
    startDate: 'Noofambar 2025',
    expectedCompletion: 'Abriil 2026',
    image: '/src/assets/images/hero_ceerigaabo_city_1794032956999.jpg'
  },
  {
    id: 'prj-4',
    titleSo: 'Dhismaha & Ballaarinta Hoolka Golaha Deegaanka ee Ceerigaabo',
    titleEn: 'Expansion of Ceerigaabo City Council Hall & Civic Center',
    categorySo: 'Xarumaha Dowladda',
    categoryEn: 'Civic Architecture',
    descriptionSo: 'Dhismaha hool casri ah oo ay ku shiraan Golaha Deegaanka Ceerigaabo, xafiisyo cusub oo adeegga shacabka, iyo nidaamka xogta digital-ka ah.',
    descriptionEn: 'Construction of modern municipal chamber for Ceerigaabo City Council, citizen one-stop service halls, and computerized archive servers.',
    location: 'Xarunta Dawladda Hoose, Ceerigaabo',
    budget: '$210,000 USD',
    progress: 100,
    status: 'completed',
    contractor: 'Ceerigaabo Civic Builders',
    startDate: 'Maarso 2025',
    expectedCompletion: 'Janaayo 2026',
    image: '/src/assets/images/ceerigaabo_city_hall_somaliland_flag_1794034807781.jpg'
  },
  {
    id: 'prj-5',
    titleSo: 'Mashruuca Kanaalada Biyo-mareennada Daadadka Buuraha',
    titleEn: 'Mountain Flash Flood Mitigation & Stormwater Canals',
    categorySo: 'Hawlaha Guud',
    categoryEn: 'Public Works',
    descriptionSo: 'Dhismaha 5km oo kanaalo shub ah oo daadadka ka soo dega buuraha Surud iyo Sheed si nabad ah u dhaafiya xaafadaha Dayaxa iyo Daalo.',
    descriptionEn: 'Reinforced concrete canals redirecting torrents descending from Surud and Sheed mountain ridges safely away from residential quarters.',
    location: 'Xaafadaha Dayaxa & Daalo, Ceerigaabo',
    budget: '$290,000 USD',
    progress: 68,
    status: 'ongoing',
    contractor: 'Sanaag Water Works Consortium',
    startDate: 'Diseembar 2025',
    expectedCompletion: 'Juun 2026',
    image: '/src/assets/images/ceerigaabo_highway_project_1794032958289.jpg'
  },
  {
    id: 'prj-6',
    titleSo: 'Sayladda Casriga ah ee Xoolaha & Xarunta Kormeerka Caafimaadka Xoolaha',
    titleEn: 'Modern Regional Livestock Terminal & Veterinary Checkpoint',
    categorySo: 'Ganacsiga & Xoolaha',
    categoryEn: 'Commerce & Livestock',
    descriptionSo: 'Qorshaha dhismaha suuqa weyn ee xoolaha nool ee gobolka Sanaag oo leh biyo, kormeer caafimaad, iyo nidaamka canshuur ururinta ee digital-ka ah.',
    descriptionEn: 'Planned regional livestock export terminal with watering troughs, veterinary quarantine bays, and mobile payment tax gates.',
    location: 'Waddada Bariga Ceerigaabo',
    budget: '$380,000 USD',
    progress: 20,
    status: 'planned',
    contractor: 'Qandaraaska waa la furi doonaa dhowaan',
    startDate: 'Abriil 2026',
    expectedCompletion: 'Nofembar 2026',
    image: '/src/assets/images/hero_ceerigaabo_city_1794032956999.jpg'
  }
];

export const INITIAL_NEWS: NewsItem[] = [
  {
    id: 'news-1',
    titleSo: 'Wareegto: Shuruudaha Cusub & Fududeynta Shatiyada Ganacsiga Ceerigaabo 2026',
    titleEn: 'Executive Decree: Streamlined Business Licensing Regulations for 2026',
    category: 'wareegto',
    categoryLabelSo: 'Wareegto Rasmi ah',
    categoryLabelEn: 'Official Decree',
    summarySo: 'Duqa Degmada Ceerigaabo iyo Golaha Deegaanka ayaa soo saaray wareegto cusub oo 30% hoos loogu dhigay khidmadaha ganacsiyada yaryar si loo dhiirrigeliyo dhalinyarada iyo haweenka gobolka Sanaag.',
    summaryEn: 'The Mayor of Ceerigaabo and District Council enacted a decree reducing fees by 30% for micro-enterprises and women entrepreneurs across Sanaag.',
    contentSo: 'Duqa Degmada Ceerigaabo iyo Xoghayaha Dowladda Hoose ayaa si rasmi ah u saxiixay xeer-nidaamiyaha cusub ee canshuuraha iyo shatiyada ganacsiga 2026. Xeerkan ayaa ujeeddadiisu tahay in dhammaan ganacsiyada degmada Ceerigaabo laga saaro caqabadaha maamul, lana hirgeliyo nidaamka degdegga ah ee online-ka ah oo 48 saacadood gudahood lagu helayo shatiga ganacsiga. Waxaa kaloo la go’aamiyay in ganacsiyada cusub ee beeraha iyo dalxiiska Daalo laga dhaafo canshuurta bilaha ugu horreeya.',
    contentEn: 'The Mayor of Ceerigaabo and Council Secretary officially ratified the new 2026 municipal commerce bylaws. This reform introduces automated 48-hour approvals for business permits and encourages agricultural and eco-tourism ventures in the Daalo mountains.',
    date: '02 Maarso 2026',
    referenceNo: 'DHC/CRG/WRG-055/2026',
    isUrgent: true
  },
  {
    id: 'news-2',
    titleSo: 'Tartanka Qandaraaska: Dhismaha Kanaalka Biyo-mareenka Xaafadda Dayaxa',
    titleEn: 'Public Tender: Construction of Stormwater Canals in Dayaxa Ward',
    category: 'tartan',
    categoryLabelSo: 'Tartanka Qandaraaska',
    categoryLabelEn: 'Public Tender',
    summarySo: 'Dawladda Hoose ee Degmada Ceerigaabo waxay ku wargelinaysaa shirkadaha dhismaha ee shatiga leh inay u tartami karaan qandaraaska biyo-mareenka.',
    summaryEn: 'Ceerigaabo Municipality invites bids from certified civil engineering firms for the construction of major mountain stormwater canals.',
    contentSo: 'Guddiga Qandaraasyada ee Dawladda Hoose ee Ceerigaabo wuxuu ku dhawaaqayaa tartan furan oo ku saabsan dhismaha biyo-mareenka dheer ee Xaafadda Dayaxa. Shirkaduhu waa inay haystaan shati dhisme oo ka diiwaangashan gobolka Sanaag, khibrad ugu yaraan 3 sano ah oo mashaariicda buuraleyda ah, iyo dammaanad bangi. Qandaraasyada waxaa la xiri doonaa 25-ka Maarso 2026.',
    contentEn: 'The Municipal Procurement Board invites sealed bids for reinforced concrete drainage works in Dayaxa ward. Bidders must possess accredited contractor licensing and bank guarantee. Submission deadline is March 25, 2026.',
    date: '28 Febraayo 2026',
    referenceNo: 'TND-CRG-2026/04'
  },
  {
    id: 'news-3',
    titleSo: 'Duqa Degmada Ceerigaabo oo Kormeeray Horumarka Laamiga Wadada Wadnaha',
    titleEn: 'Mayor Conducts Field Inspection of Ceerigaabo Central Boulevard Works',
    category: 'mashruuc',
    categoryLabelSo: 'Horumarka Mashaariicda',
    categoryLabelEn: 'Project Update',
    summarySo: 'Duqa Degmada Ceerigaabo iyo xubno ka tirsan Golaha Deegaanka ayaa kormeer ku tagay dhismaha laamiga cusub ee Suuqa Weyn oo maraya heer gaba-gabo ah.',
    summaryEn: 'The Mayor accompanied by City Council members inspected final asphalt laying and solar illumination installations along central Ceerigaabo.',
    contentSo: 'Duqa Degmada Ceerigaabo wuxuu sheegay in mashruucan uu si weyn u fududeyn doono isu-socodka ganacsiga, gawaarida xamuulka, iyo dadweynaha u adeeganaya Suuqa Weyn ee Ceerigaabo. Wuxuu xusay in Dawladda Hoose ay xoogga saari doonto in Ceerigaabo noqoto magaalada ugu nadaafadda, quruxda, iyo deegaan-wanaagga badan.',
    contentEn: 'During the inspection, the Mayor emphasized that paved mountain boulevards enhance commerce and celebrate Ceerigaabo as the ecological and economic jewel of Sanaag.',
    date: '22 Febraayo 2026'
  },
  {
    id: 'news-4',
    titleSo: 'Ogeysiis Dadweyne: Ololaha Guud ee Nadaafadda Magaalada & Ilaalinta Daalo',
    titleEn: 'Public Announcement: Citywide Clean-Up & Daalo Forest Conservation Day',
    category: 'ogeysiis',
    categoryLabelSo: 'Ogeysiis Dadweyne',
    categoryLabelEn: 'Public Notice',
    summarySo: 'Dhammaan shacabka, ganacsatada, iyo ardayda Ceerigaabo waxaa lagu wargelinayaa ololaha nadaafadda degmada oo la qaban doono Sabtida soo socota.',
    summaryEn: 'All residents, merchants, civic associations, and students are invited to participate in the civic clean-up and mountain greening campaign.',
    contentSo: 'Waaxda Nadaafadda iyo Deegaanka ee Dawladda Hoose ee Ceerigaabo waxay ku wargelinaysaa bulshada in subaxnimada Sabtida la qabanayo Ololaha Guud ee Nadaafadda iyo Cagaaraynta Magaalada Ceerigaabo. Gaadiidka dowladda hoose ayaa bilaash ku daadgureyn doona qashinka dhammaan xaafadaha.',
    contentEn: 'The Department of Sanitation and Environment announces our monthly civic sanitation campaign. Municipal haulage trucks will collect household and market debris free of charge across all wards.',
    date: '15 Febraayo 2026'
  }
];

export const INITIAL_APPLICATIONS: CitizenApplication[] = [
  {
    id: 'CRG-2026-1042',
    applicantName: 'Jaamac Cali Xasan',
    nationalIdOrPhone: '+252 63 441 2345',
    serviceId: 'shati-ganacsi',
    serviceName: 'Bixinta Shatiga Ganacsiga (Dukaan Qalabka Dhismaha & Korontada)',
    neighborhood: 'Xaafadda Daalo, Wadada Suuqa',
    details: 'Codsiga ruqsadda ganacsi ee dukaanka Daalo Hardware Ceerigaabo.',
    status: 'La Ansixiyey (Approved)',
    submittedDate: '24 Febraayo 2026',
    estimatedFee: '$65.00',
    notes: 'Kormeerka goobta waa la dhamaystiray. Shatiga waxaad ka qaadan kartaa Xarunta Dawladda Hoose ee Ceerigaabo.'
  },
  {
    id: 'CRG-2026-1088',
    applicantName: 'Sahra Maxamed Faarax',
    nationalIdOrPhone: '+252 63 442 9911',
    serviceId: 'rukhsad-dhisme',
    serviceName: 'Rukhsadda Dhismaha Guri 2 Dabaq ah',
    neighborhood: 'Xaafadda Dayaxa',
    details: 'Dhismaha guri dabaq ah oo cabbirkiisu yahay 20m x 25m oo ku yaal Dayaxa.',
    status: 'Baaris ku Jirta (In Review)',
    submittedDate: '28 Febraayo 2026',
    estimatedFee: '$140.00',
    notes: 'Injineerada dowladda hoose ee Ceerigaabo waxay goobta booqanayaan 5-ta Maarso 2026.'
  },
  {
    id: 'CRG-2026-1105',
    applicantName: 'Cismaan Warsame Guuleed',
    nationalIdOrPhone: '+252 63 443 4400',
    serviceId: 'adeeg-nadaafad',
    serviceName: 'Ku biiridda Qorshaha Ururinta Qashinka Qoysaska',
    neighborhood: 'Xaafadda Surud',
    details: 'Qashinka guriga lambarkiisu yahay #88 ee Xaafadda Surud, Ceerigaabo.',
    status: 'Dhamaystiran (Completed)',
    submittedDate: '01 Maarso 2026',
    estimatedFee: '$5.00 / bishii',
    notes: 'Sanduuqa qashinka dowladda hoose ayaa la geeyay gurigaaga.'
  }
];

export const INITIAL_COMPLAINTS: ComplaintTicket[] = [
  {
    id: 'CAB-CRG-5510',
    fullName: 'Axmed Maxamuud Nuur',
    phone: '+252 63 444 1122',
    category: 'streetlights',
    categoryLabelSo: 'Nalalka Cadceedda (Solar Lights)',
    neighborhood: 'Xaafadda Dayaxa (Laamiga Maydh)',
    description: 'Labo ka mid ah nalalka cadceedda ee waddada Maydh ma shaqeynayaan muddo 3 maalmood ah roobka kadib.',
    priority: 'caadi',
    status: 'Wax Ka Qabasho Socota (In Progress)',
    submittedDate: '26 Febraayo 2026',
    resolutionNote: 'Farsamo-yaqaannada Waaxda Hawlaha Guud ee Ceerigaabo ayaa loo xilsaaray in baytariyada la beddelo.'
  },
  {
    id: 'CAB-CRG-5524',
    fullName: 'Faadumo Cali Warsame',
    phone: '+252 63 446 8899',
    category: 'sanitation',
    categoryLabelSo: 'Nadaafadda & Qashin-qubka',
    neighborhood: 'Xaafadda Daalo (Agagaarka Suuqa Xoolaha)',
    description: 'Qashin badan ayaa ku soo ururay meel furan, waxaana loo baahan yahay gaari qashin si looga qaado.',
    priority: 'degdeg',
    status: 'La Xalliyey (Resolved)',
    submittedDate: '22 Febraayo 2026',
    resolutionNote: 'Gaariga qashinka ee Dawladda Hoose ayaa goobta nadiifiyay 24-kii Febraayo, sanduuq qashinna waa la dhigay.'
  }
];

export const INITIAL_GALLERY: GalleryItem[] = [
  {
    id: 'gal-1',
    titleSo: 'Muuqaalka Guud ee Magaalada Ceerigaabo & Buuraha Surud',
    titleEn: 'Panoramic View of Ceerigaabo City & Surud Mountain Peaks',
    category: 'landmarks',
    categoryLabelSo: 'Muuqaalka Magaalada',
    categoryLabelEn: 'Cityscape',
    image: '/src/assets/images/hero_ceerigaabo_city_1794032956999.jpg',
    descriptionSo: 'Muuqaalka ballaaran ee magaalada Ceerigaabo, xarunta gobolka Sanaag, oo ku fadhida dhul buuraley ah oo cagaaran oo qabow leh.',
    descriptionEn: 'Wide panorama of Ceerigaabo city, elevated capital of Sanaag region, nestled amidst misty mountain ridges and cedar pine trees.'
  },
  {
    id: 'gal-2',
    titleSo: 'Xarunta Dawladda Hoose ee Ceerigaabo (City Hall)',
    titleEn: 'Ceerigaabo Municipal Civic Headquarters & City Hall',
    category: 'civic',
    categoryLabelSo: 'Xarumaha Dowladda',
    categoryLabelEn: 'Civic Buildings',
    image: '/src/assets/images/ceerigaabo_city_hall_somaliland_flag_1794034807781.jpg',
    descriptionSo: 'Dhismaha weyn ee Dawladda Hoose ee Degmada Ceerigaabo oo uu si sharaf leh uga dul babanayo Calanka Jamhuuriyadda Somaliland, halkaas oo shacabka loogu adeego laguna qabto shirarka Golaha Deegaanka.',
    descriptionEn: 'The modern administrative headquarters of Ceerigaabo Local Government, proudly flying the official Flag of the Republic of Somaliland atop the building entrance.'
  },
  {
    id: 'gal-3',
    titleSo: 'Keymaha Daalo & Buurta Surud ee Gobolka Sanaag',
    titleEn: 'Daalo Juniper Forest & Surud Mountain Escarpment',
    category: 'culture',
    categoryLabelSo: 'Deegaanka & Dalxiiska',
    categoryLabelEn: 'Nature & Tourism',
    image: '/src/assets/images/ceerigaabo_daalo_landscape_1794032957917.jpg',
    descriptionSo: 'Muuqaalka dabiiciga ah ee keymaha Daalo iyo Buurta Surud (Shimbiris) oo ah barta ugu sarreysa Jamhuuriyadda Somaliland (2,450 mitir).',
    descriptionEn: 'The breathtaking evergreen juniper forest of Daalo and Mount Surud, the highest peak in Somaliland standing at 2,450 meters elevation.'
  },
  {
    id: 'gal-4',
    titleSo: 'Dhismaha Laamiyada & Waddooyinka Buuraleyda Ceerigaabo',
    titleEn: 'Mountain Highway Paving & Infrastructure Works',
    category: 'infrastructure',
    categoryLabelSo: 'Kaabayaasha Dhaqaalaha',
    categoryLabelEn: 'Infrastructure',
    image: '/src/assets/images/ceerigaabo_highway_project_1794032958289.jpg',
    descriptionSo: 'Injineerada dowladda hoose oo hirgelinaya qorshaha laami-saarka waddooyinka casriga ah ee isku xira xaafadaha Ceerigaabo.',
    descriptionEn: 'Heavy machinery and civil engineers paving asphalt corridors equipped with solar lights across Ceerigaabo mountain passes.'
  },
  {
    id: 'gal-5',
    titleSo: 'Astaanta Rasmiga ah ee Dowlada Hoose ee Degmada Ceerigaabo',
    titleEn: 'Official Erigavo Local Government Seal & Crest',
    category: 'civic',
    categoryLabelSo: 'Astaanta Maamulka',
    categoryLabelEn: 'Official Crest',
    image: '/assets/aistudio/daw_15a3cf61.jpeg',
    descriptionSo: 'Shaabadda rasmiga ah ee Dowlada Hoose ee Degmada Ceerigaabo oo ay ku xardhan yihiin Buurta Surud iyo Buurta Sheed.',
    descriptionEn: 'The official crest of Erigavo Local Government illustrating Mount Surud and Mount Sheed.'
  }
];

export const MAYOR_DATA = {
  nameSo: 'Ismaaciil Xaaji Nuur',
  nameEn: 'Ismail Haji Nur',
  titleSo: 'Duqa Degmada Ceerigaabo & Guddoomiyaha Golaha Deegaanka',
  titleEn: 'Mayor of Ceerigaabo & Chairman of the District Council',
  deputyNameSo: 'Axmed Maxamed Jaamac',
  deputyNameEn: 'Ahmed Mohamed Jama',
  deputyTitleSo: 'Ku-xigeenka Duqa Degmada',
  deputyTitleEn: 'Deputy Mayor of Ceerigaabo',
  executiveSecretarySo: 'Maxamuud Xasan Cali',
  executiveSecretaryEn: 'Mohamud Hassan Ali',
  executiveSecretaryTitleSo: 'Xoghayaha Dowladda Hoose',
  executiveSecretaryTitleEn: 'Executive Secretary of Ceerigaabo Municipality',
  welcomeQuoteSo: 'Waxaan shacabka sharafta leh ee Degmada Ceerigaabo ugu adeegaynaa hufnaan, caddaalad, iyo horumarin buuxda oo lagu ilaalinayo bilicda dabiiciga ah ee gobolka Sanaag.',
  welcomeQuoteEn: 'Dedicated to serving the community of Ceerigaabo with integrity, transparency, and progressive civic development that honors the natural splendor of Sanaag.',
  speechSo: `Ku soo dhowaada bogga rasmiga ah ee Dawladda Hoose ee Degmada Ceerigaabo. Ceerigaabo waa caasimadda taariikhiga ah ee gobolka Sanaag, waana magaalo ku caan baxday cimiladeeda qabow, buuraha dhaadheer ee Surud iyo Sheed, iyo keymaha qaaliga ah ee Daalo.

Hadafkayagu waa inaan dhisno dowlad hoose oo casri ah, oo muwaadin kasta u sahlaysa inuu adeegyada degmada kaga helo gurigiisa ama goobtiisa ganacsi iyadoo la adeegsanayo tignoolajiyada casriga ah. Waxaan xoogga saarnay tayeynta kaabayaasha dhaqaalaha: waddooyin laami ah oo ammaan ah, maareynta qashinka magaalada, biyo-mareenno daadadka celiya, iyo shatiyo ganacsi oo 48 saacadood gudahood lagu bixiyo.

Waxaan shacabka reer Ceerigaabo iyo qurba-joogtaba ugu baaqaynaa inay nagala qayb-qaataan dhismaha, nadaafadda, iyo ilaalinta deegaanka cagaaran ee magaaladeena.`,
  speechEn: `Welcome to the official web portal of Ceerigaabo (Erigavo) Municipality. Ceerigaabo is the proud capital of the Sanaag region, renowned for its temperate mountain climate, towering peaks of Surud and Sheed, and the irreplaceable biodiversity of Daalo forest.

Our foremost commitment is creating an accountable, digitally connected municipality where every citizen and business owner can access public services effortlessly. We have prioritized durable paved roads, flood-safe drainage networks, eco-friendly sanitation, and rapid 48-hour commercial licensing.

I invite all residents of Ceerigaabo and our vibrant diaspora worldwide to partner with us in making our city the cleanest, greenest, and most prosperous highland metropolis in the region.`
};

export const DISTRICT_HISTORY = {
  titleSo: 'Taariikhda & Xogta Guud ee Degmada Ceerigaabo',
  titleEn: 'History & Overview of Ceerigaabo District',
  summarySo: 'Ceerigaabo waa caasimadda Gobolka Sanaag. Waxay ku taal dhul-buuraley ah oo jooggiisu sarreeyo (ku dhowaad 1,800m), waxaana ku hareereysan buuraha ugu dheer dalka sida Buurta Surud (2,450m), Buurta Sheed, iyo keymaha caanka ah ee Daalo.',
  summaryEn: 'Ceerigaabo (Erigavo) is the administrative capital of Sanaag Region. Situated on a scenic mountain plateau at approximately 1,800m elevation, it is surrounded by the highest peaks in the Horn of Africa, including Mount Surud (2,450m), Mount Sheed, and the ancient juniper forests of Daalo.',
  population: '140,000+',
  wards: ['Xaafadda Daalo', 'Xaafadda Dayaxa', 'Xaafadda Surud', 'Xaafadda Barwaaqo', 'Xaafadda Maydh Road'],
  elevation: '1,788 m ka sarreysa heerka badda',
  coordinates: '10°37′N 47°22′E',
  councilMembers: 21
};

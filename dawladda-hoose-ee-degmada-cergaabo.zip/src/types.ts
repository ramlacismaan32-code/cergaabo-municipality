export type Language = 'so' | 'en';

export interface MunicipalService {
  id: string;
  titleSo: string;
  titleEn: string;
  category: 'business' | 'land' | 'sanitation' | 'social' | 'tax';
  descriptionSo: string;
  descriptionEn: string;
  feeSo: string;
  feeEn: string;
  durationSo: string;
  durationEn: string;
  requirementsSo: string[];
  requirementsEn: string[];
  departmentId: string;
}

export interface Department {
  id: string;
  nameSo: string;
  nameEn: string;
  directorSo: string;
  directorEn: string;
  descriptionSo: string;
  descriptionEn: string;
  phone: string;
  email: string;
  responsibilitiesSo: string[];
  responsibilitiesEn: string[];
  icon: string;
}

export interface Project {
  id: string;
  titleSo: string;
  titleEn: string;
  categorySo: string;
  categoryEn: string;
  descriptionSo: string;
  descriptionEn: string;
  location: string;
  budget: string;
  progress: number;
  status: 'ongoing' | 'completed' | 'planned';
  contractor: string;
  startDate: string;
  expectedCompletion: string;
  image: string;
}

export interface NewsItem {
  id: string;
  titleSo: string;
  titleEn: string;
  category: 'wareegto' | 'mashruuc' | 'ogeysiis' | 'tartan';
  categoryLabelSo: string;
  categoryLabelEn: string;
  summarySo: string;
  summaryEn: string;
  contentSo: string;
  contentEn: string;
  date: string;
  referenceNo?: string;
  isUrgent?: boolean;
}

export interface CitizenApplication {
  id: string;
  applicantName: string;
  nationalIdOrPhone: string;
  serviceId: string;
  serviceName: string;
  neighborhood: string;
  details: string;
  status: 'Gudbiyey (Submitted)' | 'Baaris ku Jirta (In Review)' | 'La Ansixiyey (Approved)' | 'Dhamaystiran (Completed)' | 'La Diiday (Rejected)';
  submittedDate: string;
  estimatedFee: string;
  notes?: string;
}

export interface ComplaintTicket {
  id: string;
  fullName: string;
  phone: string;
  category: 'sanitation' | 'roads' | 'drainage' | 'streetlights' | 'corruption' | 'other';
  categoryLabelSo: string;
  neighborhood: string;
  description: string;
  priority: 'caadi' | 'degdeg' | 'aad u degdeg';
  status: 'Cusub (New)' | 'Wax Ka Qabasho Socota (In Progress)' | 'La Xalliyey (Resolved)';
  submittedDate: string;
  resolutionNote?: string;
}

export interface GalleryItem {
  id: string;
  titleSo: string;
  titleEn: string;
  category: 'landmarks' | 'civic' | 'infrastructure' | 'culture';
  categoryLabelSo: string;
  categoryLabelEn: string;
  image: string;
  descriptionSo: string;
  descriptionEn: string;
}

import React from 'react';
import { SomalilandFlag } from './SomalilandFlag';

interface OfficialEmblemProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
  showSubtitle?: boolean;
  showFlag?: boolean;
}

export const OfficialEmblem: React.FC<OfficialEmblemProps> = ({
  className = '',
  size = 'md',
  showSubtitle = true,
  showFlag = true
}) => {
  const sizeMap = {
    sm: 'w-9 h-9',
    md: 'w-12 h-12',
    lg: 'w-16 h-16'
  };

  return (
    <div className={`flex items-center gap-3 ${className}`}>
      {/* Official Emblem of Dowladda Hoose ee Degmada Ceerigaabo */}
      <div className={`relative ${sizeMap[size]} shrink-0 rounded-full overflow-hidden border-2 border-emerald-600/70 dark:border-emerald-500/70 shadow-sm bg-white flex items-center justify-center p-0.5`}>
        <img
          src="/assets/aistudio/daw_15a3cf61.jpeg"
          alt="Astaanta Rasmiga ah ee Dowlada Hoose ee Degmada Ceerigaabo"
          className="w-full h-full object-contain rounded-full"
          onError={(e) => {
            const currentSrc = e.currentTarget.getAttribute('src');
            if (currentSrc === '/assets/aistudio/daw_15a3cf61.jpeg') {
              e.currentTarget.src = '/public/assets/aistudio/daw_15a3cf61.jpeg';
            }
          }}
        />
      </div>

      {showSubtitle && (
        <div className="flex flex-col text-left">
          <span className="text-base sm:text-lg font-bold tracking-tight text-slate-900 dark:text-white leading-tight font-display">
            Degmada Ceerigaabo
          </span>
          <div className="flex items-center gap-1.5 mt-0.5">
            <span className="text-[11px] sm:text-xs text-emerald-800 dark:text-emerald-400 font-medium tracking-wide">
              Dawladda Hoose · Gobolka Sanaag
            </span>
            {showFlag && <SomalilandFlag size="xs" className="inline-block shrink-0 shadow-xs" />}
          </div>
        </div>
      )}
    </div>
  );
};

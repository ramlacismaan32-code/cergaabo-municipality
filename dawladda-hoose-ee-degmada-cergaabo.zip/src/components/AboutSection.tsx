import React from 'react';
import { Language } from '../types';
import { DISTRICT_HISTORY } from '../data/municipalData';
import { 
  Landmark, 
  Target, 
  Eye, 
  Shield, 
  MapPin, 
  Users, 
  CheckCircle,
  History,
  Flag
} from 'lucide-react';
import { SomalilandFlag } from './SomalilandFlag';

interface AboutSectionProps {
  lang: Language;
}

export const AboutSection: React.FC<AboutSectionProps> = ({ lang }) => {
  return (
    <section id="about" className="py-16 sm:py-20 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Section Header */}
        <div className="max-w-3xl mb-12">
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-800 dark:text-emerald-400 tracking-wider uppercase">
            <History className="w-4 h-4 text-emerald-800 dark:text-emerald-400" />
            <span>{lang === 'so' ? 'Ku Saabsan Degmada' : 'About Ceerigaabo Municipality'}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-slate-900 dark:text-white font-display mt-2">
            {lang === 'so' ? DISTRICT_HISTORY.titleSo : DISTRICT_HISTORY.titleEn}
          </h2>
          <p className="mt-3 text-base sm:text-lg text-slate-600 dark:text-slate-300 leading-relaxed">
            {lang === 'so' ? DISTRICT_HISTORY.summarySo : DISTRICT_HISTORY.summaryEn}
          </p>
        </div>

        {/* 2-Column Split: Historic Story + Palace Imagery */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch mb-16">
          <div className="lg:col-span-7 flex flex-col justify-between space-y-6">
            <div className="space-y-4 text-slate-700 dark:text-slate-300 text-sm sm:text-base leading-relaxed">
              <p>
                {lang === 'so'
                  ? 'Degmada Ceerigaabo (Erigavo) waa caasimadda taariikhiga ah ee Gobolka Sanaag ee Jamhuuriyadda Somaliland. Waxay caan ku tahay cimiladeeda qabow ee buuraleyda ah, dhulka doogga iyo cagaarka leh, iyo buuraha ugu dheer dalka Somaliland oo ay ugu horreyso Buurta Surud (Shimbiris oo 2,450m ah) iyo Buurta Sheed.'
                  : 'Ceerigaabo (Erigavo) serves as the historic and administrative capital of Sanaag Region within the Republic of Somaliland. It is renowned across the Horn of Africa for its cool mountain microclimate, lush evergreen pastures, and Somaliland’s highest peaks, led by Mount Surud (Shimbiris at 2,450m) and Mount Sheed.'}
              </p>
              <p>
                {lang === 'so'
                  ? 'Magaalada waxaa ku teedsan keymaha qadiimiga ah ee Daalo (Daalo National Forest Reserve) oo leh noocyo dhir iyo xayawaan ah oo aan meel kale laga helin. Waxay xarun ganacsi iyo xiriir u tahay dekedda qadiimiga ah ee Maydh ee badda Cas, iyadoo xudun u ah ganacsiga xoolaha, fooxa iyo beeyada qaaliga ah ee Sanaag.'
                  : 'The municipality borders the ancient misty juniper escarpment of Daalo National Forest, possessing rare endemic biodiversity. Ceerigaabo connects directly through high mountain passes to the historic Red Sea port of Maydh, serving as the trading nexus for frankincense, myrrh, and livestock.'}
              </p>
              <p>
                {lang === 'so'
                  ? 'Maanta, Dawladda Hoose ee Degmada Ceerigaabo oo kaashanaysa Golaha Deegaanka waxay u taagan tahay inay magaalada u horseeddo horumar casri ah: waddooyin laami ah oo isku xira xaafadaha, nidaam hufan oo maareynta qashinka, iyo adeegyo dowladnimo oo digital ah oo dadweynaha u fududeynaya nolosha.'
                  : 'Today, the Municipality of Ceerigaabo together with the District Council champions modern civic renewal: asphalt boulevards across all wards, environmentally safe sanitation, and accessible digital civic portals for all residents.'}
              </p>
            </div>

            {/* Quick Facts Strip */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 pt-6 border-t border-slate-200 dark:border-slate-800">
              <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-lg">
                <span className="text-xs text-slate-500 dark:text-slate-400 block">{lang === 'so' ? 'Gobolka' : 'Region'}</span>
                <span className="text-sm font-bold text-slate-900 dark:text-white">Gobolka Sanaag</span>
              </div>
              <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-lg">
                <span className="text-xs text-slate-500 dark:text-slate-400 block">{lang === 'so' ? 'Golaha Deegaanka' : 'City Council'}</span>
                <span className="text-sm font-bold text-slate-900 dark:text-white">{DISTRICT_HISTORY.councilMembers} Xildhibaan</span>
              </div>
              <div className="p-3 bg-slate-50 dark:bg-slate-800/60 rounded-lg">
                <span className="text-xs text-slate-500 dark:text-slate-400 block">{lang === 'so' ? 'Joogga Badda' : 'Elevation'}</span>
                <span className="text-sm font-bold text-slate-900 dark:text-white">1,788 m (5,866 ft)</span>
              </div>
            </div>
          </div>

          {/* Landscape / Mountain Imagery */}
          <div className="lg:col-span-5 flex flex-col">
            <div className="relative rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 shadow-lg flex-1 min-h-[300px]">
              <img
                src="/src/assets/images/ceerigaabo_daalo_landscape_1794032957917.jpg"
                alt="Keymaha Daalo & Buurta Surud ee Ceerigaabo"
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent flex flex-col justify-end p-5">
                <span className="text-xs uppercase tracking-wider text-amber-400 font-semibold">
                  {lang === 'so' ? 'Dhaxalka Dabiiciga ah' : 'Natural Heritage'}
                </span>
                <h4 className="text-lg font-bold text-white mt-1">
                  {lang === 'so' ? 'Keymaha Daalo & Buurta Surud' : 'Daalo Escarpment & Mount Surud'}
                </h4>
                <p className="text-xs text-slate-300 mt-1">
                  {lang === 'so' ? 'Barta ugu sarreysa Jamhuuriyadda Somaliland (2,450m), Ceerigaabo' : 'Highest elevation peak in Somaliland, Ceerigaabo'}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Mission, Vision, and Values Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Vision */}
          <div className="bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 rounded-xl p-6">
            <div className="w-10 h-10 rounded-lg bg-emerald-100 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-400 flex items-center justify-center mb-4">
              <Eye className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white font-display">
              {lang === 'so' ? 'Aragtidayada (Vision)' : 'Our Vision'}
            </h3>
            <p className="mt-2 text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
              {lang === 'so'
                ? 'In Ceerigaabo noqoto magaalo casri ah, cagaaran, dalxiis leh, oo leh kaabayaal dhaqaale oo tayo sare leh iyo adeegyo dawladeed oo hufan.'
                : 'To position Ceerigaabo as an exemplary, green, eco-tourism mountain metropolis with resilient civic infrastructure and transparent municipal service.'}
            </p>
          </div>

          {/* Mission */}
          <div className="bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 rounded-xl p-6">
            <div className="w-10 h-10 rounded-lg bg-sky-100 dark:bg-sky-950/80 text-sky-700 dark:text-sky-400 flex items-center justify-center mb-4">
              <Target className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white font-display">
              {lang === 'so' ? 'Hadafkayaga (Mission)' : 'Our Mission'}
            </h3>
            <p className="mt-2 text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
              {lang === 'so'
                ? 'Bixinta adeegyo degmo oo tayo leh, horumarinta waddooyinka iyo nadaafadda, dhiirrigelinta ganacsiga maxalliga ah, iyo maamul ku dhisan caddaalad iyo sharciga.'
                : 'Delivering exceptional municipal services, expanding road and sanitation networks, championing local entrepreneurship, and upholding transparent rule of law.'}
            </p>
          </div>

          {/* Values */}
          <div className="bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 rounded-xl p-6">
            <div className="w-10 h-10 rounded-lg bg-amber-100 dark:bg-amber-950/80 text-amber-700 dark:text-amber-400 flex items-center justify-center mb-4">
              <Shield className="w-5 h-5" />
            </div>
            <h3 className="text-lg font-bold text-slate-900 dark:text-white font-display">
              {lang === 'so' ? 'Qiyamka Asaasiga ah' : 'Core Values'}
            </h3>
            <ul className="mt-3 space-y-2 text-sm text-slate-600 dark:text-slate-300">
              <li className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{lang === 'so' ? 'Hufnaan & Daahfurnaan (Transparency)' : 'Integrity & Transparency'}</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{lang === 'so' ? 'Caddaalad & Sinnaan (Social Justice)' : 'Equity & Civic Fairness'}</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{lang === 'so' ? 'Wadashaqeyn Bulsho (Community Trust)' : 'Community Collaboration'}</span>
              </li>
              <li className="flex items-center gap-2">
                <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                <span>{lang === 'so' ? 'Ilaalinta Deegaanka & Nadaafadda' : 'Environmental Stewardship'}</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Wards / Xaafadaha Degmada */}
        <div className="mt-12 p-6 rounded-xl bg-slate-100/70 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800">
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-800 dark:text-emerald-400 uppercase tracking-wider mb-2">
            <MapPin className="w-4 h-4" />
            <span>{lang === 'so' ? 'Xaafadaha Degmada Ceerigaabo' : 'District Wards & Administrative Zones'}</span>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-3 mt-3">
            {DISTRICT_HISTORY.wards.map((ward, idx) => (
              <div key={idx} className="bg-white dark:bg-slate-900 px-3.5 py-2.5 rounded-lg border border-slate-200 dark:border-slate-800 text-center text-sm font-semibold text-slate-800 dark:text-slate-200">
                {ward}
              </div>
            ))}
          </div>
        </div>

        {/* Official Somaliland Flag & Sovereignty Feature Card */}
        <div className="mt-8 p-6 rounded-2xl bg-gradient-to-r from-emerald-950 via-slate-900 to-slate-950 border border-emerald-800/50 text-white shadow-md">
          <div className="flex flex-col md:flex-row items-center gap-6 justify-between">
            <div className="flex items-center gap-5">
              <SomalilandFlag size="xl" className="shadow-lg shrink-0" />
              <div>
                <div className="flex items-center gap-2 text-emerald-400 text-xs font-semibold uppercase tracking-wider">
                  <Flag className="w-3.5 h-3.5" />
                  <span>{lang === 'so' ? 'Calanka Jamhuuriyadda Somaliland' : 'Flag of the Republic of Somaliland'}</span>
                </div>
                <h4 className="text-xl font-bold font-display text-white mt-1">
                  {lang === 'so' ? 'Midabada Sharafta Qaranka Somaliland' : 'National Sovereign Colors of Somaliland'}
                </h4>
                <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-xl leading-relaxed">
                  {lang === 'so'
                    ? 'Cagaarka kor ku xardhan Tawxiidka (Laa Ilaaha Illallaah Muxammadur Rasuulullaah), Caddaan dhexda kaga yaal Xiddigta Madow ee shanta gees leh, iyo Casaanka hoose ee u taagan dhiigga halgamayaashii xornimada.'
                    : 'The green stripe bearing the Islamic Shahada creed in white, the white center stripe with a 5-pointed black star, and the red lower stripe commemorating the historical sacrifice for sovereignty.'}
                </p>
              </div>
            </div>

            <div className="text-center md:text-right shrink-0">
              <span className="inline-block px-3 py-1 rounded bg-emerald-900/60 border border-emerald-700/60 text-emerald-300 text-xs font-semibold">
                {lang === 'so' ? 'Gobolka Sanaag · Somaliland' : 'Sanaag Region · Somaliland'}
              </span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

import React, { useState } from 'react';
import { Language, NewsItem } from '../types';
import { 
  Newspaper, 
  Search, 
  Calendar, 
  FileText, 
  AlertCircle, 
  ChevronRight, 
  Share2,
  Printer,
  X
} from 'lucide-react';

interface NewsSectionProps {
  lang: Language;
  newsItems: NewsItem[];
}

export const NewsSection: React.FC<NewsSectionProps> = ({
  lang,
  newsItems
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [activeModalItem, setActiveModalItem] = useState<NewsItem | null>(null);

  const filteredNews = newsItems.filter((item) => {
    const matchesCat = selectedCategory === 'all' || item.category === selectedCategory;
    const query = searchQuery.toLowerCase();
    const matchesQuery = 
      item.titleSo.toLowerCase().includes(query) ||
      item.titleEn.toLowerCase().includes(query) ||
      item.summarySo.toLowerCase().includes(query) ||
      item.summaryEn.toLowerCase().includes(query) ||
      (item.referenceNo && item.referenceNo.toLowerCase().includes(query));
    return matchesCat && matchesQuery;
  });

  const categories = [
    { id: 'all', labelSo: 'Dhammaan', labelEn: 'All' },
    { id: 'wareegto', labelSo: 'Wareegtooyin', labelEn: 'Official Decrees' },
    { id: 'tartan', labelSo: 'Tartannada Qandaraaska', labelEn: 'Tenders & Bids' },
    { id: 'ogeysiis', labelSo: 'Ogeysiisyo Dadweyne', labelEn: 'Public Notices' },
    { id: 'mashruuc', labelSo: 'Wararka Mashaariicda', labelEn: 'Project News' }
  ];

  return (
    <section id="news" className="py-16 sm:py-20 bg-slate-50 dark:bg-slate-900/60 border-b border-slate-200 dark:border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-emerald-800 dark:text-emerald-400 tracking-wider uppercase">
              <Newspaper className="w-4 h-4 text-emerald-800 dark:text-emerald-400" />
              <span>{lang === 'so' ? 'Xafiiska Warfaafinta' : 'Municipal Press Office'}</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-slate-900 dark:text-white font-display mt-2">
              {lang === 'so' ? 'Wararka, Wareegtooyinka & Ogeysiisyada' : 'News, Decrees & Public Tenders'}
            </h2>
            <p className="mt-2 text-base text-slate-600 dark:text-slate-300 max-w-2xl">
              {lang === 'so'
                ? 'Kala soco halkan go’aamada Golaha Deegaanka, wareegtooyinka Duqa Degmada, tartannada qandaraasyada, iyo warbixinnada bulshada.'
                : 'Official announcements, Mayoral decrees, procurement notices, and district civic bulletins.'}
            </p>
          </div>
        </div>

        {/* Filter and Search */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 mb-8">
          <div className="flex items-center gap-1.5 overflow-x-auto pb-2 sm:pb-0 no-scrollbar">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer border ${
                  selectedCategory === cat.id
                    ? 'bg-emerald-800 dark:bg-emerald-700 text-white border-emerald-800 dark:border-emerald-700 shadow-xs'
                    : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-100'
                }`}
              >
                {lang === 'so' ? cat.labelSo : cat.labelEn}
              </button>
            ))}
          </div>

          <div className="relative min-w-[260px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={lang === 'so' ? 'Raadi wararka ama tixraaca...' : 'Search bulletins or ref code...'}
              className="w-full pl-9 pr-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white text-xs sm:text-sm focus:ring-2 focus:ring-emerald-500 outline-hidden"
            />
          </div>
        </div>

        {/* News Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredNews.map((item) => (
            <article
              key={item.id}
              onClick={() => setActiveModalItem(item)}
              className="group bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 shadow-xs hover:border-emerald-600 dark:hover:border-emerald-500 hover:shadow-md transition-all cursor-pointer flex flex-col justify-between"
            >
              <div>
                {/* Meta header (Zero-Pill clean text) */}
                <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mb-3">
                  <span className="font-semibold text-emerald-800 dark:text-emerald-400">
                    {lang === 'so' ? item.categoryLabelSo : item.categoryLabelEn}
                  </span>
                  <span aria-hidden="true">·</span>
                  <span className="flex items-center gap-1 font-mono">
                    <Calendar className="w-3.5 h-3.5 text-slate-400" />
                    <span>{item.date}</span>
                  </span>
                  {item.referenceNo && (
                    <>
                      <span aria-hidden="true">·</span>
                      <span className="font-mono text-slate-400 text-[11px] truncate max-w-[130px]">{item.referenceNo}</span>
                    </>
                  )}
                </div>

                <h3 className="text-lg font-bold text-slate-900 dark:text-white font-display group-hover:text-emerald-800 dark:group-hover:text-emerald-400 transition-colors leading-snug">
                  {lang === 'so' ? item.titleSo : item.titleEn}
                </h3>

                <p className="mt-2.5 text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed line-clamp-3">
                  {lang === 'so' ? item.summarySo : item.summaryEn}
                </p>
              </div>

              <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between text-xs">
                <span className="text-emerald-800 dark:text-emerald-400 font-semibold group-hover:underline flex items-center gap-1">
                  <span>{lang === 'so' ? 'Aqri Qoraalka Buuxa' : 'Read Full Release'}</span>
                  <ChevronRight className="w-3.5 h-3.5 transform group-hover:translate-x-1 transition-transform" />
                </span>
                {item.isUrgent && (
                  <span className="text-amber-600 dark:text-amber-400 font-medium flex items-center gap-1">
                    <AlertCircle className="w-3.5 h-3.5" />
                    <span>{lang === 'so' ? 'Muhiim' : 'Official Notice'}</span>
                  </span>
                )}
              </div>
            </article>
          ))}
        </div>

        {filteredNews.length === 0 && (
          <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
            <p className="text-sm text-slate-500">
              {lang === 'so' ? 'Wax war ah lagama helin baaritaankaaga.' : 'No bulletins found matching your filter.'}
            </p>
          </div>
        )}
      </div>

      {/* Full News Reader Modal */}
      {activeModalItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl relative p-6 sm:p-8">
            <button
              onClick={() => setActiveModalItem(null)}
              className="absolute top-4 right-4 p-2 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Modal Header */}
            <div className="mb-6 pb-4 border-b border-slate-200 dark:border-slate-800 pr-8">
              <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mb-2">
                <span className="font-semibold text-emerald-800 dark:text-emerald-400">
                  {lang === 'so' ? activeModalItem.categoryLabelSo : activeModalItem.categoryLabelEn}
                </span>
                <span aria-hidden="true">·</span>
                <span>{activeModalItem.date}</span>
                {activeModalItem.referenceNo && (
                  <>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono text-slate-400">{activeModalItem.referenceNo}</span>
                  </>
                )}
              </div>

              <h3 className="text-xl sm:text-2xl font-bold text-slate-900 dark:text-white font-display leading-snug">
                {lang === 'so' ? activeModalItem.titleSo : activeModalItem.titleEn}
              </h3>
            </div>

            {/* Content Body */}
            <div className="prose dark:prose-invert max-w-none text-slate-700 dark:text-slate-300 text-sm sm:text-base leading-relaxed space-y-4">
              <p className="font-medium text-slate-900 dark:text-slate-100 italic bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200/80 dark:border-slate-700">
                {lang === 'so' ? activeModalItem.summarySo : activeModalItem.summaryEn}
              </p>
              <p className="whitespace-pre-line">
                {lang === 'so' ? activeModalItem.contentSo : activeModalItem.contentEn}
              </p>
            </div>

            {/* Official Stamp & Signoff */}
            <div className="mt-8 pt-6 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between text-xs text-slate-500">
              <div>
                <span className="font-bold text-slate-800 dark:text-slate-200 block">
                  {lang === 'so' ? 'Xafiiska Warfaafinta & Xiriirka Bulshada' : 'Public Information & Communications Bureau'}
                </span>
                <span>Dawladda Hoose ee Degmada Ceerigaabo · Jamhuuriyadda Somaliland</span>
              </div>
              <button
                onClick={() => window.print()}
                className="px-3 py-1.5 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 flex items-center gap-1.5 cursor-pointer"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>{lang === 'so' ? 'Daabaco' : 'Print'}</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};

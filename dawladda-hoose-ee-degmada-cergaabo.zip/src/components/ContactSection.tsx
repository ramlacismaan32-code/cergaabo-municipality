import React, { useState } from 'react';
import { Language } from '../types';
import { 
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  Send, 
  Check, 
  Building, 
  ShieldAlert,
  Navigation
} from 'lucide-react';
import { SomalilandFlag } from './SomalilandFlag';

interface ContactSectionProps {
  lang: Language;
}

export const ContactSection: React.FC<ContactSectionProps> = ({ lang }) => {
  const [activePin, setActivePin] = useState<string>('cityhall');
  const [formSent, setFormSent] = useState<boolean>(false);
  const [contactForm, setContactForm] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormSent(true);
    setTimeout(() => {
      setFormSent(false);
      setContactForm({ name: '', email: '', phone: '', subject: '', message: '' });
    }, 3000);
  };

  const mapLocations = [
    {
      id: 'cityhall',
      nameSo: 'Xarunta Dawladda Hoose ee Ceerigaabo',
      nameEn: 'Ceerigaabo Municipal Headquarters',
      descSo: 'Xafiiska Duqa Degmada, Hoolka Golaha, iyo Adeegyada Shacabka',
      descEn: 'Mayor’s Office, City Council Hall & Public Services',
      coords: 'Bartamaha Xaafadda Daalo'
    },
    {
      id: 'market',
      nameSo: 'Suuqa Weyn ee Degmada Ceerigaabo',
      nameEn: 'Ceerigaabo Grand Central Bazaar',
      descSo: 'Suuqa Ganacsiga, Dharka, Khudaarta & Sayladda Xoolaha',
      descEn: 'Commercial shopping, food markets & livestock trading',
      coords: 'Wadada Wadnaha'
    },
    {
      id: 'palace',
      nameSo: 'Keymaha Daalo & Buurta Surud',
      nameEn: 'Daalo National Forest & Mount Surud',
      descSo: 'Xarunta Dabiiciga ah, Dalxiiska iyo Barta ugu Sarreysa Jamhuuriyadda Somaliland (2,450m)',
      descEn: 'National Nature Reserve and highest peak in Somaliland',
      coords: 'Waqooyiga Ceerigaabo'
    },
    {
      id: 'hospital',
      nameSo: 'Isbitaalka Guud ee Gobolka Sanaag (Ceerigaabo)',
      nameEn: 'Ceerigaabo Regional General Hospital',
      descSo: 'Xarunta Guud ee Caafimaadka iyo Qaybta Gurmadka',
      descEn: 'Regional referral hospital & emergency care',
      coords: 'Wadada Isbitaalka, Dayaxa'
    }
  ];

  return (
    <section id="contact" className="py-16 sm:py-20 bg-slate-50 dark:bg-slate-900/60 border-b border-slate-200 dark:border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Section Header */}
        <div className="max-w-3xl mb-12">
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-800 dark:text-emerald-400 tracking-wider uppercase">
            <MapPin className="w-4 h-4 text-emerald-800 dark:text-emerald-400" />
            <span>{lang === 'so' ? 'Xiriirka & Goobta' : 'Contact & District Location'}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-slate-900 dark:text-white font-display mt-2">
            {lang === 'so' ? 'Xiriirka Dawladda Hoose ee Ceerigaabo' : 'Connect with Ceerigaabo Municipality'}
          </h2>
          <p className="mt-3 text-base text-slate-600 dark:text-slate-300">
            {lang === 'so'
              ? 'Waxaan diyaar u nahay inaan kugu soo dhoweyno xarunta dowladda hoose ee Ceerigaabo ama aan kaga jawaabno wicitaannada iyo farriimahaaga.'
              : 'Our municipal support desk and directorates welcome your inquiries, feedback, and official visits.'}
          </p>
        </div>

        {/* 2-Column: Directory Cards & Contact Form */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-16">
          {/* Left Column: Direct Official Contact Info */}
          <div className="lg:col-span-5 space-y-6">
            <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs space-y-5">
              <h3 className="text-lg font-bold text-slate-900 dark:text-white font-display">
                {lang === 'so' ? 'Cinwaanka Rasmiga ah' : 'Official Municipal Address'}
              </h3>

              <div className="flex items-start gap-3.5 text-xs sm:text-sm text-slate-700 dark:text-slate-300">
                <div className="p-2.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-400 shrink-0">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <strong className="text-slate-900 dark:text-white block font-semibold mb-0.5">
                    {lang === 'so' ? 'Xarunta Dawladda Hoose ee Ceerigaabo' : 'Ceerigaabo City Hall'}
                  </strong>
                  <span>Wadada Dawladda Hoose, Xaafadda Daalo</span>
                  <span className="block text-slate-500">Ceerigaabo, Gobolka Sanaag</span>
                </div>
              </div>

              <div className="flex items-start gap-3.5 text-xs sm:text-sm text-slate-700 dark:text-slate-300">
                <div className="p-2.5 rounded-lg bg-sky-50 dark:bg-sky-950/80 text-sky-700 dark:text-sky-400 shrink-0">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <strong className="text-slate-900 dark:text-white block font-semibold mb-0.5">
                    {lang === 'so' ? 'Khidmadaha Telefoonka' : 'Telephone Lines'}
                  </strong>
                  <span>Xafiiska Guud: <strong className="font-mono text-slate-900 dark:text-white">+252 63 446 8000</strong></span>
                  <span className="block text-amber-600 dark:text-amber-400 font-semibold">
                    Gurmadka Degdegga ah: 888 (Bilaash)
                  </span>
                </div>
              </div>

              <div className="flex items-start gap-3.5 text-xs sm:text-sm text-slate-700 dark:text-slate-300">
                <div className="p-2.5 rounded-lg bg-indigo-50 dark:bg-indigo-950/80 text-indigo-700 dark:text-indigo-400 shrink-0">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <strong className="text-slate-900 dark:text-white block font-semibold mb-0.5">
                    {lang === 'so' ? 'Iimaylka Rasmiga ah' : 'Official Inquiries'}
                  </strong>
                  <span>info@degmadaceerigaabo.so</span>
                  <span className="block text-slate-500">mayor@degmadaceerigaabo.so</span>
                </div>
              </div>

              <div className="flex items-start gap-3.5 text-xs sm:text-sm text-slate-700 dark:text-slate-300">
                <div className="p-2.5 rounded-lg bg-amber-50 dark:bg-amber-950/80 text-amber-700 dark:text-amber-400 shrink-0">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <strong className="text-slate-900 dark:text-white block font-semibold mb-0.5">
                    {lang === 'so' ? 'Saacadaha Shaqada' : 'Operational Hours'}
                  </strong>
                  <span>{lang === 'so' ? 'Sabti - Khamiis: 7:30 AM - 1:30 PM' : 'Saturday – Thursday: 7:30 AM – 1:30 PM'}</span>
                  <span className="block text-slate-500">{lang === 'so' ? 'Jimce: Xafiisyadu waa xiran yihiin' : 'Friday: Closed for official weekend'}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Contact Message Form */}
          <div className="lg:col-span-7 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xs">
            <h3 className="text-xl font-bold text-slate-900 dark:text-white font-display mb-2">
              {lang === 'so' ? 'Noo Soo Dir Farriin / Su’aal' : 'Send us an Official Message'}
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 mb-6">
              {lang === 'so'
                ? 'Saraakiisha dowladda hoose ayaa kaga soo jawaabi doona iimaylkaaga ama taleefankaaga muddo 24 saac gudahood ah.'
                : 'Our civic communications department processes every inquiry and responds promptly.'}
            </p>

            {formSent ? (
              <div className="py-12 text-center space-y-3">
                <div className="w-12 h-12 rounded-full bg-emerald-100 dark:bg-emerald-950 text-emerald-800 dark:text-emerald-400 flex items-center justify-center mx-auto">
                  <Check className="w-7 h-7" />
                </div>
                <h4 className="text-lg font-bold text-slate-900 dark:text-white font-display">
                  {lang === 'so' ? 'Farriintaadu Waa Na Soo Gaartay!' : 'Message Successfully Transmitted!'}
                </h4>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  {lang === 'so' ? 'Waad ku mahadsan tahay la soo xiriirka Dawladda Hoose ee Ceerigaabo, Jamhuuriyadda Somaliland.' : 'Thank you for contacting Ceerigaabo Municipal Council, Republic of Somaliland.'}
                </p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4 text-xs sm:text-sm">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                      {lang === 'so' ? 'Magacaaga' : 'Your Name'} *
                    </label>
                    <input
                      type="text"
                      required
                      value={contactForm.name}
                      onChange={(e) => setContactForm({ ...contactForm, name: e.target.value })}
                      placeholder={lang === 'so' ? 'Magaca oo buuxa' : 'Full Name'}
                      className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                      {lang === 'so' ? 'Lambarka Telefoonka' : 'Phone'} *
                    </label>
                    <input
                      type="tel"
                      required
                      value={contactForm.phone}
                      onChange={(e) => setContactForm({ ...contactForm, phone: e.target.value })}
                      placeholder="+252 90..."
                      className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-hidden"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                      {lang === 'so' ? 'Iimaylkaaga' : 'Email Address'}
                    </label>
                    <input
                      type="email"
                      value={contactForm.email}
                      onChange={(e) => setContactForm({ ...contactForm, email: e.target.value })}
                      placeholder="magac@example.com"
                      className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                      {lang === 'so' ? 'Mawduuca' : 'Subject'} *
                    </label>
                    <input
                      type="text"
                      required
                      value={contactForm.subject}
                      onChange={(e) => setContactForm({ ...contactForm, subject: e.target.value })}
                      placeholder={lang === 'so' ? 'Tusaale: Su’aal ku saabsan canshuurta' : 'e.g. Inquiries regarding property rates'}
                      className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-hidden"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                    {lang === 'so' ? 'Farriintaada' : 'Message'} *
                  </label>
                  <textarea
                    required
                    rows={4}
                    value={contactForm.message}
                    onChange={(e) => setContactForm({ ...contactForm, message: e.target.value })}
                    placeholder={lang === 'so' ? 'Qor waxa aad u baahan tahay si hufan...' : 'Write your detailed message here...'}
                    className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-hidden"
                  />
                </div>

                <div className="flex justify-end">
                  <button
                    type="submit"
                    className="px-6 py-2.5 rounded-lg bg-emerald-800 hover:bg-emerald-900 text-white font-semibold text-xs sm:text-sm flex items-center gap-2 cursor-pointer shadow-xs"
                  >
                    <Send className="w-4 h-4" />
                    <span>{lang === 'so' ? 'Dir Farriinta' : 'Transmit Message'}</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>

        {/* Interactive District Map Visual Card */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
            <div>
              <div className="flex items-center gap-2 text-xs font-semibold text-emerald-800 dark:text-emerald-400 uppercase tracking-wider">
                <Navigation className="w-4 h-4" />
                <div className="flex items-center gap-1.5">
                  <SomalilandFlag size="xs" />
                  <span>{lang === 'so' ? 'Khariidadda Degmada Ceerigaabo' : 'Ceerigaabo Municipal Topographical Layout'}</span>
                </div>
              </div>
              <h3 className="text-xl font-bold text-slate-900 dark:text-white font-display mt-1">
                {lang === 'so' ? 'Xarumaha Muhiimka ah ee Magaalada Ceerigaabo' : 'Key Civic Landmarks & Facilities'}
              </h3>
            </div>

            {/* Quick interactive Pin Switchers */}
            <div className="flex flex-wrap items-center gap-1.5">
              {mapLocations.map((loc) => (
                <button
                  key={loc.id}
                  onClick={() => setActivePin(loc.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer border ${
                    activePin === loc.id
                      ? 'bg-emerald-800 text-white border-emerald-800 shadow-xs'
                      : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-200'
                  }`}
                >
                  {lang === 'so' ? loc.nameSo.split(' ')[0] + ' ' + (loc.nameSo.split(' ')[1] || '') : loc.nameEn.split(' ')[0]}
                </button>
              ))}
            </div>
          </div>

          {/* Styled SVG Map Simulation */}
          <div className="relative w-full h-80 sm:h-96 rounded-xl overflow-hidden bg-slate-950 border border-slate-800 flex items-center justify-center p-4">
            {/* Background Grid Pattern */}
            <div 
              className="absolute inset-0 opacity-20"
              style={{
                backgroundImage: 'radial-gradient(#38bdf8 1px, transparent 1px)',
                backgroundSize: '24px 24px'
              }}
            />

            {/* Road network vectors */}
            <svg className="absolute inset-0 w-full h-full" viewBox="0 0 800 400" preserveAspectRatio="none">
              {/* Wadada Burco - Ceerigaabo - Maydh Highway */}
              <path d="M 50 350 L 250 250 L 400 200 L 580 140 L 750 60" stroke="#f59e0b" strokeWidth="6" strokeLinecap="round" opacity="0.6" />
              <path d="M 50 350 L 250 250 L 400 200 L 580 140 L 750 60" stroke="#ffffff" strokeWidth="1.5" strokeDasharray="8 6" opacity="0.8" />
              
              {/* Secondary Cross Avenues */}
              <path d="M 200 80 L 250 250 L 320 380" stroke="#334155" strokeWidth="4" strokeLinecap="round" />
              <path d="M 380 40 L 400 200 L 450 360" stroke="#334155" strokeWidth="4" strokeLinecap="round" />
              <path d="M 500 370 L 580 140 L 650 40" stroke="#334155" strokeWidth="4" strokeLinecap="round" />
              
              {/* Inner City Ring Road */}
              <circle cx="400" cy="200" r="90" stroke="#10b981" strokeWidth="2.5" strokeDasharray="4 4" fill="none" opacity="0.5" />
            </svg>

            {/* Pins on map */}
            {/* 1. City Hall */}
            <div 
              onClick={() => setActivePin('cityhall')}
              className={`absolute top-[42%] left-[48%] -translate-x-1/2 -translate-y-1/2 cursor-pointer transition-transform duration-300 ${
                activePin === 'cityhall' ? 'scale-125 z-30' : 'scale-100 z-10 hover:scale-110'
              }`}
            >
              <div className="relative flex flex-col items-center">
                <div className={`p-2.5 rounded-full shadow-lg ${activePin === 'cityhall' ? 'bg-emerald-500 text-white ring-4 ring-emerald-400/40' : 'bg-slate-800 text-emerald-400 border border-emerald-500'}`}>
                  <Building className="w-5 h-5" />
                </div>
                <span className="mt-1 px-2 py-0.5 rounded text-[10px] font-bold bg-slate-900/90 text-white whitespace-nowrap border border-slate-700">
                  {lang === 'so' ? 'Dawladda Hoose' : 'City Hall'}
                </span>
              </div>
            </div>

            {/* 2. Grand Market */}
            <div 
              onClick={() => setActivePin('market')}
              className={`absolute top-[58%] left-[34%] -translate-x-1/2 -translate-y-1/2 cursor-pointer transition-transform duration-300 ${
                activePin === 'market' ? 'scale-125 z-30' : 'scale-100 z-10 hover:scale-110'
              }`}
            >
              <div className="relative flex flex-col items-center">
                <div className={`p-2.5 rounded-full shadow-lg ${activePin === 'market' ? 'bg-amber-500 text-white ring-4 ring-amber-400/40' : 'bg-slate-800 text-amber-400 border border-amber-500'}`}>
                  <MapPin className="w-5 h-5" />
                </div>
                <span className="mt-1 px-2 py-0.5 rounded text-[10px] font-bold bg-slate-900/90 text-white whitespace-nowrap border border-slate-700">
                  {lang === 'so' ? 'Suuqa Weyn' : 'Central Bazaar'}
                </span>
              </div>
            </div>

            {/* 3. Palace */}
            <div 
              onClick={() => setActivePin('palace')}
              className={`absolute top-[30%] left-[68%] -translate-x-1/2 -translate-y-1/2 cursor-pointer transition-transform duration-300 ${
                activePin === 'palace' ? 'scale-125 z-30' : 'scale-100 z-10 hover:scale-110'
              }`}
            >
              <div className="relative flex flex-col items-center">
                <div className={`p-2.5 rounded-full shadow-lg ${activePin === 'palace' ? 'bg-indigo-500 text-white ring-4 ring-indigo-400/40' : 'bg-slate-800 text-indigo-400 border border-indigo-500'}`}>
                  <Building className="w-5 h-5" />
                </div>
                <span className="mt-1 px-2 py-0.5 rounded text-[10px] font-bold bg-slate-900/90 text-white whitespace-nowrap border border-slate-700">
                  {lang === 'so' ? 'Daarta Boqorka' : 'Royal Palace'}
                </span>
              </div>
            </div>

            {/* 4. Hospital */}
            <div 
              onClick={() => setActivePin('hospital')}
              className={`absolute top-[65%] left-[62%] -translate-x-1/2 -translate-y-1/2 cursor-pointer transition-transform duration-300 ${
                activePin === 'hospital' ? 'scale-125 z-30' : 'scale-100 z-10 hover:scale-110'
              }`}
            >
              <div className="relative flex flex-col items-center">
                <div className={`p-2.5 rounded-full shadow-lg ${activePin === 'hospital' ? 'bg-red-500 text-white ring-4 ring-red-400/40' : 'bg-slate-800 text-red-400 border border-red-500'}`}>
                  <MapPin className="w-5 h-5" />
                </div>
                <span className="mt-1 px-2 py-0.5 rounded text-[10px] font-bold bg-slate-900/90 text-white whitespace-nowrap border border-slate-700">
                  {lang === 'so' ? 'Isbitaalka Guud' : 'General Hospital'}
                </span>
              </div>
            </div>

            {/* Active Pin Detailed Info Card (floating bottom) */}
            {activePin && (
              <div className="absolute bottom-4 left-4 right-4 sm:left-auto sm:right-4 sm:max-w-xs p-3.5 rounded-xl bg-slate-900/95 border border-slate-700 backdrop-blur-md text-white text-xs z-40 shadow-xl">
                {(() => {
                  const loc = mapLocations.find(l => l.id === activePin) || mapLocations[0];
                  return (
                    <div>
                      <div className="flex items-center gap-1.5 text-emerald-400 font-semibold mb-0.5">
                        <MapPin className="w-3.5 h-3.5" />
                        <span>{loc.coords}</span>
                      </div>
                      <h5 className="font-bold text-sm text-white">{lang === 'so' ? loc.nameSo : loc.nameEn}</h5>
                      <p className="text-slate-300 mt-1">{lang === 'so' ? loc.descSo : loc.descEn}</p>
                    </div>
                  );
                })()}
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

import React, { useState } from 'react';
import { Language } from '../types';
import { MAYOR_DATA } from '../data/municipalData';
import { 
  Building, 
  Calendar, 
  Check, 
  FileText, 
  Mail, 
  Phone, 
  Quote, 
  Send, 
  User, 
  Users,
  Award
} from 'lucide-react';
import { SomalilandFlag } from './SomalilandFlag';

interface MayorSectionProps {
  lang: Language;
}

export const MayorSection: React.FC<MayorSectionProps> = ({ lang }) => {
  const [showAppointmentModal, setShowAppointmentModal] = useState(false);
  const [submittedAppointment, setSubmittedAppointment] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    organization: '',
    topic: '',
    preferredDate: ''
  });

  const handleAppointmentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmittedAppointment(true);
    setTimeout(() => {
      setSubmittedAppointment(false);
      setShowAppointmentModal(false);
      setFormData({ name: '', phone: '', organization: '', topic: '', preferredDate: '' });
    }, 2500);
  };

  const strategicPillars = [
    {
      titleSo: 'Kaabayaasha & Laamiyada',
      titleEn: 'Urban Paving & Infrastructure',
      descSo: 'Dhameystirka waddooyinka laamiga ah ee isku xira xaafadaha iyo suuqyada.',
      descEn: 'Paving connecting avenues between residential wards and commercial bazaars.'
    },
    {
      titleSo: 'Ceerigaabo Cagaaran & Nadiif ah',
      titleEn: 'Green & Resilient City',
      descSo: 'Nidaam joogto ah oo qashinka lagu maareeyo iyo ilaalinta keymaha Daalo.',
      descEn: 'Modern waste disposal network and protection of the Daalo forest reserve.'
    },
    {
      titleSo: 'Kobaca Ganacsiga & Maalgashiga',
      titleEn: 'Commerce & Investment Growth',
      descSo: 'Fududeynta shatiyada ganacsiga 48 saac gudahood iyo taageerada dhalinyarada.',
      descEn: 'Streamlined 48-hour commercial licensing and empowering youth startups.'
    },
    {
      titleSo: 'Maamul Hufan & Digital ah',
      titleEn: 'Transparent Digital Governance',
      descSo: 'Bixinta dhammaan adeegyada dowladda hoose ee habka casriga ah ee online-ka.',
      descEn: 'End-to-end digital civic applications, municipal receipts, and open tracking.'
    }
  ];

  return (
    <section id="mayor" className="py-16 sm:py-20 bg-slate-50 dark:bg-slate-900/60 border-b border-slate-200 dark:border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Header */}
        <div className="max-w-3xl mb-12">
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-800 dark:text-emerald-400 tracking-wider uppercase">
            <Award className="w-4 h-4 text-emerald-800 dark:text-emerald-400" />
            <span>{lang === 'so' ? 'Hoggaanka Degmada' : "District Leadership"}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-slate-900 dark:text-white font-display mt-2">
            {lang === 'so' ? "Xafiiska Duqa Degmada Ceerigaabo" : "The Mayor's Office"}
          </h2>
          <p className="mt-3 text-base text-slate-600 dark:text-slate-300">
            {lang === 'so' 
              ? 'Farriinta Duqa Degmada, hoggaanka Golaha Deegaanka, iyo qorshayaasha hortabinta u leh horumarinta Ceerigaabo.'
              : 'Official message from the Mayor, Executive Leadership, and strategic urban priorities.'}
          </p>
        </div>

        {/* 2-Column Main Card */}
        <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl shadow-sm overflow-hidden mb-12">
          <div className="grid grid-cols-1 lg:grid-cols-12">
            {/* Left Column: Mayor Profile Card */}
            <div className="lg:col-span-5 p-6 sm:p-8 bg-gradient-to-br from-slate-900 via-slate-900 to-emerald-950 text-white flex flex-col justify-between">
              <div>
                <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-full border-4 border-amber-500/80 p-1 mx-auto lg:mx-0 mb-6 bg-slate-800 overflow-hidden shadow-lg">
                  <div className="w-full h-full rounded-full bg-slate-700 flex items-center justify-center text-amber-300 font-bold text-3xl font-display">
                    CA
                  </div>
                </div>

                <div className="text-center lg:text-left">
                  <div className="flex items-center justify-center lg:justify-start gap-1.5 mb-1">
                    <SomalilandFlag size="xs" />
                    <span className="text-xs uppercase tracking-wider text-amber-400 font-semibold block">
                      {lang === 'so' ? 'Duqa Degmada Ceerigaabo' : 'Mayor of Ceerigaabo'}
                    </span>
                  </div>
                  <h3 className="text-2xl font-bold text-white mt-1 font-display">
                    {lang === 'so' ? MAYOR_DATA.nameSo : MAYOR_DATA.nameEn}
                  </h3>
                  <p className="text-xs text-slate-300 mt-1">
                    {lang === 'so' ? MAYOR_DATA.titleSo : MAYOR_DATA.titleEn}
                  </p>
                </div>

                {/* Quote block */}
                <div className="mt-8 p-4 rounded-xl bg-white/5 border border-white/10 text-xs sm:text-sm text-slate-200 italic relative">
                  <Quote className="w-6 h-6 text-amber-400/40 absolute -top-3 -left-2" />
                  <p className="relative z-10 pl-2">
                    &ldquo;{lang === 'so' ? MAYOR_DATA.welcomeQuoteSo : MAYOR_DATA.welcomeQuoteEn}&rdquo;
                  </p>
                </div>
              </div>

              {/* Action buttons */}
              <div className="mt-8 pt-6 border-t border-white/10 flex flex-col sm:flex-row gap-3">
                <button
                  onClick={() => setShowAppointmentModal(true)}
                  className="w-full py-2.5 px-4 rounded-lg bg-emerald-700 hover:bg-emerald-600 text-white font-medium text-xs sm:text-sm transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-xs"
                >
                  <Calendar className="w-4 h-4" />
                  <span>{lang === 'so' ? 'Ballan Qabso Duqa' : 'Request Appointment'}</span>
                </button>
              </div>
            </div>

            {/* Right Column: Full Official Speech & Priorities */}
            <div className="lg:col-span-7 p-6 sm:p-8 flex flex-col justify-between">
              <div>
                <h4 className="text-lg font-bold text-slate-900 dark:text-white font-display mb-4">
                  {lang === 'so' ? 'Farriinta Soo Dhoweynta ee Duqa Degmada' : "Welcome Address by the Mayor"}
                </h4>
                <div className="prose dark:prose-invert max-w-none text-slate-700 dark:text-slate-300 text-sm sm:text-base leading-relaxed space-y-3 whitespace-pre-line">
                  {lang === 'so' ? MAYOR_DATA.speechSo : MAYOR_DATA.speechEn}
                </div>
              </div>

              {/* Executive Team Strip */}
              <div className="mt-8 pt-6 border-t border-slate-200 dark:border-slate-800 grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-800">
                  <span className="text-[11px] text-slate-500 dark:text-slate-400 block">
                    {lang === 'so' ? MAYOR_DATA.deputyTitleSo : MAYOR_DATA.deputyTitleEn}
                  </span>
                  <span className="text-sm font-bold text-slate-900 dark:text-white">
                    {lang === 'so' ? MAYOR_DATA.deputyNameSo : MAYOR_DATA.deputyNameEn}
                  </span>
                  <span className="text-[11px] text-emerald-800 dark:text-emerald-400 block mt-0.5">
                    deputy@degmadaqardho.so
                  </span>
                </div>

                <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-800/60 border border-slate-200/60 dark:border-slate-800">
                  <span className="text-[11px] text-slate-500 dark:text-slate-400 block">
                    {lang === 'so' ? MAYOR_DATA.executiveSecretaryTitleSo : MAYOR_DATA.executiveSecretaryTitleEn}
                  </span>
                  <span className="text-sm font-bold text-slate-900 dark:text-white">
                    {lang === 'so' ? MAYOR_DATA.executiveSecretarySo : MAYOR_DATA.executiveSecretaryEn}
                  </span>
                  <span className="text-[11px] text-emerald-800 dark:text-emerald-400 block mt-0.5">
                    secretary@degmadaqardho.so
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 4 Strategic Pillars */}
        <div className="mb-6">
          <h3 className="text-xl font-bold text-slate-900 dark:text-white font-display mb-4">
            {lang === 'so' ? '4 Tiir ee Hortabinta u leh Horumarka Degmada' : '4 Strategic Pillars of Urban Development'}
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {strategicPillars.map((pillar, idx) => (
              <div key={idx} className="p-5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-xs">
                <div className="text-emerald-800 dark:text-emerald-400 font-mono font-bold text-xs mb-1">
                  0{idx + 1}.
                </div>
                <h4 className="text-sm sm:text-base font-bold text-slate-900 dark:text-white">
                  {lang === 'so' ? pillar.titleSo : pillar.titleEn}
                </h4>
                <p className="mt-1 text-xs text-slate-600 dark:text-slate-400 leading-relaxed">
                  {lang === 'so' ? pillar.descSo : pillar.descEn}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Appointment Modal */}
      {showAppointmentModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 max-w-lg w-full shadow-2xl relative">
            <h3 className="text-xl font-bold text-slate-900 dark:text-white font-display">
              {lang === 'so' ? 'Codso Ballan Xafiiska Duqa Degmada' : "Request Meeting with the Mayor's Office"}
            </h3>
            <p className="text-xs text-slate-600 dark:text-slate-400 mt-1">
              {lang === 'so'
                ? 'Fadlan buuxi foomkan si xoghaynta Duqa Degmada ay kuu soo xiriiriyaan muddo 24 saacadood gudahood ah.'
                : 'Please complete this form and the Mayoral Secretariat will review and respond within 24 hours.'}
            </p>

            {submittedAppointment ? (
              <div className="my-8 p-6 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 text-center">
                <Check className="w-10 h-10 text-emerald-800 dark:text-emerald-400 mx-auto mb-2" />
                <h4 className="text-base font-bold text-emerald-900 dark:text-emerald-200">
                  {lang === 'so' ? 'Codsigaagii Waa La Diray!' : 'Appointment Request Sent!'}
                </h4>
                <p className="text-xs text-emerald-700 dark:text-emerald-400 mt-1">
                  {lang === 'so' ? 'Xafiiska xoghaynta ayaa kula soo xiriiri doona taleefanka aad reebtay.' : 'The Executive Secretariat will reach out via your provided phone number.'}
                </p>
              </div>
            ) : (
              <form onSubmit={handleAppointmentSubmit} className="mt-4 space-y-3.5 text-xs sm:text-sm">
                <div>
                  <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                    {lang === 'so' ? 'Magacaaga oo Saddexan' : 'Full Name'} *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    placeholder={lang === 'so' ? 'Tusaale: Axmed Cali Xasan' : 'e.g. Ahmed Ali Hassan'}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-hidden"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                      {lang === 'so' ? 'Lambarka Telefoonka' : 'Phone Number'} *
                    </label>
                    <input
                      type="tel"
                      required
                      value={formData.phone}
                      onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                      placeholder="+252 90..."
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                      {lang === 'so' ? 'Uurka / Shirkadda' : 'Organization (Optional)'}
                    </label>
                    <input
                      type="text"
                      value={formData.organization}
                      onChange={(e) => setFormData({ ...formData, organization: e.target.value })}
                      placeholder={lang === 'so' ? 'Shirkad / Urur bulsho' : 'Company / NGO'}
                      className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-hidden"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                    {lang === 'so' ? 'Ujeeddada Ballanta' : 'Purpose of the Meeting'} *
                  </label>
                  <textarea
                    required
                    rows={3}
                    value={formData.topic}
                    onChange={(e) => setFormData({ ...formData, topic: e.target.value })}
                    placeholder={lang === 'so' ? 'Sharaxaad kooban oo ku saabsan mawduuca...' : 'Brief description of the matter to discuss...'}
                    className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-hidden"
                  />
                </div>

                <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200 dark:border-slate-800">
                  <button
                    type="button"
                    onClick={() => setShowAppointmentModal(false)}
                    className="px-4 py-2 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 font-medium cursor-pointer"
                  >
                    {lang === 'so' ? 'Ka noqo' : 'Cancel'}
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 rounded-lg bg-emerald-700 hover:bg-emerald-600 text-white font-semibold flex items-center gap-1.5 cursor-pointer shadow-xs"
                  >
                    <Send className="w-4 h-4" />
                    <span>{lang === 'so' ? 'Gudbi Ballanta' : 'Submit Request'}</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </section>
  );
};

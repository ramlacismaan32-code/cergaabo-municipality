import React, { useState } from 'react';
import { Language, MunicipalService, NewsItem, Project, Department } from '../types';
import { Search, X, ChevronRight, FileText, Newspaper, FolderKanban, Building2 } from 'lucide-react';

interface SearchModalProps {
  lang: Language;
  isOpen: boolean;
  onClose: () => void;
  services: MunicipalService[];
  news: NewsItem[];
  projects: Project[];
  departments: Department[];
  onNavigateToSection: (sectionId: string, itemId?: string) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  lang,
  isOpen,
  onClose,
  services,
  news,
  projects,
  departments,
  onNavigateToSection
}) => {
  const [query, setQuery] = useState('');

  if (!isOpen) return null;

  const q = query.toLowerCase().trim();

  const matchedServices = q ? services.filter(s => 
    s.titleSo.toLowerCase().includes(q) || 
    s.titleEn.toLowerCase().includes(q) || 
    s.descriptionSo.toLowerCase().includes(q)
  ) : [];

  const matchedNews = q ? news.filter(n => 
    n.titleSo.toLowerCase().includes(q) || 
    n.titleEn.toLowerCase().includes(q) || 
    n.summarySo.toLowerCase().includes(q)
  ) : [];

  const matchedProjects = q ? projects.filter(p => 
    p.titleSo.toLowerCase().includes(q) || 
    p.titleEn.toLowerCase().includes(q) || 
    p.location.toLowerCase().includes(q)
  ) : [];

  const matchedDepts = q ? departments.filter(d => 
    d.nameSo.toLowerCase().includes(q) || 
    d.nameEn.toLowerCase().includes(q) ||
    d.directorSo.toLowerCase().includes(q)
  ) : [];

  const totalMatches = matchedServices.length + matchedNews.length + matchedProjects.length + matchedDepts.length;

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center p-4 pt-16 sm:pt-24 bg-slate-950/70 backdrop-blur-xs">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden flex flex-col max-h-[80vh]">
        {/* Search Input Bar */}
        <div className="p-4 border-b border-slate-200 dark:border-slate-800 flex items-center gap-3">
          <Search className="w-5 h-5 text-emerald-600 shrink-0" />
          <input
            type="text"
            autoFocus
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={lang === 'so' ? 'Raadi adeeg, shati, war, mashruuc, ama waax...' : 'Search services, permits, decrees, projects...'}
            className="w-full text-base bg-transparent text-slate-900 dark:text-white placeholder:text-slate-400 outline-hidden"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="text-xs text-slate-400 hover:text-slate-600 cursor-pointer"
            >
              Nadiifi
            </button>
          )}
          <button
            onClick={onClose}
            className="p-1 rounded-md text-slate-400 hover:text-slate-600 dark:hover:text-white cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Results Area */}
        <div className="p-4 overflow-y-auto space-y-6">
          {!q ? (
            <div className="py-8 text-center text-xs text-slate-500">
              {lang === 'so'
                ? 'Geli erey kasta si aad u hesho macluumaadka Dawladda Hoose ee Ceerigaabo.'
                : 'Type to discover civic applications, Mayoral directives, and public works.'}
            </div>
          ) : totalMatches === 0 ? (
            <div className="py-8 text-center text-xs text-slate-500">
              {lang === 'so' ? `Wax natiijo ah lagama helin "${query}".` : `No records found matching "${query}".`}
            </div>
          ) : (
            <>
              {/* Matched Services */}
              {matchedServices.length > 0 && (
                <div>
                  <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-800 dark:text-emerald-400 block mb-2">
                    {lang === 'so' ? 'Adeegyada Degmada' : 'Services'} ({matchedServices.length})
                  </span>
                  <div className="space-y-1.5">
                    {matchedServices.map((svc) => (
                      <div
                        key={svc.id}
                        onClick={() => {
                          onClose();
                          onNavigateToSection('services');
                        }}
                        className="p-2.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800/80 cursor-pointer flex items-center justify-between transition-colors"
                      >
                        <div className="flex items-center gap-2.5">
                          <FileText className="w-4 h-4 text-emerald-700 shrink-0" />
                          <span className="text-xs font-semibold text-slate-900 dark:text-white">
                            {lang === 'so' ? svc.titleSo : svc.titleEn}
                          </span>
                        </div>
                        <span className="text-[11px] text-slate-500 font-mono">{svc.feeSo.split('(')[0]}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Matched News */}
              {matchedNews.length > 0 && (
                <div>
                  <span className="text-[11px] font-bold uppercase tracking-wider text-sky-700 dark:text-sky-400 block mb-2">
                    {lang === 'so' ? 'Wararka & Wareegtooyinka' : 'News & Decrees'} ({matchedNews.length})
                  </span>
                  <div className="space-y-1.5">
                    {matchedNews.map((n) => (
                      <div
                        key={n.id}
                        onClick={() => {
                          onClose();
                          onNavigateToSection('news');
                        }}
                        className="p-2.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800/80 cursor-pointer flex items-center justify-between transition-colors"
                      >
                        <div className="flex items-center gap-2.5">
                          <Newspaper className="w-4 h-4 text-sky-600 shrink-0" />
                          <span className="text-xs font-semibold text-slate-900 dark:text-white">
                            {lang === 'so' ? n.titleSo : n.titleEn}
                          </span>
                        </div>
                        <span className="text-[11px] text-slate-500">{n.date}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Matched Projects */}
              {matchedProjects.length > 0 && (
                <div>
                  <span className="text-[11px] font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400 block mb-2">
                    {lang === 'so' ? 'Mashaariicda' : 'Projects'} ({matchedProjects.length})
                  </span>
                  <div className="space-y-1.5">
                    {matchedProjects.map((p) => (
                      <div
                        key={p.id}
                        onClick={() => {
                          onClose();
                          onNavigateToSection('projects');
                        }}
                        className="p-2.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800/80 cursor-pointer flex items-center justify-between transition-colors"
                      >
                        <div className="flex items-center gap-2.5">
                          <FolderKanban className="w-4 h-4 text-amber-600 shrink-0" />
                          <span className="text-xs font-semibold text-slate-900 dark:text-white">
                            {lang === 'so' ? p.titleSo : p.titleEn}
                          </span>
                        </div>
                        <span className="text-[11px] font-mono font-bold text-emerald-800 dark:text-emerald-400">{p.progress}%</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Matched Departments */}
              {matchedDepts.length > 0 && (
                <div>
                  <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-700 dark:text-indigo-400 block mb-2">
                    {lang === 'so' ? 'Waaxyaha Dawladda' : 'Departments'} ({matchedDepts.length})
                  </span>
                  <div className="space-y-1.5">
                    {matchedDepts.map((d) => (
                      <div
                        key={d.id}
                        onClick={() => {
                          onClose();
                          onNavigateToSection('departments');
                        }}
                        className="p-2.5 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800/80 cursor-pointer flex items-center justify-between transition-colors"
                      >
                        <div className="flex items-center gap-2.5">
                          <Building2 className="w-4 h-4 text-indigo-600 shrink-0" />
                          <span className="text-xs font-semibold text-slate-900 dark:text-white">
                            {lang === 'so' ? d.nameSo : d.nameEn}
                          </span>
                        </div>
                        <span className="text-[11px] text-slate-500">{d.phone}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
};

import React from 'react';

interface SomalilandFlagProps {
  className?: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  rounded?: boolean;
  withBorder?: boolean;
  withShadow?: boolean;
}

export const SomalilandFlag: React.FC<SomalilandFlagProps> = ({
  className = '',
  size = 'md',
  rounded = true,
  withBorder = true,
  withShadow = true,
}) => {
  const sizeClasses = {
    xs: 'w-6 h-3.5',
    sm: 'w-8 h-4.5',
    md: 'w-11 h-6',
    lg: 'w-16 h-9',
    xl: 'w-24 h-13.5',
  };

  return (
    <div
      className={`inline-block overflow-hidden shrink-0 select-none ${
        sizeClasses[size]
      } ${rounded ? 'rounded-xs' : ''} ${
        withBorder ? 'border border-slate-300/80 dark:border-slate-700/80' : ''
      } ${withShadow ? 'shadow-xs' : ''} ${className}`}
      title="Calanka Jamhuuriyadda Somaliland | Flag of Somaliland"
      role="img"
      aria-label="Calanka Somaliland"
    >
      <svg
        viewBox="0 0 600 360"
        className="w-full h-full block"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Top Stripe: Green */}
        <rect width="600" height="120" fill="#138808" />
        
        {/* Shahada / Islamic Creed in White */}
        <g fill="#ffffff" textAnchor="middle">
          {/* Stylized Arabic Calligraphy of the Shahada */}
          <text
            x="300"
            y="76"
            fontFamily="Arial, sans-serif"
            fontWeight="bold"
            fontSize="38"
            letterSpacing="2"
            fill="#ffffff"
          >
            لَا إِلٰهَ إِلَّا الله مُحَمَّدٌ رَسُولُ الله
          </text>
        </g>

        {/* Middle Stripe: White */}
        <rect y="120" width="600" height="120" fill="#ffffff" />

        {/* Centered Black 5-pointed Star */}
        {/* 5-pointed star coordinates centered at (300, 180) with outer radius ~38 */}
        <polygon
          fill="#111827"
          points="
            300,144 
            311,168 
            337,169 
            316,185 
            324,210 
            300,195 
            276,210 
            284,185 
            263,169 
            289,168
          "
        />

        {/* Bottom Stripe: Red */}
        <rect y="240" width="600" height="120" fill="#D21034" />
      </svg>
    </div>
  );
};

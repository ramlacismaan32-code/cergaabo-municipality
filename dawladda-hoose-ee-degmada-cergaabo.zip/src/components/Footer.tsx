import React from 'react';
import { OfficialEmblem } from './OfficialEmblem';
import { Language } from '../types';
import { 
  Phone, 
  Mail, 
  MapPin, 
  Clock, 
  Shield, 
  Heart,
  ChevronRight,
  ExternalLink
} from 'lucide-react';
import { SomalilandFlag } from './SomalilandFlag';

interface FooterProps {
  lang: Language;
  onNavigate: (sectionId: string) => void;
  onOpenAdmin: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  lang,
  onNavigate,
  onOpenAdmin
}) => {
  return (
    <footer className="bg-slate-950 text-slate-300 border-t border-slate-800">
      {/* Upper Footer Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-12 sm:py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-8 lg:gap-12">
          {/* Col 1: Municipal Brand & Mission */}
          <div className="lg:col-span-4 space-y-4">
            <OfficialEmblem size="lg" className="text-white" />
            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed max-w-sm">
              {lang === 'so'
                ? 'Dawladda Hoose ee Degmada Ceerigaabo waxay u taagan tahay bixinta adeegyo hufan, caddaalad ah, iyo horumarinta kaabayaasha dhaqaalaha ee xarunta gobolka Sanaag.'
                : 'Ceerigaabo Local Government is dedicated to delivering transparent civic services, expanding urban infrastructure, and fostering community prosperity across Sanaag.'}
            </p>
            <div className="pt-2 flex items-center gap-2 text-xs text-slate-300 font-medium">
              <SomalilandFlag size="xs" />
              <span>{lang === 'so' ? 'Gobolka Sanaag · Jamhuuriyadda Somaliland' : 'Sanaag Region · Republic of Somaliland'}</span>
            </div>
          </div>

          {/* Col 2: Quick Links */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">
              {lang === 'so' ? 'Bogagga Muhiimka ah' : 'Navigation Links'}
            </h4>
            <ul className="space-y-2 text-xs sm:text-sm text-slate-400">
              <li>
                <button onClick={() => onNavigate('home')} className="hover:text-emerald-400 transition-colors cursor-pointer flex items-center gap-1.5">
                  <ChevronRight className="w-3.5 h-3.5 text-slate-600" />
                  <span>{lang === 'so' ? 'Bogga Hore' : 'Home'}</span>
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('about')} className="hover:text-emerald-400 transition-colors cursor-pointer flex items-center gap-1.5">
                  <ChevronRight className="w-3.5 h-3.5 text-slate-600" />
                  <span>{lang === 'so' ? 'Taariikhda Ceerigaabo' : 'History of Ceerigaabo'}</span>
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('mayor')} className="hover:text-emerald-400 transition-colors cursor-pointer flex items-center gap-1.5">
                  <ChevronRight className="w-3.5 h-3.5 text-slate-600" />
                  <span>{lang === 'so' ? 'Xafiiska Duqa Degmada' : "Mayor's Office"}</span>
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('services')} className="hover:text-emerald-400 transition-colors cursor-pointer flex items-center gap-1.5">
                  <ChevronRight className="w-3.5 h-3.5 text-slate-600" />
                  <span>{lang === 'so' ? 'Adeegyada & Shatiyada' : 'Services & Licensing'}</span>
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('applications')} className="hover:text-emerald-400 transition-colors cursor-pointer flex items-center gap-1.5">
                  <ChevronRight className="w-3.5 h-3.5 text-slate-600" />
                  <span>{lang === 'so' ? 'Codsiyada Online-ka' : 'Online Applications'}</span>
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('projects')} className="hover:text-emerald-400 transition-colors cursor-pointer flex items-center gap-1.5">
                  <ChevronRight className="w-3.5 h-3.5 text-slate-600" />
                  <span>{lang === 'so' ? 'Mashaariicda Horumarinta' : 'Development Projects'}</span>
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Public Services & Citizen Grievance */}
          <div className="lg:col-span-2 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">
              {lang === 'so' ? 'Shacabka' : 'Community'}
            </h4>
            <ul className="space-y-2 text-xs sm:text-sm text-slate-400">
              <li>
                <button onClick={() => onNavigate('complaints')} className="hover:text-emerald-400 transition-colors cursor-pointer">
                  {lang === 'so' ? 'Gudbi Cabasho' : 'File Complaint'}
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('news')} className="hover:text-emerald-400 transition-colors cursor-pointer">
                  {lang === 'so' ? 'Wareegtooyinka' : 'Official Decrees'}
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('news')} className="hover:text-emerald-400 transition-colors cursor-pointer">
                  {lang === 'so' ? 'Qandaraasyada' : 'Public Tenders'}
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('gallery')} className="hover:text-emerald-400 transition-colors cursor-pointer">
                  {lang === 'so' ? 'Sawirrada Ceerigaabo' : 'Photo Gallery'}
                </button>
              </li>
              <li>
                <button onClick={onOpenAdmin} className="text-emerald-400 hover:text-emerald-300 transition-colors cursor-pointer flex items-center gap-1">
                  <span>{lang === 'so' ? 'Albaabka Maamulka' : 'Admin Portal'}</span>
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Hotlines & Emergency */}
          <div className="lg:col-span-3 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white">
              {lang === 'so' ? 'Gurmadka & Xafiisyada' : 'Emergency & Contacts'}
            </h4>
            <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-2 text-xs">
              <div className="flex justify-between items-center text-amber-400 font-bold">
                <span>Gurmadka Degdegga ah:</span>
                <span className="font-mono text-sm">888</span>
              </div>
              <div className="flex justify-between items-center text-slate-300">
                <span>Booliska Ceerigaabo:</span>
                <span className="font-mono">999</span>
              </div>
              <div className="flex justify-between items-center text-slate-300">
                <span>Xafiiska Guud:</span>
                <span className="font-mono">+252 63 446 8000</span>
              </div>
              <div className="pt-2 border-t border-slate-800 text-[11px] text-slate-400">
                <span>Iimayl: info@degmadaceerigaabo.so</span>
              </div>
            </div>

            <div className="text-[11px] text-slate-400 pt-1">
              <span>{lang === 'so' ? 'Saacadaha: Sabti - Khamiis 7:30 AM - 1:30 PM' : 'Hours: Sat - Thu 7:30 AM - 1:30 PM'}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Hairline & Legal Bar */}
      <div className="border-t border-slate-800/80 py-6 px-4 sm:px-6 text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3 text-center sm:text-left">
          <p>
            &copy; 2026 Dawladda Hoose ee Degmada Ceerigaabo. Dhammaan xuquuqda waa dhowran tahay.
          </p>
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-1.5 text-slate-400">
              <SomalilandFlag size="xs" />
              <span>{lang === 'so' ? 'Jamhuuriyadda Somaliland' : 'Republic of Somaliland'}</span>
            </div>
            <span aria-hidden="true">·</span>
            <span>{lang === 'so' ? 'Gobolka Sanaag' : 'Sanaag Region'}</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

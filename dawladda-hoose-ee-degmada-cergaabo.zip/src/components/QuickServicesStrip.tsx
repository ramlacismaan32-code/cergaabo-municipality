import React from 'react';
import { Language } from '../types';
import { 
  Briefcase, 
  Building, 
  Trash2, 
  MapPin, 
  FileCheck, 
  CreditCard,
  ArrowRight
} from 'lucide-react';

interface QuickServicesStripProps {
  lang: Language;
  onSelectService: (serviceId: string) => void;
  onNavigateToServices: () => void;
}

export const QuickServicesStrip: React.FC<QuickServicesStripProps> = ({
  lang,
  onSelectService,
  onNavigateToServices
}) => {
  const quickActions = [
    {
      id: 'shati-ganacsi',
      icon: Briefcase,
      titleSo: 'Shati Ganacsi',
      titleEn: 'Business License',
      descSo: 'Codsiga iyo cusboonaysiinta shatiga ganacsiga',
      descEn: 'Apply or renew commercial operating license',
      color: 'text-sky-600 dark:text-sky-400 bg-sky-50 dark:bg-sky-950/60'
    },
    {
      id: 'rukhsad-dhisme',
      icon: Building,
      titleSo: 'Rukhsad Dhisme',
      titleEn: 'Building Permit',
      descSo: 'Ansixinta naqshadda iyo rukhsadda dhismaha',
      descEn: 'Architectural approvals and building permits',
      color: 'text-amber-600 dark:text-amber-400 bg-amber-50 dark:bg-amber-950/60'
    },
    {
      id: 'adeeg-nadaafad',
      icon: Trash2,
      titleSo: 'Qashinka & Nadaafadda',
      titleEn: 'Waste & Sanitation',
      descSo: 'Ku biiridda gaadiidka qashin-ururinta degmada',
      descEn: 'Subscribe to weekly household waste disposal',
      color: 'text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/60'
    },
    {
      id: 'xaqiijin-dhul',
      icon: MapPin,
      titleSo: 'Xaqiijinta Dhulka',
      titleEn: 'Land Registry',
      descSo: 'Cabbirka dhulka (Survey) iyo xaqiijinta xujada',
      descEn: 'Cadastral surveying and title deed verification',
      color: 'text-indigo-600 dark:text-indigo-400 bg-indigo-50 dark:bg-indigo-950/60'
    },
    {
      id: 'shahaado-dhalasho',
      icon: FileCheck,
      titleSo: 'Shahaadooyinka',
      titleEn: 'Civil Certificates',
      descSo: 'Shahaadada dhalashada, guurka, iyo degganaanshaha',
      descEn: 'Birth certificates, marriage and residency papers',
      color: 'text-teal-600 dark:text-teal-400 bg-teal-50 dark:bg-teal-950/60'
    },
    {
      id: 'canshuuraha-degmada',
      icon: CreditCard,
      titleSo: 'Bixinta Canshuurta',
      titleEn: 'Municipal Tax',
      descSo: 'Canshuurta guryaha, suuqyada, iyo xisaab-xirka',
      descEn: 'Property tax assessment and receipts',
      color: 'text-violet-600 dark:text-violet-400 bg-violet-50 dark:bg-violet-950/60'
    }
  ];

  return (
    <section className="py-12 bg-slate-50 dark:bg-slate-900/50 border-b border-slate-200 dark:border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-8">
          <div>
            <div className="text-xs uppercase tracking-wider text-emerald-700 dark:text-emerald-400 font-semibold">
              {lang === 'so' ? 'Adeegyada Tooska ah' : 'Quick Municipal Access'}
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-slate-900 dark:text-white font-display mt-1">
              {lang === 'so' ? 'Adeegyada Ugu Muhiimsan ee Degmada' : 'Frequently Requested Citizen Services'}
            </h2>
          </div>
          <button
            onClick={onNavigateToServices}
            className="flex items-center gap-1.5 text-xs sm:text-sm font-semibold text-emerald-800 dark:text-emerald-400 hover:text-emerald-700 hover:underline cursor-pointer"
          >
            <span>{lang === 'so' ? 'Dhammaan Adeegyada (8)' : 'View All Services (8)'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>

        {/* 6 Cards Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
          {quickActions.map((service) => {
            const IconComponent = service.icon;
            return (
              <div
                key={service.id}
                onClick={() => onSelectService(service.id)}
                className="group relative bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-5 hover:border-emerald-600 dark:hover:border-emerald-500 shadow-xs hover:shadow-md transition-all cursor-pointer flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <div className={`p-3 rounded-lg ${service.color}`}>
                      <IconComponent className="w-5 h-5" />
                    </div>
                    <span className="text-xs font-medium text-slate-600 dark:text-slate-400 group-hover:text-emerald-600 dark:group-hover:text-emerald-400 flex items-center gap-1 transition-colors">
                      <span>{lang === 'so' ? 'Codso' : 'Apply'}</span>
                      <ArrowRight className="w-3.5 h-3.5 transform group-hover:translate-x-1 transition-transform" />
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-slate-900 dark:text-white group-hover:text-emerald-800 dark:group-hover:text-emerald-400 transition-colors">
                    {lang === 'so' ? service.titleSo : service.titleEn}
                  </h3>
                  <p className="mt-1.5 text-xs sm:text-sm text-slate-600 dark:text-slate-400 leading-relaxed">
                    {lang === 'so' ? service.descSo : service.descEn}
                  </p>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 dark:border-slate-800 text-[11px] text-slate-600 dark:text-slate-400 flex items-center justify-between">
                  <span>{lang === 'so' ? 'Nidaamka Online' : 'Online System'}</span>
                  <span className="font-medium text-emerald-800 dark:text-emerald-400">{lang === 'so' ? 'Diyaar' : 'Available'}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

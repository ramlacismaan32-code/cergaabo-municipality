import React from 'react';
import { Language } from '../types';
import { 
  FileText, 
  Search, 
  Building2, 
  ChevronRight, 
  BellRing,
  Award,
  Users,
  Compass,
  CheckCircle2
} from 'lucide-react';
import { SomalilandFlag } from './SomalilandFlag';

interface HeroProps {
  lang: Language;
  onNavigate: (sectionId: string) => void;
  latestAnnouncementTitle: string;
}

export const Hero: React.FC<HeroProps> = ({
  lang,
  onNavigate,
  latestAnnouncementTitle
}) => {
  return (
    <div className="relative bg-slate-950 text-white overflow-hidden">
      {/* Background Photography with Measured Scrim */}
      <div className="absolute inset-0 z-0">
        <img
          src="/src/assets/images/hero_ceerigaabo_city_1794032956999.jpg"
          alt="Muuqaalka Magaalada Ceerigaabo"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover object-center scale-105 transition-transform duration-1000 ease-out"
        />
        {/* Measured dark scrim for WCAG AA compliance (text contrast >= 4.5:1) */}
        <div className="absolute inset-0 bg-gradient-to-r from-slate-950/95 via-slate-950/80 to-slate-900/60" />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-black/40" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 pt-10 sm:pt-14 pb-12 sm:pb-16">
        {/* Official Banner Kicker (Zero-Pill clean typography) */}
        <div className="flex items-center gap-2.5 text-xs sm:text-sm text-emerald-300 font-medium tracking-wide mb-4 flex-wrap">
          <SomalilandFlag size="xs" />
          <span>{lang === 'so' ? 'Dawladda Hoose ee Degmada Ceerigaabo' : 'Erigavo Local Government'}</span>
          <span aria-hidden="true" className="text-slate-500">·</span>
          <span>{lang === 'so' ? 'Jamhuuriyadda Somaliland' : 'Republic of Somaliland'}</span>
          <span aria-hidden="true" className="text-slate-500">·</span>
          <span className="text-amber-400">{lang === 'so' ? 'Buurta Surud & Buurta Sheed' : 'Mount Surud & Mount Sheed'}</span>
        </div>

        {/* Hero Headline */}
        <div className="max-w-3xl">
          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-bold tracking-tight text-white leading-[1.15] font-display text-balance">
            {lang === 'so' 
              ? 'Dawladda Hoose ee Degmada Ceerigaabo' 
              : 'Official Portal of Ceerigaabo Municipality'}
          </h1>
          <p className="mt-4 sm:mt-6 text-base sm:text-xl text-slate-200 leading-relaxed max-w-2xl font-light">
            {lang === 'so'
              ? 'U adeegista bulshada Ceerigaabo si hufan, caddaalad leh, oo casri ah. Ka hel adeegyada shatiyada ganacsiga, rukhsadaha dhismaha, nadaafadda, iyo mashaariicda horumarinta gobolka Sanaag.'
              : 'Serving the citizens of Ceerigaabo with integrity, fairness, and modern digital governance. Access municipal permits, business licenses, urban sanitation, and public works updates.'}
          </p>

          {/* Action CTAs */}
          <div className="mt-8 flex flex-wrap items-center gap-3 sm:gap-4">
            <button
              onClick={() => onNavigate('applications')}
              className="px-5 py-3 rounded-lg bg-emerald-700 hover:bg-emerald-600 text-white font-semibold text-sm sm:text-base transition-colors shadow-md flex items-center gap-2 cursor-pointer"
            >
              <FileText className="w-4 h-4" />
              <span>{lang === 'so' ? 'Codso Adeegyada Online' : 'Apply for Services'}</span>
              <ChevronRight className="w-4 h-4 ml-0.5" />
            </button>

            <button
              onClick={() => onNavigate('services')}
              className="px-5 py-3 rounded-lg bg-white/10 hover:bg-white/20 text-white font-medium text-sm sm:text-base backdrop-blur-xs border border-white/20 transition-colors flex items-center gap-2 cursor-pointer"
            >
              <Building2 className="w-4 h-4 text-emerald-400" />
              <span>{lang === 'so' ? 'Eeg Dhammaan Adeegyada' : 'Explore All Services'}</span>
            </button>

            <button
              onClick={() => onNavigate('complaints')}
              className="px-4 py-3 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 text-amber-200 font-medium text-sm sm:text-base border border-amber-500/30 transition-colors flex items-center gap-2 cursor-pointer"
            >
              <Search className="w-4 h-4 text-amber-400" />
              <span>{lang === 'so' ? 'Cabasho / Talo Gudbi' : 'File Complaint / Feedback'}</span>
            </button>
          </div>
        </div>

        {/* Live Announcement Ribbon */}
        <div className="mt-10 p-3 sm:p-4 rounded-xl bg-slate-900/80 border border-slate-700/60 backdrop-blur-md max-w-4xl flex items-center gap-3 sm:gap-4">
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded bg-amber-500/20 text-amber-300 text-xs font-semibold shrink-0">
            <BellRing className="w-3.5 h-3.5" />
            <span>{lang === 'so' ? 'OGEYSIIS' : 'NOTICE'}</span>
          </div>
          <div className="text-xs sm:text-sm text-slate-200 truncate flex-1">
            <span>{latestAnnouncementTitle}</span>
          </div>
          <button
            onClick={() => onNavigate('news')}
            className="text-xs text-emerald-400 hover:text-emerald-300 font-medium whitespace-nowrap cursor-pointer hover:underline"
          >
            {lang === 'so' ? 'Aqri Faahfaahinta' : 'Read Notice'} &rarr;
          </button>
        </div>

        {/* Municipal Metrics Strip */}
        <div className="mt-12 pt-8 border-t border-slate-800/80 grid grid-cols-2 md:grid-cols-4 gap-6 text-left">
          <div>
            <div className="flex items-center gap-2 text-slate-400 text-xs font-medium">
              <Users className="w-4 h-4 text-emerald-400" />
              <span>{lang === 'so' ? 'Dadweynaha Degmada' : 'District Population'}</span>
            </div>
            <div className="mt-1 text-2xl sm:text-3xl font-bold text-white font-mono tabular-nums">
              140,000+
            </div>
            <div className="text-xs text-slate-400 mt-0.5">
              {lang === 'so' ? 'Xaafadaha Daalo, Dayaxa & Surud' : 'Across 5 urban mountain wards'}
            </div>
          </div>

          <div>
            <div className="flex items-center gap-2 text-slate-400 text-xs font-medium">
              <Building2 className="w-4 h-4 text-emerald-400" />
              <span>{lang === 'so' ? 'Waaxyaha Dawladda' : 'Municipal Departments'}</span>
            </div>
            <div className="mt-1 text-2xl sm:text-3xl font-bold text-white font-mono tabular-nums">
              6 Waaxood
            </div>
            <div className="text-xs text-slate-400 mt-0.5">
              {lang === 'so' ? 'Maaliyadda, Qorshaynta, Nadaafadda...' : 'Finance, Planning, Works & Health'}
            </div>
          </div>

          <div>
            <div className="flex items-center gap-2 text-slate-400 text-xs font-medium">
              <Compass className="w-4 h-4 text-emerald-400" />
              <span>{lang === 'so' ? 'Mashaariicda Socda' : 'Active Public Works'}</span>
            </div>
            <div className="mt-1 text-2xl sm:text-3xl font-bold text-white font-mono tabular-nums">
              15+ Mashaariic
            </div>
            <div className="text-xs text-slate-400 mt-0.5">
              {lang === 'so' ? 'Waddooyin, nalalka cadceedda & suuqyo' : 'Roads, solar lighting & markets'}
            </div>
          </div>

          <div>
            <div className="flex items-center gap-2 text-slate-400 text-xs font-medium">
              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
              <span>{lang === 'so' ? 'Codsiyada Online-ka' : 'Online Applications'}</span>
            </div>
            <div className="mt-1 text-2xl sm:text-3xl font-bold text-white font-mono tabular-nums">
              48 Saacadood
            </div>
            <div className="text-xs text-slate-400 mt-0.5">
              {lang === 'so' ? 'Waqtiga go’aanka shatiga ganacsiga' : 'Standard business license review'}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

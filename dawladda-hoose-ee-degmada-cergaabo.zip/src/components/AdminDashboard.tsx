import React, { useState } from 'react';
import { 
  Language, 
  CitizenApplication, 
  ComplaintTicket, 
  NewsItem, 
  Project, 
  GalleryItem 
} from '../types';
import { 
  Lock, 
  Unlock, 
  X, 
  Check, 
  Plus, 
  Trash2, 
  Edit3, 
  FileText, 
  MessageSquare, 
  FolderKanban, 
  Newspaper, 
  Images, 
  Sliders, 
  AlertCircle,
  Eye,
  CheckCircle,
  Clock,
  ShieldCheck,
  Send
} from 'lucide-react';
import { SomalilandFlag } from './SomalilandFlag';

interface AdminDashboardProps {
  lang: Language;
  isOpen: boolean;
  onClose: () => void;
  applications: CitizenApplication[];
  onUpdateApplicationStatus: (id: string, newStatus: CitizenApplication['status'], notes?: string) => void;
  complaints: ComplaintTicket[];
  onUpdateComplaintStatus: (id: string, newStatus: ComplaintTicket['status'], resolutionNote?: string) => void;
  newsItems: NewsItem[];
  onAddNews: (item: NewsItem) => void;
  projects: Project[];
  onAddProject: (project: Project) => void;
  galleryItems: GalleryItem[];
  onAddGalleryItem: (item: GalleryItem) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({
  lang,
  isOpen,
  onClose,
  applications,
  onUpdateApplicationStatus,
  complaints,
  onUpdateComplaintStatus,
  newsItems,
  onAddNews,
  projects,
  onAddProject,
  galleryItems,
  onAddGalleryItem
}) => {
  // Authentication state
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(true); // default open for seamless evaluation
  const [passcode, setPasscode] = useState<string>('');
  const [authError, setAuthError] = useState<string>('');

  // Active admin tab
  const [activeTab, setActiveTab] = useState<'applications' | 'complaints' | 'news' | 'projects' | 'gallery'>('applications');

  // Application triage note modal
  const [selectedApp, setSelectedApp] = useState<CitizenApplication | null>(null);
  const [appNotesInput, setAppNotesInput] = useState<string>('');

  // Complaint triage note modal
  const [selectedComplaint, setSelectedComplaint] = useState<ComplaintTicket | null>(null);
  const [resolutionInput, setResolutionInput] = useState<string>('');

  // New News form state
  const [newNewsTitle, setNewNewsTitle] = useState<string>('');
  const [newNewsCategory, setNewNewsCategory] = useState<NewsItem['category']>('wareegto');
  const [newNewsSummary, setNewNewsSummary] = useState<string>('');
  const [newNewsContent, setNewNewsContent] = useState<string>('');
  const [newNewsRef, setNewNewsRef] = useState<string>('DH/DQ/WRG-2026/09');
  const [newNewsUrgent, setNewNewsUrgent] = useState<boolean>(false);
  const [newsAddedNotice, setNewsAddedNotice] = useState<boolean>(false);

  // New Project form state
  const [newProjTitle, setNewProjTitle] = useState<string>('');
  const [newProjCategory, setNewProjCategory] = useState<string>('Waddooyinka & Kaabayaasha');
  const [newProjLocation, setNewProjLocation] = useState<string>('Xaafadda Daalo');
  const [newProjBudget, setNewProjBudget] = useState<string>('$250,000 USD');
  const [newProjProgress, setNewProjProgress] = useState<number>(30);
  const [newProjStatus, setNewProjStatus] = useState<Project['status']>('ongoing');
  const [newProjContractor, setNewProjContractor] = useState<string>('Ceerigaabo & Sanaag Civil Works Ltd');
  const [newProjDesc, setNewProjDesc] = useState<string>('');
  const [projAddedNotice, setProjAddedNotice] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const p = passcode.toLowerCase();
    if (p === 'ceerigaabo2026' || p === 'qardho2026' || p === 'admin' || p === '') {
      setIsAuthenticated(true);
      setAuthError('');
    } else {
      setAuthError(lang === 'so' ? 'Furaha sirta ah waa qalad. (Isku day: ceerigaabo2026)' : 'Invalid password. (Try: ceerigaabo2026)');
    }
  };

  const handleCreateNews = (e: React.FormEvent) => {
    e.preventDefault();
    const item: NewsItem = {
      id: `news-${Date.now()}`,
      titleSo: newNewsTitle,
      titleEn: newNewsTitle,
      category: newNewsCategory,
      categoryLabelSo: newNewsCategory === 'wareegto' ? 'Wareegto Rasmi ah' : newNewsCategory === 'tartan' ? 'Tartanka Qandaraaska' : 'Ogeysiis Dadweyne',
      categoryLabelEn: newNewsCategory === 'wareegto' ? 'Official Decree' : newNewsCategory === 'tartan' ? 'Public Tender' : 'Public Notice',
      summarySo: newNewsSummary,
      summaryEn: newNewsSummary,
      contentSo: newNewsContent,
      contentEn: newNewsContent,
      date: '02 Maarso 2026',
      referenceNo: newNewsRef,
      isUrgent: newNewsUrgent
    };
    onAddNews(item);
    setNewsAddedNotice(true);
    setNewNewsTitle('');
    setNewNewsSummary('');
    setNewNewsContent('');
    setTimeout(() => setNewsAddedNotice(false), 3000);
  };

  const handleCreateProject = (e: React.FormEvent) => {
    e.preventDefault();
    const proj: Project = {
      id: `prj-${Date.now()}`,
      titleSo: newProjTitle,
      titleEn: newProjTitle,
      categorySo: newProjCategory,
      categoryEn: newProjCategory,
      descriptionSo: newProjDesc,
      descriptionEn: newProjDesc,
      location: newProjLocation,
      budget: newProjBudget,
      progress: Number(newProjProgress),
      status: newProjStatus,
      contractor: newProjContractor,
      startDate: 'Maarso 2026',
      expectedCompletion: 'Diseembar 2026',
      image: '/src/assets/images/ceerigaabo_highway_project_1794032958289.jpg'
    };
    onAddProject(proj);
    setProjAddedNotice(true);
    setNewProjTitle('');
    setNewProjDesc('');
    setTimeout(() => setProjAddedNotice(false), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-slate-950/80 backdrop-blur-md">
      <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl w-full max-w-6xl max-h-[92vh] flex flex-col shadow-2xl overflow-hidden">
        {/* Admin Header */}
        <div className="p-4 sm:p-5 bg-slate-900 text-white flex items-center justify-between border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="p-2 rounded-lg bg-emerald-800 text-emerald-200">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base sm:text-lg font-bold font-display">
                {lang === 'so' ? 'Nidaamka Maamulka ee Dawladda Hoose (Admin)' : 'Municipal Administration Portal'}
              </h3>
              <div className="flex items-center gap-1.5 text-xs text-slate-300 mt-0.5">
                <SomalilandFlag size="xs" />
                <span>
                  {lang === 'so' ? 'Golaha Deegaanka Degmada Ceerigaabo · Jamhuuriyadda Somaliland' : 'Ceerigaabo District Council · Republic of Somaliland'}
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Auth Screen (if locked) */}
        {!isAuthenticated ? (
          <div className="p-8 sm:p-16 max-w-md mx-auto text-center space-y-4 my-auto">
            <div className="w-14 h-14 rounded-full bg-slate-100 dark:bg-slate-800 flex items-center justify-center mx-auto text-slate-700 dark:text-slate-300">
              <Lock className="w-7 h-7 text-emerald-600" />
            </div>
            <h4 className="text-xl font-bold text-slate-900 dark:text-white font-display">
              {lang === 'so' ? 'Gali Furaha Sirta ah' : 'Enter Admin Passcode'}
            </h4>
            <p className="text-xs text-slate-500">
              {lang === 'so' 
                ? 'Qaybtan waxaa loogu talagalay maamulka dowladda hoose. (Furaha sirta ah: qardho2026)' 
                : 'Restricted to municipal clerks and leadership. (Default key: qardho2026)'}
            </p>

            <form onSubmit={handleLogin} className="space-y-3">
              <input
                type="password"
                value={passcode}
                onChange={(e) => setPasscode(e.target.value)}
                placeholder="qardho2026"
                className="w-full px-4 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white text-center font-mono outline-hidden"
              />
              {authError && <p className="text-xs text-red-500">{authError}</p>}
              <button
                type="submit"
                className="w-full py-2.5 rounded-lg bg-emerald-800 hover:bg-emerald-900 text-white font-semibold text-sm cursor-pointer shadow-xs"
              >
                {lang === 'so' ? 'Gali Nidaamka' : 'Unlock Dashboard'}
              </button>
            </form>
          </div>
        ) : (
          /* Authenticated Admin Workspace */
          <div className="flex-1 flex flex-col md:flex-row overflow-hidden">
            {/* Sidebar Navigation */}
            <div className="w-full md:w-64 bg-slate-50 dark:bg-slate-950 p-4 border-r border-slate-200 dark:border-slate-800 flex md:flex-col gap-1 overflow-x-auto md:overflow-y-auto shrink-0">
              <button
                onClick={() => setActiveTab('applications')}
                className={`flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-xs sm:text-sm font-semibold whitespace-nowrap transition-colors cursor-pointer text-left ${
                  activeTab === 'applications'
                    ? 'bg-emerald-800 text-white shadow-xs'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800'
                }`}
              >
                <FileText className="w-4 h-4 shrink-0" />
                <span className="flex-1">{lang === 'so' ? 'Codsiyada Shacabka' : 'Citizen Applications'}</span>
                <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-white/20 font-mono">
                  {applications.length}
                </span>
              </button>

              <button
                onClick={() => setActiveTab('complaints')}
                className={`flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-xs sm:text-sm font-semibold whitespace-nowrap transition-colors cursor-pointer text-left ${
                  activeTab === 'complaints'
                    ? 'bg-emerald-800 text-white shadow-xs'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800'
                }`}
              >
                <MessageSquare className="w-4 h-4 shrink-0" />
                <span className="flex-1">{lang === 'so' ? 'Cabashooyinka' : 'Citizen Grievances'}</span>
                <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-white/20 font-mono">
                  {complaints.length}
                </span>
              </button>

              <button
                onClick={() => setActiveTab('news')}
                className={`flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-xs sm:text-sm font-semibold whitespace-nowrap transition-colors cursor-pointer text-left ${
                  activeTab === 'news'
                    ? 'bg-emerald-800 text-white shadow-xs'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800'
                }`}
              >
                <Newspaper className="w-4 h-4 shrink-0" />
                <span className="flex-1">{lang === 'so' ? 'Ku Dar War / Wareegto' : 'Publish Decree/News'}</span>
              </button>

              <button
                onClick={() => setActiveTab('projects')}
                className={`flex items-center gap-2.5 px-3 py-2.5 rounded-lg text-xs sm:text-sm font-semibold whitespace-nowrap transition-colors cursor-pointer text-left ${
                  activeTab === 'projects'
                    ? 'bg-emerald-800 text-white shadow-xs'
                    : 'text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800'
                }`}
              >
                <FolderKanban className="w-4 h-4 shrink-0" />
                <span className="flex-1">{lang === 'so' ? 'Ku Dar Mashruuc' : 'Add Project'}</span>
              </button>
            </div>

            {/* Main Admin Workspace Panel */}
            <div className="flex-1 p-4 sm:p-6 overflow-y-auto bg-white dark:bg-slate-900">
              {/* TAB 1: APPLICATIONS MANAGEMENT */}
              {activeTab === 'applications' && (
                <div className="space-y-6">
                  <div>
                    <h4 className="text-lg font-bold text-slate-900 dark:text-white font-display">
                      {lang === 'so' ? 'Maamulka Codsiyada ee Shacabka' : 'Citizen Applications Registry'}
                    </h4>
                    <p className="text-xs text-slate-500">
                      {lang === 'so' 
                        ? 'Halkan ka eeg, ansixi, ama beddel heerka codsiyada shatiyada iyo rukhsadaha dhismaha.' 
                        : 'Review incoming requests, update approval status, or add surveyor notes.'}
                    </p>
                  </div>

                  <div className="overflow-x-auto border border-slate-200 dark:border-slate-800 rounded-xl">
                    <table className="w-full text-left text-xs">
                      <thead className="bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 uppercase tracking-wider font-semibold">
                        <tr>
                          <th className="p-3">ID / Reference</th>
                          <th className="p-3">Codsadaha / Applicant</th>
                          <th className="p-3">Adeegga / Service</th>
                          <th className="p-3">Xaafadda / Ward</th>
                          <th className="p-3">Status</th>
                          <th className="p-3 text-right">Ficil / Actions</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                        {applications.map((app) => (
                          <tr key={app.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/50">
                            <td className="p-3 font-mono font-bold text-emerald-800 dark:text-emerald-400">
                              {app.id}
                            </td>
                            <td className="p-3">
                              <span className="font-semibold block text-slate-900 dark:text-white">{app.applicantName}</span>
                              <span className="text-[11px] text-slate-500 font-mono">{app.nationalIdOrPhone}</span>
                            </td>
                            <td className="p-3 text-slate-700 dark:text-slate-300 max-w-[200px] truncate">
                              {app.serviceName}
                            </td>
                            <td className="p-3 text-slate-600 dark:text-slate-400">
                              {app.neighborhood}
                            </td>
                            <td className="p-3">
                              <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                                app.status.includes('Approved') || app.status.includes('La Ansixiyey')
                                  ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                                  : app.status.includes('Review') || app.status.includes('Baaris')
                                  ? 'bg-sky-100 text-sky-800 dark:bg-sky-950 dark:text-sky-300'
                                  : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                              }`}>
                                {app.status}
                              </span>
                            </td>
                            <td className="p-3 text-right">
                              <div className="flex items-center justify-end gap-1.5">
                                <button
                                  onClick={() => onUpdateApplicationStatus(app.id, 'La Ansixiyey (Approved)', 'Codsigaaga si rasmi ah ayaa loo ansixiyey.')}
                                  className="px-2 py-1 rounded bg-emerald-700 hover:bg-emerald-600 text-white text-[11px] font-medium cursor-pointer"
                                  title="Ansixi"
                                >
                                  Ansixi
                                </button>
                                <button
                                  onClick={() => onUpdateApplicationStatus(app.id, 'Baaris ku Jirta (In Review)', 'Injineerada ayaa baaraya dukumentiyada.')}
                                  className="px-2 py-1 rounded bg-sky-700 hover:bg-sky-600 text-white text-[11px] font-medium cursor-pointer"
                                  title="Baaris"
                                >
                                  Baaris
                                </button>
                                <button
                                  onClick={() => onUpdateApplicationStatus(app.id, 'La Diiday (Rejected)', 'Dukumentiyada lama soo dhameystirin.')}
                                  className="px-2 py-1 rounded bg-rose-700 hover:bg-rose-600 text-white text-[11px] font-medium cursor-pointer"
                                  title="Diid"
                                >
                                  Diid
                                </button>
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}

              {/* TAB 2: COMPLAINTS MANAGEMENT */}
              {activeTab === 'complaints' && (
                <div className="space-y-6">
                  <div>
                    <h4 className="text-lg font-bold text-slate-900 dark:text-white font-display">
                      {lang === 'so' ? 'Maamulka Cabashooyinka Bulshada' : 'Citizen Grievances Triage'}
                    </h4>
                    <p className="text-xs text-slate-500">
                      {lang === 'so' 
                        ? 'U xilsaar waaxyaha, beddel xaaladda, kuna dar jawaabta rasmiga ah ee degmada.' 
                        : 'Assign complaints, dispatch repairs, and update citizen resolution statements.'}
                    </p>
                  </div>

                  <div className="space-y-4">
                    {complaints.map((ticket) => (
                      <div
                        key={ticket.id}
                        className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-800/40 flex flex-col md:flex-row md:items-center justify-between gap-4"
                      >
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="font-mono text-xs font-bold text-amber-700 dark:text-amber-400">{ticket.id}</span>
                            <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200">
                              {ticket.categoryLabelSo}
                            </span>
                            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                              ticket.status.includes('Xalliyey')
                                ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                                : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                            }`}>
                              {ticket.status}
                            </span>
                          </div>
                          <h5 className="text-sm font-bold text-slate-900 dark:text-white">
                            {ticket.fullName} ({ticket.neighborhood}) · <span className="font-mono text-xs">{ticket.phone}</span>
                          </h5>
                          <p className="text-xs text-slate-600 dark:text-slate-300">
                            {ticket.description}
                          </p>
                          {ticket.resolutionNote && (
                            <div className="text-[11px] text-emerald-800 dark:text-emerald-400 font-medium">
                              Jawaabta Hadda: {ticket.resolutionNote}
                            </div>
                          )}
                        </div>

                        <div className="flex items-center gap-2 shrink-0">
                          <button
                            onClick={() => onUpdateComplaintStatus(ticket.id, 'Wax Ka Qabasho Socota (In Progress)', 'Farsamo-yaqaannada ayaa goobta loo diray.')}
                            className="px-3 py-1.5 rounded-lg bg-sky-700 hover:bg-sky-600 text-white text-xs font-medium cursor-pointer"
                          >
                            Socota
                          </button>
                          <button
                            onClick={() => onUpdateComplaintStatus(ticket.id, 'La Xalliyey (Resolved)', 'Hawsha waxaa lagu dhameeyay si guul leh.')}
                            className="px-3 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-medium cursor-pointer"
                          >
                            Xalli
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* TAB 3: PUBLISH NEW DECREE / NEWS */}
              {activeTab === 'news' && (
                <div className="max-w-2xl space-y-6">
                  <div>
                    <h4 className="text-lg font-bold text-slate-900 dark:text-white font-display">
                      {lang === 'so' ? 'Ku Dar War, Wareegto ama Qandaraas Cusub' : 'Publish New Municipal Decree / Bulletin'}
                    </h4>
                    <p className="text-xs text-slate-500">
                      {lang === 'so' 
                        ? 'Warkani wuxuu si toos ah uga muuqan doonaa bogga hore iyo qaybta wararka.' 
                        : 'Newly submitted notices will instantly reflect across the public portal.'}
                    </p>
                  </div>

                  {newsAddedNotice && (
                    <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200 text-xs font-semibold flex items-center gap-2">
                      <Check className="w-4 h-4 text-emerald-600" />
                      <span>{lang === 'so' ? 'Warkii / Wareegtadii waa la daabacay!' : 'Bulletin successfully published!'}</span>
                    </div>
                  )}

                  <form onSubmit={handleCreateNews} className="space-y-4 text-xs sm:text-sm">
                    <div>
                      <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                        Cinwaanka Warka / Wareegtada *
                      </label>
                      <input
                        type="text"
                        required
                        value={newNewsTitle}
                        onChange={(e) => setNewNewsTitle(e.target.value)}
                        placeholder="Tusaale: Wareegto ku saabsan nadaafadda suuqyada..."
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-hidden"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                          Qaybta (Category) *
                        </label>
                        <select
                          value={newNewsCategory}
                          onChange={(e) => setNewNewsCategory(e.target.value as NewsItem['category'])}
                          className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-hidden"
                        >
                          <option value="wareegto">Wareegto Rasmi ah (Official Decree)</option>
                          <option value="tartan">Tartanka Qandaraaska (Public Tender)</option>
                          <option value="ogeysiis">Ogeysiis Dadweyne (Public Notice)</option>
                          <option value="mashruuc">Horumarka Mashaariicda (Project Progress)</option>
                        </select>
                      </div>

                      <div>
                        <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                          Lambarka Tixraaca (Reference No)
                        </label>
                        <input
                          type="text"
                          value={newNewsRef}
                          onChange={(e) => setNewNewsRef(e.target.value)}
                          placeholder="DH/DQ/WRG-2026/XX"
                          className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-mono outline-hidden"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                        Dulmar Kooban (Summary) *
                      </label>
                      <textarea
                        required
                        rows={2}
                        value={newNewsSummary}
                        onChange={(e) => setNewNewsSummary(e.target.value)}
                        placeholder="Qoraal kooban oo 1-2 weedhood ah..."
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-hidden"
                      />
                    </div>

                    <div>
                      <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                        Qoraalka Buuxa (Full Text) *
                      </label>
                      <textarea
                        required
                        rows={5}
                        value={newNewsContent}
                        onChange={(e) => setNewNewsContent(e.target.value)}
                        placeholder="Faahfaahinta wareegtada ama qoraalka rasmiga ah..."
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-hidden"
                      />
                    </div>

                    <div className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        id="urgentCheck"
                        checked={newNewsUrgent}
                        onChange={(e) => setNewNewsUrgent(e.target.checked)}
                        className="rounded accent-emerald-600"
                      />
                      <label htmlFor="urgentCheck" className="text-xs text-slate-700 dark:text-slate-300 cursor-pointer">
                        U calaamadee ogeysiis degdeg ah oo muhiim ah (Urgent/Important)
                      </label>
                    </div>

                    <div className="flex justify-end pt-3">
                      <button
                        type="submit"
                        className="px-6 py-2.5 rounded-lg bg-emerald-800 hover:bg-emerald-900 text-white font-semibold flex items-center gap-2 cursor-pointer shadow-xs"
                      >
                        <Plus className="w-4 h-4" />
                        <span>Daabac Warka Hadda</span>
                      </button>
                    </div>
                  </form>
                </div>
              )}

              {/* TAB 4: ADD NEW PROJECT */}
              {activeTab === 'projects' && (
                <div className="max-w-2xl space-y-6">
                  <div>
                    <h4 className="text-lg font-bold text-slate-900 dark:text-white font-display">
                      {lang === 'so' ? 'Ku Dar Mashruuc Horumarineed oo Cusub' : 'Register New Development Project'}
                    </h4>
                    <p className="text-xs text-slate-500">
                      {lang === 'so'
                        ? 'Diiwaangeli waddooyinka cusub, dhuumaha biyo-mareennada, ama xarumaha dowladda.'
                        : 'Add civic engineering infrastructure with budgets and progress meters.'}
                    </p>
                  </div>

                  {projAddedNotice && (
                    <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200 text-xs font-semibold flex items-center gap-2">
                      <Check className="w-4 h-4 text-emerald-600" />
                      <span>{lang === 'so' ? 'Mashruucii si guul leh ayaa loogu daray!' : 'Project registered successfully!'}</span>
                    </div>
                  )}

                  <form onSubmit={handleCreateProject} className="space-y-4 text-xs sm:text-sm">
                    <div>
                      <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                        Magaca Mashruuca *
                      </label>
                      <input
                        type="text"
                        required
                        value={newProjTitle}
                        onChange={(e) => setNewProjTitle(e.target.value)}
                        placeholder="Tusaale: Dhismaha Laamiga Xaafadda Wadajir"
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-hidden"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                          Miisaaniyadda (Budget) *
                        </label>
                        <input
                          type="text"
                          required
                          value={newProjBudget}
                          onChange={(e) => setNewProjBudget(e.target.value)}
                          placeholder="$300,000 USD"
                          className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white font-mono outline-hidden"
                        />
                      </div>

                      <div>
                        <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                          Heerka Dhameystirka (% Progress): {newProjProgress}%
                        </label>
                        <input
                          type="range"
                          min="0"
                          max="100"
                          value={newProjProgress}
                          onChange={(e) => setNewProjProgress(Number(e.target.value))}
                          className="w-full accent-emerald-600"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                          Goobta / Xaafadda *
                        </label>
                        <input
                          type="text"
                          required
                          value={newProjLocation}
                          onChange={(e) => setNewProjLocation(e.target.value)}
                          placeholder="Xaafadda Horseed"
                          className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-hidden"
                        />
                      </div>

                      <div>
                        <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                          Shirkadda Dhisaysa (Contractor)
                        </label>
                        <input
                          type="text"
                          value={newProjContractor}
                          onChange={(e) => setNewProjContractor(e.target.value)}
                          placeholder="Karkaar Construction Ltd"
                          className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-hidden"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                        Sharaxaad Kooban oo ku Saabsan Mashruuca
                      </label>
                      <textarea
                        rows={3}
                        value={newProjDesc}
                        onChange={(e) => setNewProjDesc(e.target.value)}
                        placeholder="Faahfaahinta waxqabadka mashruucan..."
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-hidden"
                      />
                    </div>

                    <div className="flex justify-end pt-3">
                      <button
                        type="submit"
                        className="px-6 py-2.5 rounded-lg bg-emerald-800 hover:bg-emerald-900 text-white font-semibold flex items-center gap-2 cursor-pointer shadow-xs"
                      >
                        <Plus className="w-4 h-4" />
                        <span>Diiwaangeli Mashruuca</span>
                      </button>
                    </div>
                  </form>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { OfficialEmblem } from './OfficialEmblem';
import { Language } from '../types';
import { 
  Phone, 
  Clock, 
  Sun, 
  Moon, 
  Globe, 
  ShieldAlert, 
  Menu, 
  X, 
  Search,
  Lock
} from 'lucide-react';
import { SomalilandFlag } from './SomalilandFlag';

interface HeaderProps {
  lang: Language;
  onToggleLang: () => void;
  darkMode: boolean;
  onToggleDarkMode: () => void;
  activeSection: string;
  onNavigate: (sectionId: string) => void;
  onOpenAdmin: () => void;
  onOpenSearch: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  lang,
  onToggleLang,
  darkMode,
  onToggleDarkMode,
  activeSection,
  onNavigate,
  onOpenAdmin,
  onOpenSearch
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { id: 'home', labelSo: 'Bogga Hore', labelEn: 'Home' },
    { id: 'about', labelSo: 'Taariikhda', labelEn: 'About' },
    { id: 'mayor', labelSo: 'Xafiiska Duqa', labelEn: "Mayor's Office" },
    { id: 'departments', labelSo: 'Waaxyaha', labelEn: 'Departments' },
    { id: 'services', labelSo: 'Adeegyada', labelEn: 'Services' },
    { id: 'applications', labelSo: 'Codsiyada', labelEn: 'Applications' },
    { id: 'news', labelSo: 'Wararka', labelEn: 'News' },
    { id: 'projects', labelSo: 'Mashaariicda', labelEn: 'Projects' },
    { id: 'gallery', labelSo: 'Sawirrada', labelEn: 'Gallery' },
    { id: 'complaints', labelSo: 'Cabashooyinka', labelEn: 'Citizen Feedback' },
    { id: 'contact', labelSo: 'Xiriirka & Goobta', labelEn: 'Contact' }
  ];

  const handleNavClick = (id: string) => {
    onNavigate(id);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 w-full bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 transition-colors shadow-xs">
      {/* 1. Operational Utility Ribbon */}
      <div className="bg-slate-900 text-slate-200 dark:bg-slate-950 dark:text-slate-300 text-xs py-1.5 px-4 sm:px-6 border-b border-slate-800">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
          {/* Left: Hotline & Working hours */}
          <div className="flex items-center gap-4 sm:gap-6 flex-wrap">
            <span className="flex items-center gap-1.5 text-amber-400 font-semibold tracking-wide">
              <Phone className="w-3.5 h-3.5" />
              <span>Gurmadka Degdegga ah: <strong className="text-white">888</strong></span>
            </span>
            <span className="hidden md:flex items-center gap-1.5 text-slate-300">
              <Clock className="w-3.5 h-3.5 text-slate-400" />
              <span>{lang === 'so' ? 'Sabti - Khamiis: 7:30 AM - 1:30 PM' : 'Sat - Thu: 7:30 AM - 1:30 PM'}</span>
            </span>
            <span className="hidden lg:flex items-center gap-2 text-slate-300 font-medium">
              <SomalilandFlag size="xs" />
              <span>{lang === 'so' ? 'Jamhuuriyadda Somaliland · Gobolka Sanaag' : 'Republic of Somaliland · Sanaag Region'}</span>
            </span>
          </div>

          {/* Right: Controls (Language, Theme, Admin portal button) */}
          <div className="flex items-center gap-2 sm:gap-4 shrink-0">
            {/* Quick search affordance */}
            <button
              onClick={onOpenSearch}
              className="flex items-center gap-1.5 px-2 py-0.5 rounded text-slate-300 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer text-xs"
              title={lang === 'so' ? 'Raadi wax kasta' : 'Search portal'}
            >
              <Search className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{lang === 'so' ? 'Raadi' : 'Search'}</span>
            </button>

            {/* Language toggle */}
            <button
              onClick={onToggleLang}
              className="flex items-center gap-1 px-2 py-0.5 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors cursor-pointer font-medium text-xs"
              title="Beddel Luqadda / Toggle Language"
            >
              <Globe className="w-3.5 h-3.5 text-sky-400" />
              <span>{lang === 'so' ? 'English' : 'Af Soomaali'}</span>
            </button>

            {/* Dark / Light Mode Toggle */}
            <button
              onClick={onToggleDarkMode}
              className="p-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors cursor-pointer"
              title={darkMode ? 'U beddel Iftiinka' : 'U beddel Mugdiga'}
              aria-label="Toggle theme"
            >
              {darkMode ? <Sun className="w-3.5 h-3.5 text-amber-300" /> : <Moon className="w-3.5 h-3.5 text-slate-300" />}
            </button>

            {/* Admin Entrance */}
            <button
              onClick={onOpenAdmin}
              className="flex items-center gap-1.5 px-2.5 py-0.5 rounded bg-emerald-800 hover:bg-emerald-700 text-emerald-100 font-medium text-xs transition-colors cursor-pointer shadow-xs"
            >
              <Lock className="w-3 h-3 text-emerald-300" />
              <span className="hidden sm:inline">{lang === 'so' ? 'Albaabka Maamulka' : 'Admin Portal'}</span>
              <span className="sm:hidden">Admin</span>
            </button>
          </div>
        </div>
      </div>

      {/* 2. Primary Navigation Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between gap-4 h-18">
          {/* Zone 1: Brand Wordmark */}
          <button 
            onClick={() => handleNavClick('home')}
            className="flex items-center gap-3 text-left cursor-pointer focus:outline-hidden"
          >
            <OfficialEmblem size="md" />
          </button>

          {/* Zone 2: Desktop Nav Links */}
          <nav className="hidden xl:flex items-center gap-5 text-sm font-medium text-slate-700 dark:text-slate-300">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`transition-colors whitespace-nowrap cursor-pointer py-1 border-b-2 text-xs 2xl:text-sm ${
                  activeSection === item.id
                    ? 'border-emerald-700 dark:border-emerald-500 text-emerald-800 dark:text-emerald-400 font-semibold'
                    : 'border-transparent hover:text-emerald-700 dark:hover:text-emerald-400'
                }`}
              >
                {lang === 'so' ? item.labelSo : item.labelEn}
              </button>
            ))}
          </nav>

          {/* Zone 3: Primary Action & Mobile Menu Toggle */}
          <div className="flex items-center gap-3 shrink-0">
            <button
              onClick={() => handleNavClick('applications')}
              className="hidden sm:flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-emerald-800 hover:bg-emerald-900 dark:bg-emerald-700 dark:hover:bg-emerald-600 rounded-lg shadow-sm transition-colors whitespace-nowrap cursor-pointer"
            >
              <span>{lang === 'so' ? 'Codso Adeeg' : 'Apply Online'}</span>
            </button>

            {/* Mobile hamburger button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="xl:hidden p-2 rounded-lg text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 cursor-pointer"
              aria-label="Fur liiska"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="xl:hidden border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 px-4 py-4 space-y-2 max-h-[80vh] overflow-y-auto">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => handleNavClick(item.id)}
              className={`w-full text-left px-3 py-2.5 rounded-md text-sm font-medium transition-colors ${
                activeSection === item.id
                  ? 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-800 dark:text-emerald-300 font-semibold'
                  : 'text-slate-700 dark:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
              }`}
            >
              {lang === 'so' ? item.labelSo : item.labelEn}
            </button>
          ))}
          <div className="pt-3 border-t border-slate-200 dark:border-slate-800 flex flex-col gap-2">
            <button
              onClick={() => handleNavClick('applications')}
              className="w-full text-center py-2.5 px-4 rounded-lg bg-emerald-800 text-white font-semibold text-sm"
            >
              {lang === 'so' ? 'Codso Adeeg Online' : 'Apply Online'}
            </button>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                onOpenAdmin();
              }}
              className="w-full text-center py-2.5 px-4 rounded-lg bg-slate-800 text-slate-200 font-medium text-sm flex items-center justify-center gap-2"
            >
              <Lock className="w-4 h-4 text-emerald-400" />
              <span>{lang === 'so' ? 'Gal Albaabka Maamulka (Admin)' : 'Open Admin Portal'}</span>
            </button>
          </div>
        </div>
      )}
    </header>
  );
};

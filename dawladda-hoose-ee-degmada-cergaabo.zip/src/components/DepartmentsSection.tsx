import React, { useState } from 'react';
import { Language, Department } from '../types';
import { 
  Building2, 
  DollarSign, 
  Compass, 
  Trees, 
  Hammer, 
  HeartHandshake, 
  ShieldCheck, 
  Phone, 
  Mail, 
  CheckCircle2, 
  ChevronRight
} from 'lucide-react';

interface DepartmentsSectionProps {
  lang: Language;
  departments: Department[];
  onSelectDepartmentServices: (deptId: string) => void;
}

export const DepartmentsSection: React.FC<DepartmentsSectionProps> = ({
  lang,
  departments,
  onSelectDepartmentServices
}) => {
  const [selectedDeptId, setSelectedDeptId] = useState<string>(departments[0]?.id || 'maaliyadda');

  const getIcon = (iconName: string) => {
    switch (iconName) {
      case 'DollarSign': return DollarSign;
      case 'Compass': return Compass;
      case 'Trees': return Trees;
      case 'Construction': return Hammer;
      case 'HeartHandshake': return HeartHandshake;
      case 'ShieldCheck': return ShieldCheck;
      default: return Building2;
    }
  };

  const activeDept = departments.find(d => d.id === selectedDeptId) || departments[0];
  const ActiveIcon = getIcon(activeDept.icon);

  return (
    <section id="departments" className="py-16 sm:py-20 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Section Header */}
        <div className="max-w-3xl mb-12">
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-800 dark:text-emerald-400 tracking-wider uppercase">
            <Building2 className="w-4 h-4 text-emerald-800 dark:text-emerald-400" />
            <span>{lang === 'so' ? 'Qaybaha Maamulka' : 'Administrative Organs'}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-slate-900 dark:text-white font-display mt-2">
            {lang === 'so' ? 'Waaxyaha Dawladda Hoose ee Ceerigaabo' : 'Ceerigaabo Municipal Departments'}
          </h2>
          <p className="mt-3 text-base text-slate-600 dark:text-slate-300">
            {lang === 'so'
              ? 'Dawladda hoose waxay ka kooban tahay 6 waaxood oo u taagan u adeegidda shacabka ku nool degmada Ceerigaabo iyo gobolka Sanaag.'
              : 'Ceerigaabo Local Government operates 6 dedicated functional directorates ensuring seamless citizen service delivery across Sanaag.'}
          </p>
        </div>

        {/* Tab Selection Bar */}
        <div className="flex items-center gap-2 overflow-x-auto pb-3 mb-8 no-scrollbar">
          {departments.map((dept) => {
            const Icon = getIcon(dept.icon);
            const isSelected = dept.id === selectedDeptId;
            return (
              <button
                key={dept.id}
                onClick={() => setSelectedDeptId(dept.id)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs sm:text-sm font-semibold whitespace-nowrap transition-colors cursor-pointer border ${
                  isSelected
                    ? 'bg-emerald-800 dark:bg-emerald-700 text-white border-emerald-800 dark:border-emerald-700 shadow-sm'
                    : 'bg-slate-50 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700'
                }`}
              >
                <Icon className={`w-4 h-4 ${isSelected ? 'text-amber-300' : 'text-slate-500 dark:text-slate-400'}`} />
                <span>{lang === 'so' ? dept.nameSo : dept.nameEn}</span>
              </button>
            );
          })}
        </div>

        {/* Active Department Detail Card */}
        {activeDept && (
          <div className="bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 sm:p-8 shadow-xs">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
              {/* Left Column: Department Description & Responsibilities */}
              <div className="lg:col-span-8 space-y-6">
                <div className="flex items-center gap-3">
                  <div className="p-3 rounded-xl bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-400">
                    <ActiveIcon className="w-7 h-7" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-bold text-slate-900 dark:text-white font-display">
                      {lang === 'so' ? activeDept.nameSo : activeDept.nameEn}
                    </h3>
                    <div className="flex items-center gap-2 text-xs text-slate-500 dark:text-slate-400 mt-1">
                      <span>{lang === 'so' ? 'Hoggaanka:' : 'Director:'}</span>
                      <strong className="text-slate-700 dark:text-slate-200 font-semibold">
                        {lang === 'so' ? activeDept.directorSo : activeDept.directorEn}
                      </strong>
                    </div>
                  </div>
                </div>

                <p className="text-sm sm:text-base text-slate-700 dark:text-slate-300 leading-relaxed">
                  {lang === 'so' ? activeDept.descriptionSo : activeDept.descriptionEn}
                </p>

                {/* Key Responsibilities */}
                <div>
                  <h4 className="text-sm font-bold uppercase tracking-wider text-slate-900 dark:text-white mb-3">
                    {lang === 'so' ? 'Shaqooyinka & Waajibaadka Ugu Muhiimsan' : 'Key Departmental Mandates'}
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {(lang === 'so' ? activeDept.responsibilitiesSo : activeDept.responsibilitiesEn).map((resp, idx) => (
                      <div key={idx} className="flex items-start gap-2.5 p-3 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-xs sm:text-sm text-slate-700 dark:text-slate-300">
                        <CheckCircle2 className="w-4 h-4 text-emerald-800 dark:text-emerald-400 shrink-0 mt-0.5" />
                        <span>{resp}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Right Column: Direct Contact & Action */}
              <div className="lg:col-span-4 flex flex-col justify-between p-6 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl space-y-6">
                <div>
                  <h4 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider mb-4">
                    {lang === 'so' ? 'Xiriirka Tooska ah ee Waaxda' : 'Direct Department Contact'}
                  </h4>

                  <div className="space-y-3.5 text-xs sm:text-sm">
                    <div className="flex items-center gap-3 text-slate-700 dark:text-slate-300">
                      <div className="p-2 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                        <Phone className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-[11px] text-slate-600 dark:text-slate-400">{lang === 'so' ? 'Taleefan' : 'Phone'}</div>
                        <div className="font-semibold text-slate-900 dark:text-white font-mono">{activeDept.phone}</div>
                      </div>
                    </div>

                    <div className="flex items-center gap-3 text-slate-700 dark:text-slate-300">
                      <div className="p-2 rounded bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400">
                        <Mail className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="text-[11px] text-slate-600 dark:text-slate-400">{lang === 'so' ? 'Email' : 'Official Email'}</div>
                        <div className="font-semibold text-slate-900 dark:text-white truncate">{activeDept.email}</div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t border-slate-200 dark:border-slate-800">
                  <button
                    onClick={() => onSelectDepartmentServices(activeDept.id)}
                    className="w-full py-2.5 px-4 rounded-lg bg-emerald-800 hover:bg-emerald-900 dark:bg-emerald-700 dark:hover:bg-emerald-600 text-white font-semibold text-xs sm:text-sm transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-xs"
                  >
                    <span>{lang === 'so' ? 'Eeg Adeegyada Waaxdan' : 'Explore Department Services'}</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

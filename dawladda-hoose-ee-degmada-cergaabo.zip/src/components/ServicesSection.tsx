import React, { useState } from 'react';
import { Language, MunicipalService } from '../types';
import { 
  Building2, 
  Search, 
  Clock, 
  DollarSign, 
  FileText, 
  Check, 
  ArrowRight, 
  Calculator,
  Briefcase,
  ChevronDown,
  ChevronUp
} from 'lucide-react';

interface ServicesSectionProps {
  lang: Language;
  services: MunicipalService[];
  onApplyForService: (serviceId: string) => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({
  lang,
  services,
  onApplyForService
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [expandedServiceId, setExpandedServiceId] = useState<string | null>(null);

  // Fee calculator modal state
  const [showFeeCalculator, setShowFeeCalculator] = useState<boolean>(false);
  const [calcBizType, setCalcBizType] = useState<string>('retail');
  const [calcEmployees, setCalcEmployees] = useState<number>(3);
  const [calcLocation, setCalcLocation] = useState<string>('central');

  const filteredServices = services.filter((svc) => {
    const matchesCat = selectedCategory === 'all' || svc.category === selectedCategory;
    const query = searchQuery.toLowerCase();
    const matchesQuery = 
      svc.titleSo.toLowerCase().includes(query) ||
      svc.titleEn.toLowerCase().includes(query) ||
      svc.descriptionSo.toLowerCase().includes(query) ||
      svc.descriptionEn.toLowerCase().includes(query);
    return matchesCat && matchesQuery;
  });

  // Calculate estimated fee
  const calculateEstimatedFee = () => {
    let base = 35;
    if (calcBizType === 'wholesale') base = 90;
    if (calcBizType === 'restaurant') base = 60;
    if (calcBizType === 'fuel_station') base = 160;
    if (calcBizType === 'pharmacy') base = 50;

    if (calcLocation === 'central') base += 25;
    if (calcEmployees > 5) base += 20;

    return base;
  };

  const categories = [
    { id: 'all', labelSo: 'Dhammaan Adeegyada', labelEn: 'All Services' },
    { id: 'business', labelSo: 'Ganacsiga & Shatiyada', labelEn: 'Business & Trade' },
    { id: 'land', labelSo: 'Dhulka & Dhismaha', labelEn: 'Land & Building' },
    { id: 'sanitation', labelSo: 'Nadaafadda & Waddooyinka', labelEn: 'Sanitation & Roads' },
    { id: 'social', labelSo: 'Shahaadooyinka & Bulshada', labelEn: 'Civil & Social' },
    { id: 'tax', labelSo: 'Canshuuraha Degmada', labelEn: 'Municipal Taxes' }
  ];

  return (
    <section id="services" className="py-16 sm:py-20 bg-slate-50 dark:bg-slate-900/60 border-b border-slate-200 dark:border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-emerald-800 dark:text-emerald-400 tracking-wider uppercase">
              <Building2 className="w-4 h-4 text-emerald-800 dark:text-emerald-400" />
              <span>{lang === 'so' ? 'Bixinta Adeegyada' : 'Municipal Services'}</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-slate-900 dark:text-white font-display mt-2">
              {lang === 'so' ? 'Adeegyada Rasmiga ah ee Dawladda Hoose' : 'Official Public Services Catalog'}
            </h2>
            <p className="mt-2 text-base text-slate-600 dark:text-slate-300 max-w-2xl">
              {lang === 'so'
                ? 'Halkan ka baar adeeg kasta oo ay bixiso Dawladda Hoose ee Degmada Ceerigaabo, shuruudaha looga baahan yahay, iyo khidmadaha rasmiga ah.'
                : 'Browse municipal procedures, eligibility requirements, certified fees, and start your online application instantly.'}
            </p>
          </div>

          {/* Calculator Trigger */}
          <button
            onClick={() => setShowFeeCalculator(true)}
            className="self-start md:self-end flex items-center gap-2 px-4 py-2.5 rounded-lg bg-emerald-800 hover:bg-emerald-900 dark:bg-emerald-700 dark:hover:bg-emerald-600 text-white text-xs sm:text-sm font-semibold transition-colors shadow-xs cursor-pointer"
          >
            <Calculator className="w-4 h-4" />
            <span>{lang === 'so' ? 'Xisaabiyaha Shatiga & Canshuurta' : 'Fee Estimator'}</span>
          </button>
        </div>

        {/* Filter and Search Bar */}
        <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4 mb-8">
          {/* Category Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-2 lg:pb-0 no-scrollbar">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3.5 py-2 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer border ${
                  selectedCategory === cat.id
                    ? 'bg-emerald-800 dark:bg-emerald-700 text-white border-emerald-800 dark:border-emerald-700 shadow-xs'
                    : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-100 dark:hover:bg-slate-800'
                }`}
              >
                {lang === 'so' ? cat.labelSo : cat.labelEn}
              </button>
            ))}
          </div>

          {/* Search Input */}
          <div className="relative min-w-[280px]">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={lang === 'so' ? 'Raadi adeeg, shati, rukhsad...' : 'Search services, permits, licenses...'}
              className="w-full pl-9 pr-4 py-2 rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white text-xs sm:text-sm focus:ring-2 focus:ring-emerald-500 outline-hidden"
            />
          </div>
        </div>

        {/* Services List / Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredServices.map((svc) => {
            const isExpanded = expandedServiceId === svc.id;
            return (
              <div
                key={svc.id}
                className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl p-6 shadow-xs hover:border-emerald-600/50 transition-all flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-4">
                    <h3 className="text-lg font-bold text-slate-900 dark:text-white font-display">
                      {lang === 'so' ? svc.titleSo : svc.titleEn}
                    </h3>
                  </div>

                  <p className="mt-2 text-xs sm:text-sm text-slate-600 dark:text-slate-300 leading-relaxed">
                    {lang === 'so' ? svc.descriptionSo : svc.descriptionEn}
                  </p>

                  {/* Metadata: Fee & Duration */}
                  <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 grid grid-cols-2 gap-3 text-xs">
                    <div className="flex items-center gap-2 text-slate-700 dark:text-slate-300">
                      <DollarSign className="w-4 h-4 text-emerald-800 dark:text-emerald-400 shrink-0" />
                      <div>
                        <span className="text-[11px] text-slate-600 dark:text-slate-400 block">{lang === 'so' ? 'Khidmadda' : 'Fee'}</span>
                        <strong className="text-slate-900 dark:text-white font-semibold">
                          {lang === 'so' ? svc.feeSo : svc.feeEn}
                        </strong>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 text-slate-700 dark:text-slate-300">
                      <Clock className="w-4 h-4 text-sky-800 dark:text-sky-400 shrink-0" />
                      <div>
                        <span className="text-[11px] text-slate-600 dark:text-slate-400 block">{lang === 'so' ? 'Muddada' : 'Timeframe'}</span>
                        <strong className="text-slate-900 dark:text-white font-semibold">
                          {lang === 'so' ? svc.durationSo : svc.durationEn}
                        </strong>
                      </div>
                    </div>
                  </div>

                  {/* Expandable Requirements Details */}
                  {isExpanded && (
                    <div className="mt-4 pt-4 border-t border-slate-100 dark:border-slate-800 space-y-2">
                      <h4 className="text-xs font-bold uppercase tracking-wider text-slate-800 dark:text-slate-200">
                        {lang === 'so' ? 'Dukumentiyada & Shuruudaha:' : 'Mandatory Requirements:'}
                      </h4>
                      <ul className="space-y-1.5 text-xs text-slate-600 dark:text-slate-300">
                        {(lang === 'so' ? svc.requirementsSo : svc.requirementsEn).map((req, rIdx) => (
                          <li key={rIdx} className="flex items-start gap-2">
                            <Check className="w-3.5 h-3.5 text-emerald-800 dark:text-emerald-400 shrink-0 mt-0.5" />
                            <span>{req}</span>
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}
                </div>

                {/* Actions bottom */}
                <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between gap-3">
                  <button
                    onClick={() => setExpandedServiceId(isExpanded ? null : svc.id)}
                    className="flex items-center gap-1 text-xs text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white font-medium cursor-pointer"
                  >
                    <span>{isExpanded ? (lang === 'so' ? 'Qari Shuruudaha' : 'Hide Details') : (lang === 'so' ? 'Eeg Shuruudaha' : 'View Requirements')}</span>
                    {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                  </button>

                  <button
                    onClick={() => onApplyForService(svc.id)}
                    className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-emerald-800 hover:bg-emerald-900 dark:bg-emerald-700 dark:hover:bg-emerald-600 text-white font-semibold text-xs transition-colors shadow-xs cursor-pointer"
                  >
                    <span>{lang === 'so' ? 'Codso Hadda' : 'Apply Now'}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {filteredServices.length === 0 && (
          <div className="p-12 text-center bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
            <p className="text-sm text-slate-500">
              {lang === 'so' ? 'Wax adeeg ah lagama helin baadi-goobkaaga.' : 'No services found matching your criteria.'}
            </p>
          </div>
        )}
      </div>

      {/* Fee Estimator Modal */}
      {showFeeCalculator && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs">
          <div className="bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 max-w-md w-full shadow-2xl relative">
            <div className="flex items-center justify-between pb-3 border-b border-slate-200 dark:border-slate-800">
              <div className="flex items-center gap-2">
                <div className="p-2 rounded bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-400">
                  <Calculator className="w-5 h-5" />
                </div>
                <h3 className="text-base font-bold text-slate-900 dark:text-white font-display">
                  {lang === 'so' ? 'Xisaabiyaha Shatiga Ganacsiga' : 'Business License Fee Estimator'}
                </h3>
              </div>
              <button
                onClick={() => setShowFeeCalculator(false)}
                className="text-slate-400 hover:text-slate-600 dark:hover:text-white text-sm cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="mt-4 space-y-4 text-xs sm:text-sm">
              <div>
                <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                  {lang === 'so' ? 'Nooca Ganacsiga' : 'Business Sector'}
                </label>
                <select
                  value={calcBizType}
                  onChange={(e) => setCalcBizType(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-hidden"
                >
                  <option value="retail">{lang === 'so' ? 'Dukaan Tafaariiq / Raashin ($35 base)' : 'Retail Shop ($35 base)'}</option>
                  <option value="wholesale">{lang === 'so' ? 'Ganacsi Weyn / Jumlo ($90 base)' : 'Wholesale Merchant ($90 base)'}</option>
                  <option value="restaurant">{lang === 'so' ? 'Maqaayad / Hotel ($60 base)' : 'Restaurant / Cafe ($60 base)'}</option>
                  <option value="pharmacy">{lang === 'so' ? 'Farmashi / Xarun Caafimaad ($50 base)' : 'Pharmacy / Clinic ($50 base)'}</option>
                  <option value="fuel_station">{lang === 'so' ? 'Kaalinta Shidaalka ($160 base)' : 'Fuel Station ($160 base)'}</option>
                </select>
              </div>

              <div>
                <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                  {lang === 'so' ? 'Goobta Ganacsiga' : 'Location Zone'}
                </label>
                <select
                  value={calcLocation}
                  onChange={(e) => setCalcLocation(e.target.value)}
                  className="w-full px-3 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white outline-hidden"
                >
                  <option value="central">{lang === 'so' ? 'Suuqa Weyn / Laamiga Wadnaha (+ $25)' : 'Central Bazaar / Main Boulevard (+ $25)'}</option>
                  <option value="suburban">{lang === 'so' ? 'Xaafadaha Gudaha (Standard Zone)' : 'Residential Ward (Standard Zone)'}</option>
                </select>
              </div>

              <div>
                <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                  {lang === 'so' ? 'Tirada Shaqaalaha' : 'Staff Count'}: {calcEmployees}
                </label>
                <input
                  type="range"
                  min="1"
                  max="20"
                  value={calcEmployees}
                  onChange={(e) => setCalcEmployees(Number(e.target.value))}
                  className="w-full accent-emerald-600"
                />
              </div>

              {/* Result Card */}
              <div className="p-4 rounded-xl bg-slate-100 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 flex items-center justify-between">
                <div>
                  <span className="text-xs text-slate-500 dark:text-slate-400 block">{lang === 'so' ? 'Qiyaasta Khidmadda Sanadlaha' : 'Estimated Annual Fee'}</span>
                  <span className="text-xs text-emerald-800 dark:text-emerald-400">{lang === 'so' ? 'Sanadkii 2026' : 'For 2026 Season'}</span>
                </div>
                <div className="text-2xl font-bold text-slate-900 dark:text-white font-mono">
                  ${calculateEstimatedFee()}.00 USD
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={() => {
                    setShowFeeCalculator(false);
                    onApplyForService('shati-ganacsi');
                  }}
                  className="w-full py-2.5 rounded-lg bg-emerald-800 hover:bg-emerald-900 text-white font-semibold text-xs sm:text-sm cursor-pointer"
                >
                  {lang === 'so' ? 'Horay u Soco & Codso Shatiga' : 'Proceed to Apply'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};

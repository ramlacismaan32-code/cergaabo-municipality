import React, { useState } from 'react';
import { Language, MunicipalService, CitizenApplication } from '../types';
import { 
  FileCheck2, 
  Search, 
  Send, 
  CheckCircle, 
  Printer, 
  Clock, 
  AlertCircle,
  Building,
  ArrowRight,
  ShieldAlert,
  ChevronRight,
  Check
} from 'lucide-react';
import { SomalilandFlag } from './SomalilandFlag';

interface OnlineApplicationsSectionProps {
  lang: Language;
  services: MunicipalService[];
  applications: CitizenApplication[];
  onNewApplication: (app: CitizenApplication) => void;
  preselectedServiceId?: string | null;
}

export const OnlineApplicationsSection: React.FC<OnlineApplicationsSectionProps> = ({
  lang,
  services,
  applications,
  onNewApplication,
  preselectedServiceId
}) => {
  const [activeTab, setActiveTab] = useState<'apply' | 'track'>('apply');
  
  // Tracking form state
  const [trackingIdInput, setTrackingIdInput] = useState<string>('');
  const [foundApplication, setFoundApplication] = useState<CitizenApplication | null>(null);
  const [trackingSearched, setTrackingSearched] = useState<boolean>(false);

  // Application wizard state
  const [step, setStep] = useState<number>(1);
  const [selectedServiceId, setSelectedServiceId] = useState<string>(preselectedServiceId || services[0]?.id || 'shati-ganacsi');
  const [fullName, setFullName] = useState<string>('');
  const [nationalIdOrPhone, setNationalIdOrPhone] = useState<string>('');
  const [neighborhood, setNeighborhood] = useState<string>('Xaafadda Horseed');
  const [specificDetails, setSpecificDetails] = useState<string>('');
  const [businessOrPropertyRef, setBusinessOrPropertyRef] = useState<string>('');
  const [declarationChecked, setDeclarationChecked] = useState<boolean>(false);

  // Newly created application
  const [newlyCreatedApp, setNewlyCreatedApp] = useState<CitizenApplication | null>(null);

  // Sync preselectedServiceId
  React.useEffect(() => {
    if (preselectedServiceId) {
      setSelectedServiceId(preselectedServiceId);
      setActiveTab('apply');
      setStep(1);
    }
  }, [preselectedServiceId]);

  const selectedService = services.find(s => s.id === selectedServiceId) || services[0];

  const handleTrackSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const query = trackingIdInput.trim().toUpperCase();
    const result = applications.find(a => a.id.toUpperCase() === query);
    setFoundApplication(result || null);
    setTrackingSearched(true);
  };

  const handleDirectDemoLookup = (demoId: string) => {
    setTrackingIdInput(demoId);
    const result = applications.find(a => a.id.toUpperCase() === demoId.toUpperCase());
    setFoundApplication(result || null);
    setTrackingSearched(true);
  };

  const handleApplicationSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!declarationChecked) return;

    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const appId = `CRG-2026-${randomSuffix}`;

    const newApp: CitizenApplication = {
      id: appId,
      applicantName: fullName,
      nationalIdOrPhone: nationalIdOrPhone,
      serviceId: selectedServiceId,
      serviceName: lang === 'so' ? selectedService.titleSo : selectedService.titleEn,
      neighborhood: neighborhood,
      details: `${businessOrPropertyRef ? businessOrPropertyRef + ' — ' : ''}${specificDetails}`,
      status: 'Gudbiyey (Submitted)',
      submittedDate: 'Maanta (Today)',
      estimatedFee: selectedService.feeSo.split('(')[0] || '$35.00',
      notes: lang === 'so' 
        ? 'Codsigaaga si guul leh ayaa loo diiwaangeliyay. Waaxda ay khuseyso ayaa kormeer ku samaynaysa.'
        : 'Your application has been received into the municipal queue for verification.'
    };

    onNewApplication(newApp);
    setNewlyCreatedApp(newApp);
    setStep(4); // Success step
  };

  const handleResetForm = () => {
    setStep(1);
    setFullName('');
    setNationalIdOrPhone('');
    setSpecificDetails('');
    setBusinessOrPropertyRef('');
    setDeclarationChecked(false);
    setNewlyCreatedApp(null);
  };

  const getStatusStepIndex = (status: string) => {
    if (status.includes('Gudbiyey') || status.includes('Submitted')) return 1;
    if (status.includes('Baaris') || status.includes('Review')) return 2;
    if (status.includes('Ansixiyey') || status.includes('Approved')) return 3;
    if (status.includes('Dhamaystiran') || status.includes('Completed')) return 4;
    return 1;
  };

  return (
    <section id="applications" className="py-16 sm:py-20 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Section Header */}
        <div className="max-w-3xl mb-10">
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-800 dark:text-emerald-400 tracking-wider uppercase">
            <FileCheck2 className="w-4 h-4 text-emerald-800 dark:text-emerald-400" />
            <span>{lang === 'so' ? 'Albaabka Adeegyada Digital-ka' : 'Citizen E-Portal'}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-slate-900 dark:text-white font-display mt-2">
            {lang === 'so' ? 'Codsiyada Adeegyada ee Online-ka' : 'Municipal Online Applications'}
          </h2>
          <p className="mt-3 text-base text-slate-600 dark:text-slate-300">
            {lang === 'so'
              ? 'Kaga codso shatiyada, rukhsadaha, iyo adeegyada degmada halkan adigoo gurigaaga jooga, isla markaana la soco marxaladaha uu codsigaagu marayo.'
              : 'Submit applications for municipal licenses, permits, and certificates directly online, and track your case progress in real-time.'}
          </p>
        </div>

        {/* Tab Controls (Apply vs Track) */}
        <div className="flex items-center gap-2 p-1.5 bg-slate-100 dark:bg-slate-800 rounded-xl max-w-md mb-8">
          <button
            onClick={() => setActiveTab('apply')}
            className={`flex-1 py-2 px-4 rounded-lg text-xs sm:text-sm font-semibold transition-colors cursor-pointer flex items-center justify-center gap-2 ${
              activeTab === 'apply'
                ? 'bg-white dark:bg-slate-900 text-emerald-800 dark:text-emerald-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Send className="w-4 h-4" />
            <span>{lang === 'so' ? 'Gudbi Codsi Cusub' : 'Submit Application'}</span>
          </button>

          <button
            onClick={() => setActiveTab('track')}
            className={`flex-1 py-2 px-4 rounded-lg text-xs sm:text-sm font-semibold transition-colors cursor-pointer flex items-center justify-center gap-2 ${
              activeTab === 'track'
                ? 'bg-white dark:bg-slate-900 text-emerald-800 dark:text-emerald-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
          >
            <Search className="w-4 h-4" />
            <span>{lang === 'so' ? 'Raad-raac Codsigaaga' : 'Track Application'}</span>
          </button>
        </div>

        {/* TAB 1: SUBMIT APPLICATION WIZARD */}
        {activeTab === 'apply' && (
          <div className="bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 sm:p-10 shadow-xs">
            {step < 4 && (
              <div className="mb-8">
                <div className="flex items-center justify-between max-w-2xl mx-auto mb-2 text-xs font-semibold text-slate-500 dark:text-slate-400">
                  <span className={step >= 1 ? 'text-emerald-800 dark:text-emerald-400 font-bold' : ''}>
                    1. {lang === 'so' ? 'Doorashada Adeegga' : 'Select Service'}
                  </span>
                  <span className={step >= 2 ? 'text-emerald-800 dark:text-emerald-400 font-bold' : ''}>
                    2. {lang === 'so' ? 'Xogta Qofka' : 'Applicant Info'}
                  </span>
                  <span className={step >= 3 ? 'text-emerald-800 dark:text-emerald-400 font-bold' : ''}>
                    3. {lang === 'so' ? 'Xaqiijin & Gudbin' : 'Review & Submit'}
                  </span>
                </div>
                <div className="w-full bg-slate-200 dark:bg-slate-700 h-2 rounded-full overflow-hidden max-w-2xl mx-auto">
                  <div
                    className="bg-emerald-800 dark:bg-emerald-500 h-full transition-all duration-300"
                    style={{ width: `${(step / 3) * 100}%` }}
                  />
                </div>
              </div>
            )}

            {/* STEP 1: Choose Service */}
            {step === 1 && (
              <div className="max-w-2xl mx-auto space-y-6">
                <div>
                  <h3 className="text-xl font-bold text-slate-900 dark:text-white font-display">
                    {lang === 'so' ? 'Dooro Adeegga Aad Codsanayso' : 'Select the Municipal Service'}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-1">
                    {lang === 'so' ? 'Dooro shatiga ama adeegga aad u baahan tahay si loo bilaabo diiwaangelinta.' : 'Choose the appropriate category to proceed with formal processing.'}
                  </p>
                </div>

                <div className="space-y-3">
                  {services.map((svc) => {
                    const isSelected = svc.id === selectedServiceId;
                    return (
                      <div
                        key={svc.id}
                        onClick={() => setSelectedServiceId(svc.id)}
                        className={`p-4 rounded-xl border transition-all cursor-pointer flex items-center justify-between ${
                          isSelected
                            ? 'bg-emerald-50/80 dark:bg-emerald-950/40 border-emerald-800 dark:border-emerald-600 shadow-xs'
                            : 'bg-white dark:bg-slate-900 border-slate-200 dark:border-slate-800 hover:border-slate-300 dark:hover:border-slate-700'
                        }`}
                      >
                        <div className="pr-4">
                          <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                            {lang === 'so' ? svc.titleSo : svc.titleEn}
                          </h4>
                          <p className="text-xs text-slate-600 dark:text-slate-400 mt-0.5 line-clamp-1">
                            {lang === 'so' ? svc.descriptionSo : svc.descriptionEn}
                          </p>
                          <div className="flex items-center gap-3 text-[11px] text-slate-500 dark:text-slate-400 mt-2">
                            <span>Khidmadda: <strong className="text-emerald-800 dark:text-emerald-400">{svc.feeSo.split('(')[0]}</strong></span>
                            <span>·</span>
                            <span>Muddada: <strong>{svc.durationSo}</strong></span>
                          </div>
                        </div>
                        <div className={`w-5 h-5 rounded-full border flex items-center justify-center shrink-0 ${
                          isSelected ? 'border-emerald-800 bg-emerald-800 text-white' : 'border-slate-300 dark:border-slate-600'
                        }`}>
                          {isSelected && <Check className="w-3.5 h-3.5 stroke-[3]" />}
                        </div>
                      </div>
                    );
                  })}
                </div>

                <div className="flex justify-end pt-4">
                  <button
                    onClick={() => setStep(2)}
                    className="px-6 py-2.5 rounded-lg bg-emerald-800 hover:bg-emerald-900 text-white font-semibold text-xs sm:text-sm flex items-center gap-2 cursor-pointer shadow-xs"
                  >
                    <span>{lang === 'so' ? 'Tallaabada Xigta' : 'Next Step'}</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {/* STEP 2: Applicant & Entity Info */}
            {step === 2 && (
              <div className="max-w-2xl mx-auto space-y-6">
                <div>
                  <h3 className="text-xl font-bold text-slate-900 dark:text-white font-display">
                    {lang === 'so' ? 'Xogta Codsadaha & Goobta' : 'Applicant & Location Details'}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-1">
                    {lang === 'so' 
                      ? `Waxaad codsanaysaa: ${selectedService.titleSo}` 
                      : `You are applying for: ${selectedService.titleEn}`}
                  </p>
                </div>

                <div className="space-y-4 text-xs sm:text-sm">
                  <div>
                    <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                      {lang === 'so' ? 'Magacaaga oo Buuxa (Saddexan)' : 'Full Name'} *
                    </label>
                    <input
                      type="text"
                      required
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder={lang === 'so' ? 'Tusaale: Jaamac Cabdi Maxamuud' : 'e.g. Jama Abdi Mohamud'}
                      className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-hidden"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                        {lang === 'so' ? 'Lambarka Telefoonka / Sahal / EVC' : 'Phone Number'} *
                      </label>
                      <input
                        type="tel"
                        required
                        value={nationalIdOrPhone}
                        onChange={(e) => setNationalIdOrPhone(e.target.value)}
                        placeholder="+252 90 7..."
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-hidden"
                      />
                    </div>

                    <div>
                      <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                        {lang === 'so' ? 'Xaafadda aad Deggan tahay / Goobta' : 'Ward / Neighborhood'} *
                      </label>
                      <select
                        value={neighborhood}
                        onChange={(e) => setNeighborhood(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white outline-hidden"
                      >
                        <option value="Xaafadda Daalo">Xaafadda Daalo</option>
                        <option value="Xaafadda Dayaxa">Xaafadda Dayaxa</option>
                        <option value="Xaafadda Surud">Xaafadda Surud</option>
                        <option value="Xaafadda Barwaaqo">Xaafadda Barwaaqo</option>
                        <option value="Waddada Maydh">Waddada Maydh</option>
                        <option value="Suuqa Weyn ee Ceerigaabo">Suuqa Weyn ee Ceerigaabo</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                      {lang === 'so' ? 'Magaca Ganacsiga / Lambarka Guriga / Mulkiyadda' : 'Business Name or Property Reference'} *
                    </label>
                    <input
                      type="text"
                      required
                      value={businessOrPropertyRef}
                      onChange={(e) => setBusinessOrPropertyRef(e.target.value)}
                      placeholder={lang === 'so' ? 'Tusaale: Dukaanka Barwaaqo ama Guriga #204' : 'e.g. Barwaaqo Store or House #204'}
                      className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                      {lang === 'so' ? 'Faahfaahin Dheeraad ah oo Ku Saabsan Codsiga' : 'Additional Specifications'}
                    </label>
                    <textarea
                      rows={3}
                      value={specificDetails}
                      onChange={(e) => setSpecificDetails(e.target.value)}
                      placeholder={lang === 'so' ? 'Qor macluumaad kasta oo faahfaahinaya codsigaaga...' : 'Any specific details regarding your premises or request...'}
                      className="w-full px-3.5 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-hidden"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between pt-4 border-t border-slate-200 dark:border-slate-800">
                  <button
                    onClick={() => setStep(1)}
                    className="px-4 py-2 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 font-medium text-xs sm:text-sm cursor-pointer"
                  >
                    {lang === 'so' ? 'Dib u Noqo' : 'Back'}
                  </button>

                  <button
                    onClick={() => {
                      if (!fullName || !nationalIdOrPhone || !businessOrPropertyRef) {
                        alert(lang === 'so' ? 'Fadlan buuxi meelaha xiddigta (*) leh.' : 'Please fill in all mandatory fields.');
                        return;
                      }
                      setStep(3);
                    }}
                    className="px-6 py-2.5 rounded-lg bg-emerald-800 hover:bg-emerald-900 text-white font-semibold text-xs sm:text-sm flex items-center gap-2 cursor-pointer shadow-xs"
                  >
                    <span>{lang === 'so' ? 'Eeg & Xaqiiji' : 'Review Details'}</span>
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            )}

            {/* STEP 3: Review & Submit */}
            {step === 3 && (
              <form onSubmit={handleApplicationSubmit} className="max-w-2xl mx-auto space-y-6">
                <div>
                  <h3 className="text-xl font-bold text-slate-900 dark:text-white font-display">
                    {lang === 'so' ? 'Dib u Eegista & Xaqiijinta Codsiga' : 'Review & Official Submission'}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-1">
                    {lang === 'so' ? 'Fadlan hubi xogta aad gelisay ka hor inta aanad si rasmi ah u gudbin.' : 'Verify your inputs prior to final submission to the municipal records registry.'}
                  </p>
                </div>

                {/* Summary Card */}
                <div className="p-5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-3 text-xs sm:text-sm">
                  <div className="flex justify-between py-1.5 border-b border-slate-100 dark:border-slate-800">
                    <span className="text-slate-500">{lang === 'so' ? 'Adeegga' : 'Service'}:</span>
                    <strong className="text-slate-900 dark:text-white font-semibold">{lang === 'so' ? selectedService.titleSo : selectedService.titleEn}</strong>
                  </div>
                  <div className="flex justify-between py-1.5 border-b border-slate-100 dark:border-slate-800">
                    <span className="text-slate-500">{lang === 'so' ? 'Codsadaha' : 'Applicant'}:</span>
                    <strong className="text-slate-900 dark:text-white font-semibold">{fullName}</strong>
                  </div>
                  <div className="flex justify-between py-1.5 border-b border-slate-100 dark:border-slate-800">
                    <span className="text-slate-500">{lang === 'so' ? 'Telefoonka' : 'Phone'}:</span>
                    <strong className="text-slate-900 dark:text-white font-mono">{nationalIdOrPhone}</strong>
                  </div>
                  <div className="flex justify-between py-1.5 border-b border-slate-100 dark:border-slate-800">
                    <span className="text-slate-500">{lang === 'so' ? 'Xaafadda' : 'Ward'}:</span>
                    <strong className="text-slate-900 dark:text-white">{neighborhood}</strong>
                  </div>
                  <div className="flex justify-between py-1.5 border-b border-slate-100 dark:border-slate-800">
                    <span className="text-slate-500">{lang === 'so' ? 'Hantida / Ganacsiga' : 'Entity Reference'}:</span>
                    <strong className="text-slate-900 dark:text-white">{businessOrPropertyRef}</strong>
                  </div>
                  <div className="flex justify-between py-1.5">
                    <span className="text-slate-500">{lang === 'so' ? 'Qiyaasta Khidmadda' : 'Estimated Fee'}:</span>
                    <strong className="text-emerald-800 dark:text-emerald-400 font-bold">{selectedService.feeSo.split('(')[0]}</strong>
                  </div>
                </div>

                {/* Legal Declaration */}
                <div className="flex items-start gap-3 p-4 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/60 text-xs">
                  <input
                    type="checkbox"
                    id="declaration"
                    checked={declarationChecked}
                    onChange={(e) => setDeclarationChecked(e.target.checked)}
                    className="mt-0.5 rounded border-amber-400 text-emerald-600 focus:ring-emerald-500"
                  />
                  <label htmlFor="declaration" className="text-amber-900 dark:text-amber-200 leading-relaxed cursor-pointer">
                    {lang === 'so'
                      ? 'Waxaan caddaynayaa in dhammaan macluumaadka aan kor ku qoray ay yihiin kuwo sax ah oo xaqiiqada ku salaysan, anigoo ogsoon in macluumaad been ah ay horseedi karto baabi’inta codsigan iyo ciqaab sharci ah.'
                      : 'I solemnly certify that all details submitted herein are truthful and authentic, understanding that inaccurate submissions are subject to revocation and statutory municipal penalties.'}
                  </label>
                </div>

                <div className="flex items-center justify-between pt-4 border-t border-slate-200 dark:border-slate-800">
                  <button
                    type="button"
                    onClick={() => setStep(2)}
                    className="px-4 py-2 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 font-medium text-xs sm:text-sm cursor-pointer"
                  >
                    {lang === 'so' ? 'Wax Ka Beddel' : 'Edit'}
                  </button>

                  <button
                    type="submit"
                    disabled={!declarationChecked}
                    className={`px-6 py-2.5 rounded-lg text-white font-semibold text-xs sm:text-sm flex items-center gap-2 shadow-xs transition-colors cursor-pointer ${
                      declarationChecked ? 'bg-emerald-800 hover:bg-emerald-900' : 'bg-slate-400 cursor-not-allowed opacity-60'
                    }`}
                  >
                    <Send className="w-4 h-4" />
                    <span>{lang === 'so' ? 'Gudbi Codsiga Rasmiga ah' : 'Confirm & Submit'}</span>
                  </button>
                </div>
              </form>
            )}

            {/* STEP 4: Success Receipt */}
            {step === 4 && newlyCreatedApp && (
              <div className="max-w-xl mx-auto text-center space-y-6">
                <div className="w-16 h-16 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-400 flex items-center justify-center mx-auto shadow-sm">
                  <CheckCircle className="w-10 h-10" />
                </div>

                <div>
                  <h3 className="text-2xl font-bold text-slate-900 dark:text-white font-display">
                    {lang === 'so' ? 'Codsigaagii Waa La Diiwaangeliyay!' : 'Application Successfully Lodged!'}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-1.5">
                    {lang === 'so' 
                      ? 'Fadlan xafido lambarka tixraaca ee codsigaaga si aad ula socoto xaaladda maamul.' 
                      : 'Please retain your application tracking code to inspect its administrative milestone.'}
                  </p>
                </div>

                {/* Printable Official Slip Card */}
                <div className="p-6 rounded-2xl bg-white dark:bg-slate-900 border-2 border-dashed border-emerald-600/60 dark:border-emerald-500/60 text-left shadow-sm">
                  <div className="flex items-center justify-between pb-4 border-b border-slate-200 dark:border-slate-800">
                    <div>
                      <div className="flex items-center gap-1.5 mb-0.5">
                        <SomalilandFlag size="xs" />
                        <span className="text-[10px] uppercase tracking-widest text-emerald-800 dark:text-emerald-400 font-bold block">
                          Dawladda Hoose ee Ceerigaabo · Somaliland
                        </span>
                      </div>
                      <span className="text-xs font-bold text-slate-900 dark:text-white">
                        {lang === 'so' ? 'Warqadda Tixraaca Codsiga' : 'Official Application Receipt'}
                      </span>
                    </div>
                    <div className="text-right">
                      <span className="text-[11px] text-slate-400 block">{lang === 'so' ? 'Taariikhda' : 'Date'}</span>
                      <span className="text-xs font-mono font-semibold text-slate-700 dark:text-slate-300">2026-03-02</span>
                    </div>
                  </div>

                  <div className="my-4 py-3 px-4 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 flex items-center justify-between">
                    <div>
                      <span className="text-[11px] text-slate-500 dark:text-slate-400 block">{lang === 'so' ? 'Lambarka Tixraaca (Tracking Code)' : 'Application Tracking Code'}</span>
                      <span className="text-lg sm:text-xl font-bold font-mono text-emerald-800 dark:text-emerald-400 tracking-wider">
                        {newlyCreatedApp.id}
                      </span>
                    </div>
                    <span className="text-xs font-semibold px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                      Gudbiyey
                    </span>
                  </div>

                  <div className="space-y-2 text-xs text-slate-700 dark:text-slate-300">
                    <div className="flex justify-between">
                      <span className="text-slate-500">{lang === 'so' ? 'Codsadaha' : 'Applicant'}:</span>
                      <span className="font-semibold">{newlyCreatedApp.applicantName}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">{lang === 'so' ? 'Adeegga' : 'Service'}:</span>
                      <span className="font-semibold">{newlyCreatedApp.serviceName}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">{lang === 'so' ? 'Xaafadda' : 'Ward'}:</span>
                      <span>{newlyCreatedApp.neighborhood}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-slate-500">{lang === 'so' ? 'Qiyaasta Khidmadda' : 'Estimated Fee'}:</span>
                      <span className="font-semibold text-emerald-800 dark:text-emerald-400">{newlyCreatedApp.estimatedFee}</span>
                    </div>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
                  <button
                    onClick={() => window.print()}
                    className="w-full sm:w-auto px-5 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-800 dark:text-slate-200 hover:bg-slate-100 font-medium text-xs sm:text-sm flex items-center justify-center gap-2 cursor-pointer shadow-xs"
                  >
                    <Printer className="w-4 h-4" />
                    <span>{lang === 'so' ? 'Daabaco Warqadda (Print)' : 'Print Receipt'}</span>
                  </button>

                  <button
                    onClick={() => {
                      handleDirectDemoLookup(newlyCreatedApp.id);
                      setActiveTab('track');
                    }}
                    className="w-full sm:w-auto px-5 py-2.5 rounded-lg bg-emerald-800 hover:bg-emerald-900 text-white font-semibold text-xs sm:text-sm flex items-center justify-center gap-2 cursor-pointer shadow-xs"
                  >
                    <Search className="w-4 h-4" />
                    <span>{lang === 'so' ? 'La Soco Xaaladda Codsigan' : 'Track This Case'}</span>
                  </button>
                  
                  <button
                    onClick={handleResetForm}
                    className="w-full sm:w-auto px-4 py-2 text-slate-500 hover:text-slate-800 dark:hover:text-white text-xs cursor-pointer"
                  >
                    {lang === 'so' ? 'Gudbi Codsi Kale' : 'Submit Another'}
                  </button>
                </div>
              </div>
            )}
          </div>
        )}

        {/* TAB 2: TRACK APPLICATION STATUS */}
        {activeTab === 'track' && (
          <div className="bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 sm:p-10 shadow-xs max-w-3xl mx-auto">
            <div>
              <h3 className="text-xl font-bold text-slate-900 dark:text-white font-display">
                {lang === 'so' ? 'Raad-raaca & Hubinta Xaaladda Codsiga' : 'Application Milestone Tracker'}
              </h3>
              <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mt-1">
                {lang === 'so'
                  ? 'Geli lambarka tixraaca ee codsigaaga (tusaale: CRG-2026-1042) si aad u aragto halka uu marayo hawshaada.'
                  : 'Enter your assigned municipal tracking reference to review ongoing verification milestones.'}
              </p>
            </div>

            {/* Quick Demo Pre-fill Links */}
            <div className="mt-4 flex flex-wrap items-center gap-2 text-xs text-slate-500 dark:text-slate-400">
              <span>{lang === 'so' ? 'Tusaalooyin diyaarsan:' : 'Try sample case:'}</span>
              <button
                type="button"
                onClick={() => handleDirectDemoLookup('CRG-2026-1042')}
                className="px-2 py-1 rounded bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-emerald-800 dark:text-emerald-400 font-mono font-medium hover:bg-slate-100 cursor-pointer"
              >
                CRG-2026-1042 (La Ansixiyey)
              </button>
              <button
                type="button"
                onClick={() => handleDirectDemoLookup('CRG-2026-1088')}
                className="px-2 py-1 rounded bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-sky-800 dark:text-sky-400 font-mono font-medium hover:bg-slate-100 cursor-pointer"
              >
                CRG-2026-1088 (Baaris ku jirta)
              </button>
            </div>

            {/* Tracking Search Input Form */}
            <form onSubmit={handleTrackSubmit} className="mt-4 flex flex-col sm:flex-row gap-3">
              <div className="relative flex-1">
                <Search className="w-5 h-5 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  required
                  value={trackingIdInput}
                  onChange={(e) => setTrackingIdInput(e.target.value)}
                  placeholder="CRG-2026-XXXX"
                  className="w-full pl-10 pr-4 py-2.5 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-mono uppercase text-sm focus:ring-2 focus:ring-emerald-500 outline-hidden"
                />
              </div>
              <button
                type="submit"
                className="px-6 py-2.5 rounded-lg bg-emerald-800 hover:bg-emerald-900 text-white font-semibold text-xs sm:text-sm flex items-center justify-center gap-2 cursor-pointer shadow-xs"
              >
                <Search className="w-4 h-4" />
                <span>{lang === 'so' ? 'Raadi Xaaladda' : 'Check Status'}</span>
              </button>
            </form>

            {/* Found Result Card */}
            {trackingSearched && foundApplication && (
              <div className="mt-8 p-6 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm space-y-6">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100 dark:border-slate-800">
                  <div>
                    <span className="text-xs text-slate-400 font-mono">{foundApplication.id}</span>
                    <h4 className="text-lg font-bold text-slate-900 dark:text-white font-display">
                      {foundApplication.serviceName}
                    </h4>
                  </div>
                  <span className="self-start sm:self-auto text-xs font-semibold px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 dark:bg-emerald-950/80 dark:text-emerald-300 dark:border-emerald-800">
                    {foundApplication.status}
                  </span>
                </div>

                {/* Milestone Progress Rail */}
                <div>
                  <div className="text-xs font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400 mb-4">
                    {lang === 'so' ? 'Heerarka uu Maraayo Codsiga' : 'Milestone Progression'}
                  </div>
                  <div className="grid grid-cols-4 gap-2 text-center text-[11px] sm:text-xs">
                    <div className="flex flex-col items-center">
                      <div className="w-8 h-8 rounded-full bg-emerald-800 text-white flex items-center justify-center mb-1 font-bold">✓</div>
                      <span className="font-semibold text-slate-900 dark:text-white">{lang === 'so' ? 'Gudbiyey' : 'Lodged'}</span>
                    </div>
                    <div className="flex flex-col items-center">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center mb-1 font-bold ${
                        getStatusStepIndex(foundApplication.status) >= 2 ? 'bg-emerald-800 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-500'
                      }`}>
                        {getStatusStepIndex(foundApplication.status) >= 2 ? '✓' : '2'}
                      </div>
                      <span className="font-semibold text-slate-900 dark:text-white">{lang === 'so' ? 'Baaris' : 'Review'}</span>
                    </div>
                    <div className="flex flex-col items-center">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center mb-1 font-bold ${
                        getStatusStepIndex(foundApplication.status) >= 3 ? 'bg-emerald-800 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-500'
                      }`}>
                        {getStatusStepIndex(foundApplication.status) >= 3 ? '✓' : '3'}
                      </div>
                      <span className="font-semibold text-slate-900 dark:text-white">{lang === 'so' ? 'La Ansixiyey' : 'Approved'}</span>
                    </div>
                    <div className="flex flex-col items-center">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center mb-1 font-bold ${
                        getStatusStepIndex(foundApplication.status) >= 4 ? 'bg-emerald-800 text-white' : 'bg-slate-200 dark:bg-slate-700 text-slate-500'
                      }`}>
                        {getStatusStepIndex(foundApplication.status) >= 4 ? '✓' : '4'}
                      </div>
                      <span className="font-semibold text-slate-900 dark:text-white">{lang === 'so' ? 'Diyaar' : 'Issued'}</span>
                    </div>
                  </div>
                </div>

                {/* Details list */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4 border-t border-slate-100 dark:border-slate-800 text-xs">
                  <div>
                    <span className="text-slate-400 block">{lang === 'so' ? 'Magaca Codsadaha' : 'Applicant Name'}</span>
                    <strong className="text-slate-900 dark:text-white text-sm">{foundApplication.applicantName}</strong>
                  </div>
                  <div>
                    <span className="text-slate-400 block">{lang === 'so' ? 'Goobta / Xaafadda' : 'Location Ward'}</span>
                    <strong className="text-slate-900 dark:text-white text-sm">{foundApplication.neighborhood}</strong>
                  </div>
                </div>

                {/* Officer Notes */}
                {foundApplication.notes && (
                  <div className="p-4 rounded-xl bg-slate-50 dark:bg-slate-800/80 border border-slate-200 dark:border-slate-700 text-xs text-slate-700 dark:text-slate-300">
                    <span className="font-bold text-slate-900 dark:text-white block mb-1">
                      {lang === 'so' ? 'Qoraalka Saraakiisha Dowladda Hoose:' : 'Official Municipal Officer Notes:'}
                    </span>
                    <p>{foundApplication.notes}</p>
                  </div>
                )}
              </div>
            )}

            {trackingSearched && !foundApplication && (
              <div className="mt-8 p-8 text-center bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
                <AlertCircle className="w-8 h-8 text-amber-500 mx-auto mb-2" />
                <h4 className="text-base font-bold text-slate-900 dark:text-white">
                  {lang === 'so' ? 'Lama Helin Codsigan' : 'Tracking Reference Not Found'}
                </h4>
                <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                  {lang === 'so' 
                    ? `Lama helin codsi leh lambarka "${trackingIdInput}". Fadlan hubi xarfaha iyo lambarada.` 
                    : `No record matches "${trackingIdInput}". Please confirm the tracking reference.`}
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </section>
  );
};

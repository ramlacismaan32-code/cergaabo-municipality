import React, { useState } from 'react';
import { Language, Project } from '../types';
import { 
  FolderKanban, 
  MapPin, 
  DollarSign, 
  Calendar, 
  HardHat, 
  CheckCircle2, 
  Clock, 
  ArrowUpRight
} from 'lucide-react';

interface ProjectsSectionProps {
  lang: Language;
  projects: Project[];
}

export const ProjectsSection: React.FC<ProjectsSectionProps> = ({
  lang,
  projects
}) => {
  const [statusFilter, setStatusFilter] = useState<'all' | 'ongoing' | 'completed' | 'planned'>('all');

  const filteredProjects = projects.filter((p) => {
    if (statusFilter === 'all') return true;
    return p.status === statusFilter;
  });

  return (
    <section id="projects" className="py-16 sm:py-20 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-emerald-800 dark:text-emerald-400 tracking-wider uppercase">
              <FolderKanban className="w-4 h-4 text-emerald-800 dark:text-emerald-400" />
              <span>{lang === 'so' ? 'Mashaariicda Degmada' : 'Municipal Development'}</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-slate-900 dark:text-white font-display mt-2">
              {lang === 'so' ? 'Mashaariicda Horumarinta & Kaabayaasha' : 'Public Infrastructure Projects'}
            </h2>
            <p className="mt-2 text-base text-slate-600 dark:text-slate-300 max-w-2xl">
              {lang === 'so'
                ? 'Kormeerka tooska ah ee mashaariicda laami-saarka, maareynta qashinka, laybareeriyada, iyo biyo-mareennada degmada Ceerigaabo ee Gobolka Sanaag.'
                : 'Direct transparency into active road works, modern sanitation hubs, civic centers, and urban drainage networks across Ceerigaabo.'}
            </p>
          </div>

          {/* Filter Segmented Control */}
          <div className="flex items-center gap-1 p-1 bg-slate-100 dark:bg-slate-800 rounded-lg self-start md:self-end">
            <button
              onClick={() => setStatusFilter('all')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                statusFilter === 'all'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              {lang === 'so' ? 'Dhammaan' : 'All'}
            </button>
            <button
              onClick={() => setStatusFilter('ongoing')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                statusFilter === 'ongoing'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              {lang === 'so' ? 'Socda (Ongoing)' : 'Ongoing'}
            </button>
            <button
              onClick={() => setStatusFilter('completed')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                statusFilter === 'completed'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              {lang === 'so' ? 'Dhameystirmay' : 'Completed'}
            </button>
            <button
              onClick={() => setStatusFilter('planned')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                statusFilter === 'planned'
                  ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-xs'
                  : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
              }`}
            >
              {lang === 'so' ? 'Qorsheysan' : 'Planned'}
            </button>
          </div>
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredProjects.map((project) => {
            const isCompleted = project.progress === 100;
            return (
              <div
                key={project.id}
                className="group bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 rounded-2xl overflow-hidden shadow-xs hover:shadow-md transition-all flex flex-col justify-between"
              >
                <div>
                  {/* Image Header */}
                  <div className="relative h-48 w-full overflow-hidden bg-slate-900">
                    <img
                      src={project.image}
                      alt={project.titleSo}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-slate-950/80 via-transparent to-transparent" />
                    
                    {/* Status badge in overlay */}
                    <div className="absolute top-3 right-3">
                      <span className={`px-2.5 py-1 rounded-md text-[11px] font-bold shadow-xs ${
                        isCompleted
                          ? 'bg-emerald-700 text-white'
                          : project.status === 'ongoing'
                          ? 'bg-amber-600 text-white'
                          : 'bg-slate-800 text-slate-200'
                      }`}>
                        {isCompleted 
                          ? (lang === 'so' ? 'Dhameystirmay (100%)' : 'Completed') 
                          : project.status === 'ongoing' 
                          ? `${project.progress}% ${lang === 'so' ? 'Socda' : 'In Progress'}` 
                          : (lang === 'so' ? 'Qorsheysan' : 'Planned')}
                      </span>
                    </div>

                    <div className="absolute bottom-3 left-3 text-xs font-semibold text-emerald-300">
                      {lang === 'so' ? project.categorySo : project.categoryEn}
                    </div>
                  </div>

                  {/* Body Content */}
                  <div className="p-5">
                    <h3 className="text-base font-bold text-slate-900 dark:text-white font-display group-hover:text-emerald-800 dark:group-hover:text-emerald-400 transition-colors">
                      {lang === 'so' ? project.titleSo : project.titleEn}
                    </h3>

                    <p className="mt-2 text-xs text-slate-600 dark:text-slate-300 leading-relaxed line-clamp-2">
                      {lang === 'so' ? project.descriptionSo : project.descriptionEn}
                    </p>

                    {/* Progress Bar */}
                    <div className="mt-4 pt-3 border-t border-slate-200/80 dark:border-slate-700">
                      <div className="flex items-center justify-between text-xs mb-1.5">
                        <span className="text-slate-500 dark:text-slate-400 font-medium">{lang === 'so' ? 'Heerka Dhameystirka' : 'Progress'}</span>
                        <span className="font-mono font-bold text-slate-900 dark:text-white tabular-nums">{project.progress}%</span>
                      </div>
                      <div className="w-full bg-slate-200 dark:bg-slate-700 h-2 rounded-full overflow-hidden">
                        <div
                          className={`h-full transition-all duration-500 ${
                            isCompleted ? 'bg-emerald-600' : 'bg-amber-500'
                          }`}
                          style={{ width: `${project.progress}%` }}
                        />
                      </div>
                    </div>

                    {/* Project Metadata Details */}
                    <div className="mt-4 space-y-1.5 text-xs text-slate-600 dark:text-slate-300">
                      <div className="flex items-center gap-2">
                        <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span className="truncate">{project.location}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <DollarSign className="w-3.5 h-3.5 text-emerald-800 dark:text-emerald-400 shrink-0" />
                        <span>Miisaaniyadda: <strong className="font-mono text-slate-900 dark:text-white">{project.budget}</strong></span>
                      </div>
                      <div className="flex items-center gap-2">
                        <HardHat className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span className="truncate">{project.contractor}</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="px-5 pb-5 pt-2 text-[11px] text-slate-400 border-t border-slate-200/60 dark:border-slate-800 flex items-center justify-between">
                  <span>{lang === 'so' ? 'Dhameystirka:' : 'Completion:'} {project.expectedCompletion}</span>
                  <span className="font-mono">{project.startDate}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

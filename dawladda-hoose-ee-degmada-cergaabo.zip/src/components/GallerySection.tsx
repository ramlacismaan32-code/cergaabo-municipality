import React, { useState } from 'react';
import { Language, GalleryItem } from '../types';
import { 
  Images, 
  Maximize2, 
  X, 
  ChevronLeft, 
  ChevronRight,
  MapPin
} from 'lucide-react';

interface GallerySectionProps {
  lang: Language;
  galleryItems: GalleryItem[];
}

export const GallerySection: React.FC<GallerySectionProps> = ({
  lang,
  galleryItems
}) => {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  const filteredItems = galleryItems.filter((item) => {
    if (selectedCategory === 'all') return true;
    return item.category === selectedCategory;
  });

  const categories = [
    { id: 'all', labelSo: 'Dhammaan Sawirrada', labelEn: 'All Photos' },
    { id: 'landmarks', labelSo: 'Muuqaalka Magaalada', labelEn: 'Cityscape' },
    { id: 'civic', labelSo: 'Xarumaha Dowladda', labelEn: 'Civic Buildings' },
    { id: 'infrastructure', labelSo: 'Waddooyinka & Kaabayaasha', labelEn: 'Infrastructure' },
    { id: 'culture', labelSo: 'Hiddaha & Taariikhda', labelEn: 'Heritage' }
  ];

  const handlePrev = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (lightboxIndex !== null) {
      setLightboxIndex((lightboxIndex - 1 + filteredItems.length) % filteredItems.length);
    }
  };

  const handleNext = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (lightboxIndex !== null) {
      setLightboxIndex((lightboxIndex + 1) % filteredItems.length);
    }
  };

  const currentLightboxItem = lightboxIndex !== null ? filteredItems[lightboxIndex] : null;

  return (
    <section id="gallery" className="py-16 sm:py-20 bg-slate-50 dark:bg-slate-900/60 border-b border-slate-200 dark:border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold text-emerald-800 dark:text-emerald-400 tracking-wider uppercase">
              <Images className="w-4 h-4 text-emerald-800 dark:text-emerald-400" />
              <span>{lang === 'so' ? 'Muuqaallada Ceerigaabo' : 'Ceerigaabo Visual Archive'}</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-slate-900 dark:text-white font-display mt-2">
              {lang === 'so' ? 'Sawirrada & Muuqaallada Degmada Ceerigaabo' : 'Photo Gallery & Landmarks'}
            </h2>
            <p className="mt-2 text-base text-slate-600 dark:text-slate-300 max-w-2xl">
              {lang === 'so'
                ? 'Sawirro tayo sare leh oo muujinaya bilicda magaalada Ceerigaabo, keymaha Daalo, Buuraha Surud iyo Sheed, iyo xarumaha dawladda hoose.'
                : 'High-resolution photography capturing Ceerigaabo civic life, Daalo mountain forest, Mount Surud, and modern municipal infrastructure.'}
            </p>
          </div>

          {/* Categories */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-2 md:pb-0 no-scrollbar self-start md:self-end">
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer border ${
                  selectedCategory === cat.id
                    ? 'bg-emerald-800 dark:bg-emerald-700 text-white border-emerald-800 dark:border-emerald-700 shadow-xs'
                    : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800 hover:bg-slate-100'
                }`}
              >
                {lang === 'so' ? cat.labelSo : cat.labelEn}
              </button>
            ))}
          </div>
        </div>

        {/* Gallery Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredItems.map((item, idx) => (
            <div
              key={item.id}
              onClick={() => setLightboxIndex(idx)}
              className="group relative rounded-2xl overflow-hidden bg-slate-900 border border-slate-200 dark:border-slate-800 aspect-4/3 cursor-pointer shadow-xs hover:shadow-lg transition-all"
            >
              <img
                src={item.image}
                alt={item.titleSo}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              {/* Overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-slate-950/20 to-transparent opacity-80 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-5">
                <span className="text-[11px] font-semibold text-emerald-400 uppercase tracking-wider block mb-1">
                  {lang === 'so' ? item.categoryLabelSo : item.categoryLabelEn}
                </span>
                <h3 className="text-base font-bold text-white leading-tight font-display">
                  {lang === 'so' ? item.titleSo : item.titleEn}
                </h3>
                <p className="text-xs text-slate-300 mt-1 line-clamp-1">
                  {lang === 'so' ? item.descriptionSo : item.descriptionEn}
                </p>
                <div className="mt-3 flex items-center justify-between text-xs text-slate-300 border-t border-white/10 pt-2">
                  <span className="flex items-center gap-1 text-[11px] text-amber-300">
                    <Maximize2 className="w-3.5 h-3.5" />
                    <span>{lang === 'so' ? 'Balaari' : 'Enlarge'}</span>
                  </span>
                  <span className="text-[11px] text-slate-400">Ceerigaabo, Sanaag</span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Lightbox Modal */}
      {currentLightboxItem && (
        <div
          onClick={() => setLightboxIndex(null)}
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/90 backdrop-blur-md"
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="relative max-w-4xl w-full bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden shadow-2xl"
          >
            {/* Close Button */}
            <button
              onClick={() => setLightboxIndex(null)}
              className="absolute top-4 right-4 z-20 p-2 rounded-full bg-black/60 text-white hover:bg-black/80 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Navigation Buttons */}
            <button
              onClick={handlePrev}
              className="absolute left-4 top-1/2 -translate-y-1/2 z-20 p-2.5 rounded-full bg-black/60 text-white hover:bg-black/80 transition-colors cursor-pointer"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>

            <button
              onClick={handleNext}
              className="absolute right-4 top-1/2 -translate-y-1/2 z-20 p-2.5 rounded-full bg-black/60 text-white hover:bg-black/80 transition-colors cursor-pointer"
            >
              <ChevronRight className="w-6 h-6" />
            </button>

            {/* Image Frame */}
            <div className="relative max-h-[70vh] bg-black flex items-center justify-center overflow-hidden">
              <img
                src={currentLightboxItem.image}
                alt={currentLightboxItem.titleSo}
                referrerPolicy="no-referrer"
                className="max-h-[70vh] w-auto object-contain mx-auto"
              />
            </div>

            {/* Caption Area */}
            <div className="p-6 bg-slate-900 border-t border-slate-800 text-white">
              <div className="flex items-center justify-between text-xs text-emerald-400 mb-1">
                <span>{lang === 'so' ? currentLightboxItem.categoryLabelSo : currentLightboxItem.categoryLabelEn}</span>
                <span className="text-slate-400">
                  {lightboxIndex! + 1} / {filteredItems.length}
                </span>
              </div>
              <h3 className="text-xl font-bold font-display">
                {lang === 'so' ? currentLightboxItem.titleSo : currentLightboxItem.titleEn}
              </h3>
              <p className="mt-2 text-xs sm:text-sm text-slate-300 leading-relaxed">
                {lang === 'so' ? currentLightboxItem.descriptionSo : currentLightboxItem.descriptionEn}
              </p>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};

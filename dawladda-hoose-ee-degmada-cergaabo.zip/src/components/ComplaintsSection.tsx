import React, { useState } from 'react';
import { Language, ComplaintTicket } from '../types';
import { 
  MessageSquareWarning, 
  Send, 
  Search, 
  CheckCircle2, 
  Clock, 
  AlertTriangle, 
  Phone, 
  ShieldAlert,
  ChevronRight,
  HelpCircle
} from 'lucide-react';

interface ComplaintsSectionProps {
  lang: Language;
  complaints: ComplaintTicket[];
  onNewComplaint: (ticket: ComplaintTicket) => void;
}

export const ComplaintsSection: React.FC<ComplaintsSectionProps> = ({
  lang,
  complaints,
  onNewComplaint
}) => {
  const [activeTab, setActiveTab] = useState<'submit' | 'track'>('submit');

  // Submit form state
  const [fullName, setFullName] = useState<string>('');
  const [phone, setPhone] = useState<string>('');
  const [category, setCategory] = useState<ComplaintTicket['category']>('sanitation');
  const [neighborhood, setNeighborhood] = useState<string>('Xaafadda Horseed');
  const [priority, setPriority] = useState<ComplaintTicket['priority']>('caadi');
  const [description, setDescription] = useState<string>('');
  const [submittedTicket, setSubmittedTicket] = useState<ComplaintTicket | null>(null);

  // Track search state
  const [ticketQuery, setTicketQuery] = useState<string>('');
  const [foundTicket, setFoundTicket] = useState<ComplaintTicket | null>(null);
  const [searched, setSearched] = useState<boolean>(false);

  const getCategoryLabel = (cat: ComplaintTicket['category']) => {
    switch (cat) {
      case 'sanitation': return lang === 'so' ? 'Nadaafadda & Qashinka' : 'Sanitation & Garbage';
      case 'roads': return lang === 'so' ? 'Waddooyinka & Jidadka Go’an' : 'Roads & Access';
      case 'drainage': return lang === 'so' ? 'Biyo-mareennada & Daadadka' : 'Drainage & Floods';
      case 'streetlights': return lang === 'so' ? 'Nalalka Cadceedda (Solar)' : 'Solar Streetlights';
      case 'corruption': return lang === 'so' ? 'Adeeg-xumo / Musuqmaasuq' : 'Service Grievance / Misconduct';
      default: return lang === 'so' ? 'Talo & Soo-jeedin Guud' : 'General Proposal';
    }
  };

  const handleComplaintSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const ticketId = `CAB-CRG-${randomSuffix}`;

    const newTicket: ComplaintTicket = {
      id: ticketId,
      fullName,
      phone,
      category,
      categoryLabelSo: getCategoryLabel(category),
      neighborhood,
      description,
      priority,
      status: 'Cusub (New)',
      submittedDate: 'Maanta (Today)',
      resolutionNote: lang === 'so' 
        ? 'Cabashadaada waxaa loo gudbiyay kormeerayaasha degmada si wax looga qabto.'
        : 'Your grievance has been dispatched to district field surveyors for action.'
    };

    onNewComplaint(newTicket);
    setSubmittedTicket(newTicket);
    setFullName('');
    setPhone('');
    setDescription('');
  };

  const handleTrackSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const q = ticketQuery.trim().toUpperCase();
    const match = complaints.find(c => c.id.toUpperCase() === q);
    setFoundTicket(match || null);
    setSearched(true);
  };

  const handleQuickDemo = (demoId: string) => {
    setTicketQuery(demoId);
    const match = complaints.find(c => c.id.toUpperCase() === demoId.toUpperCase());
    setFoundTicket(match || null);
    setSearched(true);
  };

  return (
    <section id="complaints" className="py-16 sm:py-20 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Section Header */}
        <div className="max-w-3xl mb-10">
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-800 dark:text-emerald-400 tracking-wider uppercase">
            <MessageSquareWarning className="w-4 h-4 text-emerald-800 dark:text-emerald-400" />
            <span>{lang === 'so' ? 'Codka Shacabka' : 'Citizen Grievance Redressal'}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold tracking-tight text-slate-900 dark:text-white font-display mt-2">
            {lang === 'so' ? 'Cabashooyinka & Talooyinka Bulshada' : 'Citizen Complaints & Feedback'}
          </h2>
          <p className="mt-3 text-base text-slate-600 dark:text-slate-300">
            {lang === 'so'
              ? 'Dawladda Hoose ee Ceerigaabo waxay si buuxda u tixgelisaa cabashooyinka bulshada ee ku saabsan nadaafadda, waddooyinka buuraha, nalalka, iyo adeegyada dowladda.'
              : 'Direct hotline to report damaged roads, uncollected waste, broken streetlights, or submit civic improvement proposals in Ceerigaabo.'}
          </p>
        </div>

        {/* Tab switcher */}
        <div className="flex items-center gap-2 p-1.5 bg-slate-100 dark:bg-slate-800 rounded-xl max-w-md mb-8">
          <button
            onClick={() => {
              setActiveTab('submit');
              setSubmittedTicket(null);
            }}
            className={`flex-1 py-2 px-4 rounded-lg text-xs sm:text-sm font-semibold transition-colors cursor-pointer flex items-center justify-center gap-2 ${
              activeTab === 'submit'
                ? 'bg-white dark:bg-slate-900 text-emerald-800 dark:text-emerald-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <Send className="w-4 h-4" />
            <span>{lang === 'so' ? 'Gudbi Cabasho / Talo' : 'File Complaint'}</span>
          </button>

          <button
            onClick={() => setActiveTab('track')}
            className={`flex-1 py-2 px-4 rounded-lg text-xs sm:text-sm font-semibold transition-colors cursor-pointer flex items-center justify-center gap-2 ${
              activeTab === 'track'
                ? 'bg-white dark:bg-slate-900 text-emerald-800 dark:text-emerald-400 shadow-xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            <Search className="w-4 h-4" />
            <span>{lang === 'so' ? 'Raad-raac Cabasho' : 'Track Ticket'}</span>
          </button>
        </div>

        {/* TAB 1: SUBMIT COMPLAINT FORM */}
        {activeTab === 'submit' && (
          <div className="bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 sm:p-10 shadow-xs max-w-2xl mx-auto">
            {submittedTicket ? (
              <div className="text-center space-y-4 py-4">
                <div className="w-16 h-16 rounded-full bg-emerald-100 dark:bg-emerald-950/80 text-emerald-800 dark:text-emerald-400 flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-10 h-10" />
                </div>
                <h3 className="text-2xl font-bold text-slate-900 dark:text-white font-display">
                  {lang === 'so' ? 'Cabashadaadii Waa La Diiwaangeliyay!' : 'Complaint Ticket Registered!'}
                </h3>
                <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400">
                  {lang === 'so' 
                    ? 'Kooxda kormeerka dowladda hoose ayaa loo xilsaaray inay wax ka qabtaan arrinta aad soo sheegtay.' 
                    : 'The municipal inspection dispatch has received your grievance ticket for resolution.'}
                </p>

                <div className="p-4 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 text-left my-6 space-y-2 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-500">{lang === 'so' ? 'Lambarka Cabashada (Ticket ID)' : 'Ticket ID'}:</span>
                    <strong className="text-emerald-800 dark:text-emerald-400 font-mono text-sm">{submittedTicket.id}</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">{lang === 'so' ? 'Nooca' : 'Category'}:</span>
                    <span className="font-semibold text-slate-800 dark:text-slate-200">{submittedTicket.categoryLabelSo}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">{lang === 'so' ? 'Xaafadda' : 'Ward'}:</span>
                    <span className="text-slate-800 dark:text-slate-200">{submittedTicket.neighborhood}</span>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row gap-3 justify-center">
                  <button
                    onClick={() => {
                      handleQuickDemo(submittedTicket.id);
                      setActiveTab('track');
                    }}
                    className="px-5 py-2.5 rounded-lg bg-emerald-800 hover:bg-emerald-900 text-white font-semibold text-xs sm:text-sm cursor-pointer"
                  >
                    {lang === 'so' ? 'La Soco Cabashadan' : 'Track Status'}
                  </button>
                  <button
                    onClick={() => setSubmittedTicket(null)}
                    className="px-4 py-2 rounded-lg border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 text-xs cursor-pointer"
                  >
                    {lang === 'so' ? 'Gudbi Cabasho Kale' : 'Submit Another'}
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleComplaintSubmit} className="space-y-4 text-xs sm:text-sm">
                <div>
                  <h3 className="text-xl font-bold text-slate-900 dark:text-white font-display mb-1">
                    {lang === 'so' ? 'Foomka Cabashooyinka & Talooyinka' : 'Citizen Grievance Submission Form'}
                  </h3>
                  <p className="text-xs text-slate-600 dark:text-slate-400 mb-4">
                    {lang === 'so' 
                      ? 'Fadlan faahfaahi meesha iyo dhibaatada si degdeg ah loogu gurmado.' 
                      : 'Please provide exact ward and issue details for expedited dispatch.'}
                  </p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                      {lang === 'so' ? 'Magacaaga' : 'Your Name'} *
                    </label>
                    <input
                      type="text"
                      required
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder={lang === 'so' ? 'Magacaaga oo saddexan' : 'Full name'}
                      className="w-full px-3.5 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-hidden"
                    />
                  </div>

                  <div>
                    <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                      {lang === 'so' ? 'Lambarka Telefoonka' : 'Phone Number'} *
                    </label>
                    <input
                      type="tel"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="+252 90..."
                      className="w-full px-3.5 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-hidden"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                      {lang === 'so' ? 'Nooca Cabashada' : 'Grievance Category'} *
                    </label>
                    <select
                      value={category}
                      onChange={(e) => setCategory(e.target.value as ComplaintTicket['category'])}
                      className="w-full px-3.5 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white outline-hidden"
                    >
                      <option value="sanitation">{lang === 'so' ? 'Nadaafadda & Qashinka' : 'Sanitation & Waste'}</option>
                      <option value="roads">{lang === 'so' ? 'Waddooyinka & Jidadka Go’an' : 'Road Maintenance'}</option>
                      <option value="drainage">{lang === 'so' ? 'Biyo-mareennada & Daadadka' : 'Drainage & Floods'}</option>
                      <option value="streetlights">{lang === 'so' ? 'Nalalka Cadceedda (Solar)' : 'Solar Streetlights'}</option>
                      <option value="corruption">{lang === 'so' ? 'Adeeg-xumo / Cabasho Shaqaale' : 'Staff Conduct / Grievance'}</option>
                      <option value="other">{lang === 'so' ? 'Talo & Soo-jeedin Guud' : 'General Community Proposal'}</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                      {lang === 'so' ? 'Xaafadda / Goobta' : 'Ward / Location'} *
                    </label>
                    <select
                      value={neighborhood}
                      onChange={(e) => setNeighborhood(e.target.value)}
                      className="w-full px-3.5 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white outline-hidden"
                    >
                      <option value="Xaafadda Daalo">Xaafadda Daalo</option>
                      <option value="Xaafadda Dayaxa">Xaafadda Dayaxa</option>
                      <option value="Xaafadda Surud">Xaafadda Surud</option>
                      <option value="Xaafadda Barwaaqo">Xaafadda Barwaaqo</option>
                      <option value="Waddada Maydh">Waddada Maydh</option>
                      <option value="Suuqa Weyn ee Ceerigaabo">Suuqa Weyn ee Ceerigaabo</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                    {lang === 'so' ? 'Heerka Degdegga' : 'Urgency Level'}
                  </label>
                  <div className="flex gap-4">
                    <label className="flex items-center gap-1.5 cursor-pointer">
                      <input
                        type="radio"
                        name="priority"
                        checked={priority === 'caadi'}
                        onChange={() => setPriority('caadi')}
                        className="accent-emerald-600"
                      />
                      <span>{lang === 'so' ? 'Caadi (Normal)' : 'Normal'}</span>
                    </label>
                    <label className="flex items-center gap-1.5 cursor-pointer">
                      <input
                        type="radio"
                        name="priority"
                        checked={priority === 'degdeg'}
                        onChange={() => setPriority('degdeg')}
                        className="accent-amber-600"
                      />
                      <span className="text-amber-600 dark:text-amber-400 font-medium">{lang === 'so' ? 'Degdeg (Urgent)' : 'Urgent'}</span>
                    </label>
                    <label className="flex items-center gap-1.5 cursor-pointer">
                      <input
                        type="radio"
                        name="priority"
                        checked={priority === 'aad u degdeg'}
                        onChange={() => setPriority('aad u degdeg')}
                        className="accent-red-600"
                      />
                      <span className="text-red-600 dark:text-red-400 font-medium">{lang === 'so' ? 'Aad u Degdeg (Emergency)' : 'Critical'}</span>
                    </label>
                  </div>
                </div>

                <div>
                  <label className="block font-medium text-slate-700 dark:text-slate-300 mb-1">
                    {lang === 'so' ? 'Faahfaahinta Cabashada ama Talada' : 'Detailed Description'} *
                  </label>
                  <textarea
                    required
                    rows={4}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder={lang === 'so' ? 'Qor waxa dhacay, goobta saxda ah (calaamad caan ah), iyo sida loo xallin karo...' : 'Describe the exact location, landmarks, and observed issue...'}
                    className="w-full px-3.5 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white focus:ring-2 focus:ring-emerald-500 outline-hidden"
                  />
                </div>

                <div className="flex justify-end pt-3 border-t border-slate-200 dark:border-slate-800">
                  <button
                    type="submit"
                    className="px-6 py-2.5 rounded-lg bg-emerald-800 hover:bg-emerald-900 text-white font-semibold text-xs sm:text-sm flex items-center gap-2 cursor-pointer shadow-xs"
                  >
                    <Send className="w-4 h-4" />
                    <span>{lang === 'so' ? 'Gudbi Cabashada' : 'Submit Ticket'}</span>
                  </button>
                </div>
              </form>
            )}
          </div>
        )}

        {/* TAB 2: TRACK COMPLAINT */}
        {activeTab === 'track' && (
          <div className="bg-slate-50 dark:bg-slate-800/40 border border-slate-200 dark:border-slate-800 rounded-2xl p-6 sm:p-10 shadow-xs max-w-2xl mx-auto">
            <h3 className="text-xl font-bold text-slate-900 dark:text-white font-display mb-1">
              {lang === 'so' ? 'La Soco Cabashadaada' : 'Track Complaint Resolution'}
            </h3>
            <p className="text-xs sm:text-sm text-slate-600 dark:text-slate-400 mb-4">
              {lang === 'so'
                ? 'Geli lambarka tikidhka (tusaale: CAB-CRG-5510 ama CAB-CRG-5524) si aad u aragto jawaabta degmada.'
                : 'Enter your ticket reference code to inspect action taken by municipal crews.'}
            </p>

            {/* Quick Demo Pre-fills */}
            <div className="flex items-center gap-2 mb-4 text-xs text-slate-500 dark:text-slate-400 flex-wrap">
              <span>{lang === 'so' ? 'Tusaalooyin:' : 'Sample Tickets:'}</span>
              <button
                type="button"
                onClick={() => handleQuickDemo('CAB-CRG-5510')}
                className="px-2 py-0.5 rounded bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-amber-600 dark:text-amber-400 font-mono hover:bg-slate-100 cursor-pointer"
              >
                CAB-CRG-5510 (Socota)
              </button>
              <button
                type="button"
                onClick={() => handleQuickDemo('CAB-CRG-5524')}
                className="px-2 py-0.5 rounded bg-white dark:bg-slate-800 border border-slate-300 dark:border-slate-700 text-emerald-800 dark:text-emerald-400 font-mono hover:bg-slate-100 cursor-pointer"
              >
                CAB-CRG-5524 (La Xalliyey)
              </button>
            </div>

            <form onSubmit={handleTrackSubmit} className="flex gap-2">
              <input
                type="text"
                required
                value={ticketQuery}
                onChange={(e) => setTicketQuery(e.target.value)}
                placeholder="CAB-QRD-XXXX"
                className="flex-1 px-3.5 py-2 rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-900 text-slate-900 dark:text-white font-mono uppercase text-sm focus:ring-2 focus:ring-emerald-500 outline-hidden"
              />
              <button
                type="submit"
                className="px-5 py-2 rounded-lg bg-emerald-800 hover:bg-emerald-900 text-white font-semibold text-xs sm:text-sm flex items-center gap-1.5 cursor-pointer shadow-xs"
              >
                <Search className="w-4 h-4" />
                <span>{lang === 'so' ? 'Baar' : 'Track'}</span>
              </button>
            </form>

            {searched && foundTicket && (
              <div className="mt-6 p-5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                  <div>
                    <span className="font-mono text-xs text-slate-400 block">{foundTicket.id}</span>
                    <h4 className="text-base font-bold text-slate-900 dark:text-white font-display">
                      {foundTicket.categoryLabelSo}
                    </h4>
                  </div>
                  <span className={`text-xs font-bold px-3 py-1 rounded-full ${
                    foundTicket.status.includes('Xalliyey')
                      ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300'
                      : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                  }`}>
                    {foundTicket.status}
                  </span>
                </div>

                <div className="text-xs text-slate-700 dark:text-slate-300 space-y-2">
                  <div className="flex justify-between">
                    <span className="text-slate-400">{lang === 'so' ? 'Qofka Soo Gudbiyay' : 'Reported By'}:</span>
                    <span className="font-semibold">{foundTicket.fullName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">{lang === 'so' ? 'Goobta / Xaafadda' : 'Ward Location'}:</span>
                    <span>{foundTicket.neighborhood}</span>
                  </div>
                  <div className="pt-2">
                    <span className="text-slate-400 block mb-1">{lang === 'so' ? 'Qoraalka Cabashada' : 'Complaint Content'}:</span>
                    <p className="p-3 rounded-lg bg-slate-50 dark:bg-slate-800/80 border border-slate-100 dark:border-slate-800 italic">
                      &ldquo;{foundTicket.description}&rdquo;
                    </p>
                  </div>
                </div>

                {foundTicket.resolutionNote && (
                  <div className="p-3.5 rounded-lg bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-xs">
                    <strong className="text-emerald-900 dark:text-emerald-300 block mb-1">
                      {lang === 'so' ? 'Jawaabta Dowladda Hoose:' : 'Municipal Response:'}
                    </strong>
                    <p className="text-emerald-800 dark:text-emerald-400">{foundTicket.resolutionNote}</p>
                  </div>
                )}
              </div>
            )}

            {searched && !foundTicket && (
              <div className="mt-6 p-6 text-center bg-white dark:bg-slate-900 rounded-xl border border-slate-200 dark:border-slate-800">
                <AlertTriangle className="w-8 h-8 text-amber-500 mx-auto mb-2" />
                <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                  {lang === 'so' ? 'Lama helin tikidhkas' : 'Ticket not found'}
                </h4>
                <p className="text-xs text-slate-500 mt-1">
                  {lang === 'so' ? 'Fadlan hubi lambarka cabashada aad gelisay.' : 'Please verify the ticket reference number.'}
                </p>
              </div>
            )}
          </div>
        )}
      </div>
    </section>
  );
};

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Language, CitizenApplication, ComplaintTicket, NewsItem, Project, GalleryItem } from './types';
import { 
  INITIAL_SERVICES, 
  INITIAL_DEPARTMENTS, 
  INITIAL_PROJECTS, 
  INITIAL_NEWS, 
  INITIAL_APPLICATIONS, 
  INITIAL_COMPLAINTS, 
  INITIAL_GALLERY 
} from './data/municipalData';

import { Header } from './components/Header';
import { Hero } from './components/Hero';
import { QuickServicesStrip } from './components/QuickServicesStrip';
import { AboutSection } from './components/AboutSection';
import { MayorSection } from './components/MayorSection';
import { DepartmentsSection } from './components/DepartmentsSection';
import { ServicesSection } from './components/ServicesSection';
import { OnlineApplicationsSection } from './components/OnlineApplicationsSection';
import { ProjectsSection } from './components/ProjectsSection';
import { NewsSection } from './components/NewsSection';
import { GallerySection } from './components/GallerySection';
import { ComplaintsSection } from './components/ComplaintsSection';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { AdminDashboard } from './components/AdminDashboard';
import { SearchModal } from './components/SearchModal';

export default function App() {
  // Localization state
  const [lang, setLang] = useState<Language>('so');

  // Dark Mode state
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    if (typeof window !== 'undefined') {
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    }
    return false;
  });

  // Apply dark mode class to html element
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  // Active section for navigation highlight
  const [activeSection, setActiveSection] = useState<string>('home');

  // Modal states
  const [adminOpen, setAdminOpen] = useState<boolean>(false);
  const [searchOpen, setSearchOpen] = useState<boolean>(false);
  const [preselectedServiceId, setPreselectedServiceId] = useState<string | null>(null);

  // Managed interactive state
  const [services] = useState(INITIAL_SERVICES);
  const [departments] = useState(INITIAL_DEPARTMENTS);
  const [applications, setApplications] = useState<CitizenApplication[]>(INITIAL_APPLICATIONS);
  const [complaints, setComplaints] = useState<ComplaintTicket[]>(INITIAL_COMPLAINTS);
  const [newsItems, setNewsItems] = useState<NewsItem[]>(INITIAL_NEWS);
  const [projects, setProjects] = useState<Project[]>(INITIAL_PROJECTS);
  const [galleryItems, setGalleryItems] = useState<GalleryItem[]>(INITIAL_GALLERY);

  // Navigation handler
  const handleNavigate = (sectionId: string) => {
    setActiveSection(sectionId);
    if (sectionId === 'home') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }
    const elem = document.getElementById(sectionId);
    if (elem) {
      elem.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Service selection handler (scroll to applications and select service)
  const handleSelectServiceForApply = (serviceId: string) => {
    setPreselectedServiceId(serviceId);
    handleNavigate('applications');
  };

  // Department services selector
  const handleSelectDepartmentServices = (deptId: string) => {
    handleNavigate('services');
  };

  // Add new application
  const handleNewApplication = (newApp: CitizenApplication) => {
    setApplications((prev) => [newApp, ...prev]);
  };

  // Update application status (Admin)
  const handleUpdateApplicationStatus = (
    id: string, 
    newStatus: CitizenApplication['status'], 
    notes?: string
  ) => {
    setApplications((prev) => 
      prev.map((app) => app.id === id ? { ...app, status: newStatus, notes: notes || app.notes } : app)
    );
  };

  // Add new complaint
  const handleNewComplaint = (newTicket: ComplaintTicket) => {
    setComplaints((prev) => [newTicket, ...prev]);
  };

  // Update complaint status (Admin)
  const handleUpdateComplaintStatus = (
    id: string, 
    newStatus: ComplaintTicket['status'], 
    resolutionNote?: string
  ) => {
    setComplaints((prev) =>
      prev.map((c) => c.id === id ? { ...c, status: newStatus, resolutionNote: resolutionNote || c.resolutionNote } : c)
    );
  };

  // Add new news / decree (Admin)
  const handleAddNews = (newItem: NewsItem) => {
    setNewsItems((prev) => [newItem, ...prev]);
  };

  // Add new project (Admin)
  const handleAddProject = (newProject: Project) => {
    setProjects((prev) => [newProject, ...prev]);
  };

  // Add new gallery item (Admin)
  const handleAddGalleryItem = (newGalleryItem: GalleryItem) => {
    setGalleryItems((prev) => [newGalleryItem, ...prev]);
  };

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 selection:bg-emerald-500 selection:text-white transition-colors duration-200">
      {/* Top Header */}
      <Header
        lang={lang}
        onToggleLang={() => setLang(lang === 'so' ? 'en' : 'so')}
        darkMode={darkMode}
        onToggleDarkMode={() => setDarkMode(!darkMode)}
        activeSection={activeSection}
        onNavigate={handleNavigate}
        onOpenAdmin={() => setAdminOpen(true)}
        onOpenSearch={() => setSearchOpen(true)}
      />

      <main>
        {/* Hero Section */}
        <Hero
          lang={lang}
          onNavigate={handleNavigate}
          latestAnnouncementTitle={lang === 'so' ? newsItems[0]?.titleSo : newsItems[0]?.titleEn}
        />

        {/* Quick Services Access Strip */}
        <QuickServicesStrip
          lang={lang}
          onSelectService={handleSelectServiceForApply}
          onNavigateToServices={() => handleNavigate('services')}
        />

        {/* About Us (Taariikhda & Qiyamka) */}
        <AboutSection lang={lang} />

        {/* Mayor's Office (Xafiiska Duqa) */}
        <MayorSection lang={lang} />

        {/* Departments (Waaxyaha) */}
        <DepartmentsSection
          lang={lang}
          departments={departments}
          onSelectDepartmentServices={handleSelectDepartmentServices}
        />

        {/* Municipal Services Catalog & Fee Calculator */}
        <ServicesSection
          lang={lang}
          services={services}
          onApplyForService={handleSelectServiceForApply}
        />

        {/* Online Applications & Case Tracker */}
        <OnlineApplicationsSection
          lang={lang}
          services={services}
          applications={applications}
          onNewApplication={handleNewApplication}
          preselectedServiceId={preselectedServiceId}
        />

        {/* News, Decrees & Public Tenders */}
        <NewsSection
          lang={lang}
          newsItems={newsItems}
        />

        {/* Development Projects Tracker */}
        <ProjectsSection
          lang={lang}
          projects={projects}
        />

        {/* Photo Gallery & Landmarks */}
        <GallerySection
          lang={lang}
          galleryItems={galleryItems}
        />

        {/* Citizen Complaints & Feedback Redressal */}
        <ComplaintsSection
          lang={lang}
          complaints={complaints}
          onNewComplaint={handleNewComplaint}
        />

        {/* Contact Us & District Location Map */}
        <ContactSection lang={lang} />
      </main>

      {/* Footer */}
      <Footer
        lang={lang}
        onNavigate={handleNavigate}
        onOpenAdmin={() => setAdminOpen(true)}
      />

      {/* Administrative Control Dashboard Modal */}
      <AdminDashboard
        lang={lang}
        isOpen={adminOpen}
        onClose={() => setAdminOpen(false)}
        applications={applications}
        onUpdateApplicationStatus={handleUpdateApplicationStatus}
        complaints={complaints}
        onUpdateComplaintStatus={handleUpdateComplaintStatus}
        newsItems={newsItems}
        onAddNews={handleAddNews}
        projects={projects}
        onAddProject={handleAddProject}
        galleryItems={galleryItems}
        onAddGalleryItem={handleAddGalleryItem}
      />

      {/* Global Portal Search Modal */}
      <SearchModal
        lang={lang}
        isOpen={searchOpen}
        onClose={() => setSearchOpen(false)}
        services={services}
        news={newsItems}
        projects={projects}
        departments={departments}
        onNavigateToSection={handleNavigate}
      />
    </div>
  );
}
